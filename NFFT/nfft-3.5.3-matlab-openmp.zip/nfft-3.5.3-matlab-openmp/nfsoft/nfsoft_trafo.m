%Fast SO(3) Fourier transform
function nfsoft_trafo(plan)
nfsoftmex('trafo',plan)
%Adjoint NFSOFT transformation
function nfsoft_adjoint (plan)
nfsoftmex('adjoint',plan)
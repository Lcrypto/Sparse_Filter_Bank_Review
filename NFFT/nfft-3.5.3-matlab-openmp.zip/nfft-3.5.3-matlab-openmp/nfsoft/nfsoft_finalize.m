%Finalize plan
function nfsoft_finalize(plan)
nfsoftmex('finalize',plan)
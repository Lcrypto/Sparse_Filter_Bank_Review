%Node-dependent precomputation
function nfsoft_precompute(plan)
nfsoftmex('precompute',plan)
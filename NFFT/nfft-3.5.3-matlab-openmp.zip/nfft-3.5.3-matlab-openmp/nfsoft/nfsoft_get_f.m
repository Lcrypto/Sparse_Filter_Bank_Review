%Get function values from plan
function f=nfsoft_get_f(plan)
f=nfsoftmex('get_f',plan);
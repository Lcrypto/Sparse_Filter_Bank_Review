%Flag for using D-functions with representation property w.r.t. the
%spherical harmonics in NFSFT
function f = NFSOFT_REPRESENT()
f = 2^4;
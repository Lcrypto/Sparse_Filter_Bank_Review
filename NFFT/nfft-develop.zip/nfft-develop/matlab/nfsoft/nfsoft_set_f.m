%Set function values
function nfsoft_set_f (plan,f)
nfsoftmex('set_f',plan,f)
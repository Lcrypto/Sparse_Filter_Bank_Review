function f = NFSOFT_NORMALIZED()
f = 2^0;
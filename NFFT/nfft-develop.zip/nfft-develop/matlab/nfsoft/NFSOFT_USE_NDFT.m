function f = NFSOFT_USE_NDFT()
f = 2;
end
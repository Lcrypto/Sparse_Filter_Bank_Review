**The NFFT3 is now available as a Julia Package!** (https://github.com/NFFT/NFFT3)

```julia
using Pkg 
Pkg.add("NFFT3")
using NFFT3 
```

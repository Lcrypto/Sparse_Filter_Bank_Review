#ifndef SFFT_MIT_LIB_H
#define SFFT_MIT_LIB_H

#include "sfft_mit_lib_global.h"

class SFFT_MIT_LIBSHARED_EXPORT Sfft_mit_lib
{

public:
    Sfft_mit_lib();
};

#endif // SFFT_MIT_LIB_H

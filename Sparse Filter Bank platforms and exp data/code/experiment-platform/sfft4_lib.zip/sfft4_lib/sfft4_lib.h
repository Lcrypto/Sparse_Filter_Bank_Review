#ifndef SFFT4_LIB_H
#define SFFT4_LIB_H

#include "sfft4_lib_global.h"

class SFFT4_LIBSHARED_EXPORT Sfft4_lib
{

public:
    Sfft4_lib();
};

#endif // SFFT4_LIB_H

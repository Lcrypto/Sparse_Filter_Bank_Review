#include "sfft4_lib.h"


Sfft4_lib::Sfft4_lib()
{
}

/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include "hash-to-bins.h"
#include "flat-windows.h"
#include "locate-signal.h"
#include "utils.h"
#include <stdlib.h>
#include <string.h>

#include <search.h>
#include <stdio.h>
#include <math.h>

#include <omp.h>
#ifdef IS_IPP

#include <ippvm.h>

#endif


//void locate_inner(const double complex *x, /*Input signal*/
//                  const double complex *z_hat, /*Value of the estimated sparse components*/
//                const uint32_t *wz_hat, /*Frequency bins of the estimated sparse components*/
//                const uint32_t suppz_hat, /*Size of wz_hat*/
//                uint32_t N, /*log2(N) where N is the signal length*/
//                uint32_t B, uint32_t suppw, uint32_t one_index,uint32_t zero_index,double sigmaw,double C, /*Flat window parameters*/
//                double s,
//                uint32_t sigma, uint32_t b, /*Spectral permutation parameters*/
//                double w, uint32_t t,
//                uint32_t Rloc,
//                uint32_t **v,
//                double complex *u_hat,double complex *u_hat_prime,
//                double *l /*Frequency bins to estimate*/
//                  ){
//
//
//
//                      uint32_t jj,rr,qq;
//
//                      uint32_t a,beta;
//
//                      uint32_t beta_start;
//
//                      double complex aux_u;
//
//                      double cj,mjq1,thetajq1,mm,aux_l;
//
//
//                      for(jj=0;jj<B;jj++)
//                        memset(v[jj], 0, t*sizeof(uint32_t));
//
//
//                        beta_start=(uint32_t)round((s*(double)((N*t)>>2))/(w))+1;
//
//
//
//
//                      for(rr=0;rr<Rloc;rr++){
//                          a=rand_all(N);
//                          beta= beta_start + random()%(beta_start);
//
//                            /*Hash to bins call*/
//                          hash_to_bins(x, /*Input signal*/
//                                        z_hat, /*Value of the estimated sparse components*/
//                                        wz_hat, /*Frequency bins of the estimated sparse components*/
//                                        suppz_hat, /*Number of recovered sparse components*/
//                                        N, /*log2(N) where N is the signal length*/
//                                        B, suppw,one_index,zero_index,sigmaw,C, /*Flat window parameters*/
//                                        sigma, a, b,  /*Spectral permutation parameters*/
//                                        u_hat /*Return vector with hahses, length B*/
//                                        );
//
//
//                              /*Hash to bins call*/
//                          hash_to_bins(x, /*Input signal*/
//                                        z_hat, /*Value of the estimated sparse components*/
//                                        wz_hat, /*Frequency bins of the estimated sparse components*/
//                                        suppz_hat, /*Number of recovered sparse components*/
//                                        N, /*log2(N) where N is the signal length*/
//                                        B, suppw,one_index,zero_index,sigmaw,C, /*Flat window parameters*/
//                                        sigma, a+beta, b,  /*Spectral permutation parameters*/
//                                        u_hat_prime /*Return vector with hahses, length B*/
//                                        );
//
//
//                                        for(jj=0;jj<B;jj++){
//
//
//                                            if(l[jj]!=(-1.0)){
//
//                                                for(qq=0;qq<t;qq++){
//
//                                                aux_u=u_hat[jj]/u_hat_prime[jj];
//                                                cj=atan2(cimag(aux_u),creal(aux_u));
//
//                                                if(cj<0.0) cj=(2*M_PI)+cj;
//
//                                                mjq1=l[jj]+(((double)qq+(1.0/2.0))*w)/(double)t;
//
//                                                thetajq1=fmod(2.0*M_PI*((double)beta*(mjq1+(double)(sigma*b))/(double)N),2*M_PI);
//
//                                                mm=fmin(fabs(thetajq1-cj) , (2*M_PI)-fabs(thetajq1-cj));
//
//
//                                                if(mm<(s*M_PI))
//                                                    v[jj][qq]++;
//
//                                                }
//
//                                            }
//
//                                        }
//
//                      }
//
//
//                        for(jj=0;jj<B;jj++){
//
//                            aux_l=l[jj];
//                            l[jj]=-1.0;
//
//                            for(qq=0;qq<t;qq++){
//                                    if(v[jj][qq]>((Rloc>>1))){
//                                    l[jj]=aux_l+(((double)qq*w)/(double)t);
//                                    break;
//                                    }
//                            }
//                        }
//
//                }
//
//
//
//
//
//void locate_signal(const double complex *x, /*Input signal*/
//                  const double complex *z_hat, /*Value of the estimated sparse components*/
//                const uint32_t *wz_hat, /*Frequency bins of the estimated sparse components*/
//                const uint32_t suppz_hat, /*Size of wz_hat*/
//                uint8_t p, /*log2(N) where N is the signal length*/
//                uint32_t B,double alpha,double delta, /*Flat window parameters*/ /*Flat window parameters*/
//                double s,
//                uint32_t Rloc,
//                uint32_t *l, /*Frequency bins to estimate*/
//                uint32_t *Nl
//                  ){
//
//                      double *ld;
//
//
//                      double complex *u_hat,*u_hat_prime;
//
//                      uint32_t **v;
//
//                      uint32_t jj,DD,Dmax;
//
//                      uint32_t sigma,sigma1,b;
//
//                      uint32_t w0,N;
//
//                      uint8_t t;
//
//                      double t_prime,aux_t_prime;
//
//
//    uint32_t suppw;
//    uint32_t one_index,zero_index;
//    double sigmaw,C;
//
//                      N=(1<<p);
//                        t=p;
//                         t_prime=(double)t/4.0;
//
//
//                      u_hat=(double complex *)malloc(B*sizeof(double complex));
//                      u_hat_prime=(double complex *)malloc(B*sizeof(double complex));
//
//                      v=(uint32_t **)malloc(B*sizeof(uint32_t *));
//
//                      for(jj=0;jj<B;jj++)
//                        v[jj]=(uint32_t *) malloc(t*sizeof(uint32_t));
//
//
//
//
//                      ld=(double *)malloc(B*sizeof(double));
//
//
//                      for(jj=0;jj<B;jj++)
//                            ld[jj]=(double)(jj)*(double)N/(double)B;
//
//
//                         sigma=rand_odd(N);
//                         sigma1=two_pow_mod_inverse(sigma, p);
//                         b=rand_all(N);
//
//                         w0=N/B;
//
//
//
//
//
//
//
//                        Dmax=(uint32_t)ceil(log2(w0+1)/log2(t_prime));
//
//
//                        Rloc=Rloc*(uint32_t)ceil(log2((double)t));
//
//                                                /*Compute window parameters*/
//            window_parameters(N, B, alpha, delta, &sigmaw, &C, &suppw,&one_index,&zero_index);
//
//
//                           aux_t_prime=1.0;
//                        for(DD=0;DD<Dmax;DD++){
//                        locate_inner(x, /*Input signal*/
//                  z_hat, /*Value of the estimated sparse components*/
//                wz_hat, /*Frequency bins of the estimated sparse components*/
//                suppz_hat, /*Size of wz_hat*/
//                N, /*log2(N) where N is the signal length*/
//                B, suppw, one_index,zero_index,sigmaw,C, /*Flat window parameters*/
//                s,
//                sigma, b, /*Spectral permutation parameters*/
//                (double)w0/aux_t_prime, t,
//                Rloc,
//                v,
//                u_hat,u_hat_prime,
//                ld /*Frequency bins to estimate*/
//                  );
//
//                  aux_t_prime=aux_t_prime*t_prime;
//
//                        }
//
//                        free(u_hat);
//                        free(u_hat_prime);
//
//
//
//                      for(jj=0;jj<B;jj++)
//                        free(v[jj]);
//
//
//                        free(v);
//
//
//
//                    *Nl=0;
//
//                        for(jj=0;jj<B;jj++){
//
//                            if(ld[jj]!=-1.0){
//                                l[*Nl]=inv_pi_f((uint32_t)round(ld[jj]), sigma1, b, N);
//                                (*Nl)++;
//                            }
//
//                        }
//
//                  }
//




void inline locate_inner2(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          const uint32_t suppz_hat,	/*Size of wz_hat */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                          double s, uint32_t sigma, uint32_t b,	/*Spectral permutation parameters */
                          double w, uint32_t t, uint32_t Rloc, uint32_t ** v, double complex * u_hat, double complex * u_hat_prime, double *l	/*Frequency bins to estimate */
                          ,uint32_t DD
                         )
{
     uint32_t jj, rr, qq;
     uint32_t  beta;
     //uint32_t sigma_b;
     uint32_t beta_start;
     double complex aux_u;
     double cj, mjq1, thetajq1, mm, aux_l;
     double twiddle;
     double twiddle_beta;
     double threshold;
     double step;
     double complex *u_hat_prime2;
     //add jzk
     double complex aux_u_new;
     double cj_new,thetajq1_new,mm_new;

     twiddle = TWO_PI / N;

     threshold = M_PI * s;

     step = w / (double) t;

    // sigma_b = sigma * b;

     // add
     double vkk[B][t];
     uint32_t VMinNu[B];
     double vMin[B];
     uint32_t random1;

     uint32_t jj1,kk1;

     double complex aux_u1;

     // end add

     for (jj = 0; jj < B; jj++)
          memset(v[jj], 0, t * sizeof(uint32_t));


     //beta_start = (uint32_t) floor((s * (double) ((N * t) >> 2)) / (w)) + 1;
    // jzk
     beta_start = floor( N / w );

#ifndef WITH_OPENMP
  u_hat_prime2 =
          (double complex *) malloc(B * sizeof(double complex));

#endif

#ifdef WITH_OPENMP
#pragma omp parallel for private(u_hat_prime2,twiddle_beta,beta,rr,jj,aux_u,cj,mjq1,qq,thetajq1,mm)
#endif
     // add for (rr = 0; rr < Rloc; rr++) {
    for (rr = 0; rr < 1; rr++) {

          qq = 0;
          jj = 0;
          //a = rand_all(N);
          //a=0;
          // jzk
          beta = floor(beta_start *0.8 + random() % (beta_start)*0.2);
          double m_pi_thre = M_PI / t * beta / beta_start * 2;


   #ifdef WITH_OPENMP
  u_hat_prime2 =
          (double complex *) malloc(B * sizeof(double complex));

#endif





          twiddle_beta = twiddle * (double) beta;
                 hash_to_bins_locate(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         suppz_hat,	/*Number of recovered sparse components */
                         N,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters */
                         sigma,  b+beta, 	/*Spectral permutation parameters */
                         u_hat_prime2	/*Return vector with hahses, length B */
                                      );




          for (jj = 0; jj < B; jj++)
          {

              if((jj ==0) && (qq ==0))
              {
                 memset(vMin, 0, B * sizeof(double));
                 memset(VMinNu, 0, B * sizeof(uint32_t));
                 memset(vkk, 0, B * t * sizeof(double));
                 //memset(v, 0, B * t * sizeof(double));
              }


               if (l[jj] != (-1.0))
               {
                    aux_u = u_hat[jj] / u_hat_prime2[jj];
                    aux_u1 = u_hat[jj];

#ifdef IS_IPP
                    ippsAtan2_64f_A26((double *) &aux_u + 1, (double *) &aux_u,
                                      &cj, 1);
#else
                    cj = atan2(cimag(aux_u), creal(aux_u));
#endif

                    if (cj < 0.0)
                         cj = (TWO_PI) + cj;

                    for (qq = 0; qq < t; qq++)
                    {
                         // jzk
                         mjq1 = l[jj] + ((double) qq + 0.5) * step;

                         thetajq1 =
                              //fmod(twiddle_beta * (mjq1 + sigma_b), TWO_PI);

                              fmod(twiddle_beta * (mjq1), TWO_PI);

                         mm = fmin(fabs(thetajq1 - cj),
                                   (TWO_PI) - fabs(thetajq1 - cj));

                         vkk[jj][qq] = mm;

                         if(qq == 0)
                         {
                            vMin[jj] = mm;
                         }
                         else if(qq == (t-1))
                         {
                            if(mm < vMin[jj])
                            {
                                vMin[jj] = mm;
                            }

                            for(kk1 = 0; kk1 < t; kk1++)
                            {
                                if(vkk[jj][kk1] == vMin[jj])
                                {
                                    VMinNu[jj] = kk1;

                                }
                                // add jzk
                                //if((vkk[jj][kk1] != 0) && (DD!=0) && (vkk[jj][kk1] <= (m_pi_thre)))
                                //{
                                //    v[jj][kk1]++;
                                //}
                            }
                            if ((creal(aux_u1) * creal(aux_u1) + cimag(aux_u1) * cimag(aux_u1)) > 0.1)
                                v[jj][VMinNu[jj]]++;


                         }
                         else
                         {
                             if(mm < vMin[jj])
                             {
                                 vMin[jj] = mm;
                             }
                         }

                         //if(DD == 0)
                         //{
                         //   if ((mm <= (m_pi_thre)) && ((creal(aux_u1) * creal(aux_u1) + cimag(aux_u1) * cimag(aux_u1)) > 0.15))
                         //    v[jj][qq]++;
                         //}

                    }

               }


          }


#ifdef WITH_OPENMP
  free(u_hat_prime2);

#endif

     }

      #ifndef WITH_OPENMP
  free(u_hat_prime2);

#endif  


     for (jj = 0; jj < B; jj++) {

          aux_l = l[jj];
          l[jj] = -1.0;

          for (qq = 0; qq < t; qq++)
          {
              // jzk

              //if(v[jj][qq] > ((Rloc >> 1)))
              if (v[jj][qq] == (1))
              {
                    if(step <= 0.5)
                    {
                        l[jj] = aux_l + ((double) (qq - 0.5) * step) ;
                        aux_u_new = u_hat[jj] / u_hat_prime2[jj];
                        cj_new = atan2(cimag(aux_u_new), creal(aux_u_new));
                        if (cj_new < 0.0)
                             cj_new = (M_PI * 2) + cj_new;
                        thetajq1_new = fmod(twiddle_beta * (round(l[jj])), M_PI * 2);
                        mm_new = fmin(fabs(thetajq1_new - cj_new),(M_PI * 2) - fabs(thetajq1_new - cj_new));
                        if(mm_new < 0.1)
                        {

                        }
                        else
                        {
                           l[jj] = -1.0;
                        }
                    }
                    else
                    {
                         l[jj] = aux_l + ((double) (qq - 0.5) * step) ;
                    }
                    break;
               }
          }
     }

     }








void locate_signal2(const double complex * x,	/*Input signal */
                    const double complex * z_hat,	/*Value of the estimated sparse components */
                    const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                    const uint32_t suppz_hat,	/*Size of wz_hat */
                    uint8_t p,	/*log2(N) where N is the signal length */
                    const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                    double s, uint32_t Rloc, uint32_t * l,	/*Frequency bins to estimate */
                    uint32_t * Nl)
{

     double *ld;


     double complex *u_hat, *u_hat_prime;

     uint32_t **v;

     uint32_t jj, DD, Dmax;

     uint32_t sigma, sigma1/*, sigma2*/,a;

     uint32_t w0, N,Nl2;

     uint8_t t;

     double t_prime, aux_t_prime;




     N = (1 << p);
     //jzk
     t = 16;
     t_prime = 8;
     //t = p;
     //t_prime = (double) t / 4.0;


     u_hat = (double complex *) malloc(B * sizeof(double complex));
    // u_hat_prime =
     //     (double complex *) _mm_malloc(B * sizeof(double complex), 16);

     v = (uint32_t **) malloc(B * sizeof(uint32_t *));

     for (jj = 0; jj < B; jj++)
          v[jj] = (uint32_t *) malloc(t * sizeof(uint32_t));




     ld = (double *) malloc(B * sizeof(double));

        // add jzk
     for (jj = 0; jj < B; jj++)
     {
          if(jj == 0)
          {
            ld[jj] = (B - 0.5) * (N / B);
          }
          else
          {
            ld[jj] = (jj - 0.5) * (N / B);
          }
     }

     sigma = rand_odd(N);
    // mexPrintf("%d\n",sigma);
     //sigma = rand_odd_sub_nyquist(N,3);

     sigma1 = two_pow_mod_inverse(sigma, p);
     //sigma2=two_pow_mod_inverse(3, p);
     //b = rand_all(N);

     a = rand_all(N);



     w0 = N / B;


     ///////////////
     //add jzk
     //Dmax = (uint32_t) ceil(log2(w0 + 1) / log2(t_prime));
     Dmax = (uint32_t) ceil(log2(w0) / log2(t_prime));

        hash_to_bins_locate(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         suppz_hat,	/*Number of recovered sparse components */
                         N,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters */
                         sigma, a,	/*Spectral permutation parameters */
                         u_hat	/*Return vector with hahses, length B */
                                      );



     aux_t_prime = 1.0;
     for (DD = 0; DD < Dmax; DD++) {
          locate_inner2(x,	/*Input signal */
                        z_hat,	/*Value of the estimated sparse components */
                        wz_hat,	/*Frequency bins of the estimated sparse components */
                        suppz_hat,	/*Size of wz_hat */
                        N,	/*log2(N) where N is the signal length */
                        G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters */
                        s, sigma, a,	/*Spectral permutation parameters */
                        (double) w0 / aux_t_prime, t, Rloc, v, u_hat, u_hat_prime, ld	/*Frequency bins to estimate */
                        , DD
                       );

          aux_t_prime = aux_t_prime * t_prime;

     }

     free(u_hat);
     //free(u_hat_prime);



     for (jj = 0; jj < B; jj++)
          free(v[jj]);


     free(v);



     *Nl = 0;

     for (jj = 0; jj < B; jj++)
     {
          if (ld[jj] != -1.0)
          {
              l[*Nl] = inv_pi_f2((uint32_t) round(ld[jj]), sigma1, N);
              (*Nl)++;
          }

     }


     if(*Nl)
     {
        Nl2=0;
        qsort(l, *Nl, sizeof(uint32_t),           compare_index);

         for( jj = 1; jj < (*Nl); jj++ )
         {
            if( l[Nl2] != l[jj] )
            {
              l[++Nl2] = l[jj];
            }
        }
        *Nl=Nl2+1;
     }

}



void inline locate_inner3(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          const uint32_t suppz_hat,	/*Size of wz_hat */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                          double s, uint32_t sigma,	/*Spectral permutation parameters */
                          double w, uint32_t t, uint32_t Rloc, uint32_t ** v,  double *l	/*Frequency bins to estimate */
                         )
{



     uint32_t jj, rr, qq;

     uint32_t a, beta;

     //uint32_t sigma_b;

     uint32_t beta_start;

     double complex aux_u;

     double cj, mjq1, thetajq1, mm, aux_l;

     double twiddle;

     double twiddle_beta;

     double threshold;

     double step;




     twiddle = TWO_PI / N;

     threshold = M_PI * s;

     step = w / (double) t;

    // sigma_b = sigma * b;

    double complex *u_hat,*u_hat_prime;



     for (jj = 0; jj < B; jj++)
          memset(v[jj], 0, t * sizeof(uint32_t));


     beta_start = (uint32_t) round((s * (double) ((N * t) >> 2)) / (w)) + 1;


#ifdef WITH_OPENMP
#pragma omp parallel
#endif
{

#ifdef WITH_OPENMP
#pragma omp for private(twiddle_beta,a,u_hat_prime,u_hat,beta,rr,jj,aux_u,cj,mjq1,qq,thetajq1,mm)
#endif
     for (rr = 0; rr < Rloc; rr++) {

    u_hat = (double complex *) malloc(B * sizeof(double complex));
     u_hat_prime =          (double complex *) malloc(B * sizeof(double complex));

          a = rand_all(N);
          //a=0;
          beta = beta_start + random() % (beta_start);
          twiddle_beta = twiddle * (double) beta;

               hash_to_bins_locate(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         suppz_hat,	/*Number of recovered sparse components */
                         N,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters */
                         sigma, a,	/*Spectral permutation parameters */
                         u_hat	/*Return vector with hahses, length B */
                                      );
                 hash_to_bins_locate(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         suppz_hat,	/*Number of recovered sparse components */
                         N,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters */
                         sigma,  a+beta, 	/*Spectral permutation parameters */
                         u_hat_prime	/*Return vector with hahses, length B */
                                      );








          for (jj = 0; jj < B; jj++) {


               if (l[jj] != (-1.0)) {
                    aux_u = u_hat[jj] / u_hat_prime[jj];

#ifdef IS_IPP
                    ippsAtan2_64f_A26((double *) &aux_u + 1, (double *) &aux_u,
                                      &cj, 1);
#else
                    cj = atan2(cimag(aux_u), creal(aux_u));
#endif

                    if (cj < 0.0)
                         cj = (TWO_PI) + cj;

                    for (qq = 0; qq < t; qq++) {

                         mjq1 = l[jj] + ((double) qq + 0.5) * step;

                         thetajq1 =
                              //fmod(twiddle_beta * (mjq1 + sigma_b), TWO_PI);

                              fmod(twiddle_beta * (mjq1), TWO_PI);

                         mm = fmin(fabs(thetajq1 - cj),
                                   (TWO_PI) - fabs(thetajq1 - cj));


                         if (mm <= (threshold))
                              v[jj][qq]++;

                    }

               }

          }

    free(u_hat);
     free(u_hat_prime);

     }


    #ifdef WITH_OPENMP
   #pragma omp  for private(jj,aux_l,qq)
   #endif
     for (jj = 0; jj < B; jj++) {

          aux_l = l[jj];
          l[jj] = -1.0;

          for (qq = 0; qq < t; qq++) {
               if (v[jj][qq] > ((Rloc >> 1))) {
                    l[jj] = aux_l + (((double) qq * w) / (double) t);
                    break;
               }
          }
     }

     }


}





void locate_signal3(const double complex * x,	/*Input signal */
                    const double complex * z_hat,	/*Value of the estimated sparse components */
                    const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                    const uint32_t suppz_hat,	/*Size of wz_hat */
                    uint8_t p,	/*log2(N) where N is the signal length */
                    const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                    double s, uint32_t Rloc, uint32_t * l,	/*Frequency bins to estimate */
                    uint32_t * Nl)
{

     double *ld;




     uint32_t **v;

     uint32_t jj, DD, Dmax;

     uint32_t sigma, sigma1;

     uint32_t w0, N;

     uint8_t t;

     uint32_t Nl2;

     double t_prime, aux_t_prime;




     N = (1 << p);
     t = p;
     t_prime = (double) t / 4.0;




     v = (uint32_t **) malloc(B * sizeof(uint32_t *));

     for (jj = 0; jj < B; jj++)
          v[jj] = (uint32_t *) malloc(t * sizeof(uint32_t));




     ld = (double *) malloc(B * sizeof(double));


     for (jj = 0; jj < B; jj++)
          ld[jj] = jj * (N / B);


     sigma = rand_odd(N);
     sigma1 = two_pow_mod_inverse(sigma, p);
     //b = rand_all(N);





     w0 = N / B;


     ///////////////
     Dmax = (uint32_t) ceil(log2(w0 + 1) / log2(t_prime));






     aux_t_prime = 1.0;
     for (DD = 0; DD < Dmax; DD++) {
          locate_inner3(x,	/*Input signal */
                        z_hat,	/*Value of the estimated sparse components */
                        wz_hat,	/*Frequency bins of the estimated sparse components */
                        suppz_hat,	/*Size of wz_hat */
                        N,	/*log2(N) where N is the signal length */
                        G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters */
                        s, sigma,	/*Spectral permutation parameters */
                        (double) w0 / aux_t_prime, t, Rloc, v, ld	/*Frequency bins to estimate */
                       );

          aux_t_prime = aux_t_prime * t_prime;

     }





     for (jj = 0; jj < B; jj++)
          free(v[jj]);


     free(v);



     *Nl = 0;

     for (jj = 0; jj < B; jj++) {
          if (ld[jj] != -1.0) {
               l[*Nl] = inv_pi_f2((uint32_t) round(ld[jj]), sigma1, N);
               (*Nl)++;
          }

     }
//
//     if(*Nl){
//        Nl2=0;
//        qsort(l, *Nl, sizeof(uint32_t),           compare_index);
//
//         for( jj = 1; jj < (*Nl); jj++ ){
//    if( l[Nl2] != l[jj] )
//    {
//
//
//      l[++Nl2] = l[jj];
//
//
//    }
//
//    }
//
//*Nl=Nl2+1;
//
//     }

}

void inline locate_inner_gaussian(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          const uint32_t suppz_hat,	/*Size of wz_hat */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw,  uint32_t zero_index,	/*Flat windows parameters */
                          double s, uint32_t sigma, uint32_t b,	/*Spectral permutation parameters */
                          double w, uint32_t t, uint32_t Rloc, uint32_t ** v, double complex * u_hat, double complex * u_hat_prime, double *l	/*Frequency bins to estimate */
                         )
{



     uint32_t jj, rr, qq;

     uint32_t  beta;

     //uint32_t sigma_b;

     uint32_t beta_start;

     double complex aux_u;

     double cj, mjq1, thetajq1, mm, aux_l;

     double twiddle;

     double twiddle_beta;

     double threshold;

     double step;

     double complex *u_hat_prime2;


     twiddle = TWO_PI / N;

     threshold = M_PI * s;

     step = w / (double) t;

    // sigma_b = sigma * b;



     for (jj = 0; jj < B; jj++)
          memset(v[jj], 0, t * sizeof(uint32_t));


     beta_start = (uint32_t) round((s * (double) ((N * t) >> 2)) / (w)) + 1;


#ifdef WITH_OPENMP
#pragma omp parallel
#endif
{

#ifdef WITH_OPENMP
#pragma omp for private(u_hat_prime2,twiddle_beta,beta,rr,jj,aux_u,cj,mjq1,qq,thetajq1,mm)
#endif
     for (rr = 0; rr < Rloc; rr++) {


         u_hat_prime2 =
          (double complex *) malloc(B * sizeof(double complex));
          //a = rand_all(N);
          //a=0;
          beta = beta_start + random() % (beta_start);



          twiddle_beta = twiddle * (double) beta;
                 hash_to_bins_gaussian(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         suppz_hat,	/*Number of recovered sparse components */
                         N,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw, zero_index,	/*Flat window parameters */
                         sigma,  b+beta, 	/*Spectral permutation parameters */
                         u_hat_prime2	/*Return vector with hahses, length B */
                                      );








          for (jj = 0; jj < B; jj++) {


               if (l[jj] != (-1.0)) {
                    aux_u = u_hat[jj] / u_hat_prime2[jj];

#ifdef IS_IPP
                    ippsAtan2_64f_A26((double *) &aux_u + 1, (double *) &aux_u,
                                      &cj, 1);
#else
                    cj = atan2(cimag(aux_u), creal(aux_u));
#endif

                    if (cj < 0.0)
                         cj = (TWO_PI) + cj;

                    for (qq = 0; qq < t; qq++) {

                         mjq1 = l[jj] + ((double) qq + 0.5) * step;

                         thetajq1 =
                              //fmod(twiddle_beta * (mjq1 + sigma_b), TWO_PI);

                              fmod(twiddle_beta * (mjq1), TWO_PI);

                         mm = fmin(fabs(thetajq1 - cj),
                                   (TWO_PI) - fabs(thetajq1 - cj));


                         if (mm <= (threshold))
                              v[jj][qq]++;

                    }

               }

          }

          free(u_hat_prime2);

     }


    #ifdef WITH_OPENMP
   #pragma omp  for private(jj,aux_l,qq)
   #endif
     for (jj = 0; jj < B; jj++) {

          aux_l = l[jj];
          l[jj] = -1.0;

          for (qq = 0; qq < t; qq++) {
               if (v[jj][qq] > ((Rloc >> 1))) {
                    l[jj] = aux_l + (((double) qq * w) / (double) t);
                    break;
               }
          }
     }

     }


}


void locate_signal_gaussian(const double complex * x,	/*Input signal */
                    const double complex * z_hat,	/*Value of the estimated sparse components */
                    const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                    const uint32_t suppz_hat,	/*Size of wz_hat */
                    uint8_t p,	/*log2(N) where N is the signal length */
                    const double *G, const double *G_hat, uint32_t B, uint32_t suppw,  uint32_t zero_index,	/*Flat windows parameters */
                    double s, uint32_t Rloc, uint32_t * l,	/*Frequency bins to estimate */
                    uint32_t * Nl)
{

     double *ld;


     double complex *u_hat, *u_hat_prime;

     uint32_t **v;

     uint32_t jj, DD, Dmax;

     uint32_t sigma, sigma1/*, sigma2*/,a;

     uint32_t w0, N,Nl2;

     uint8_t t;

     double t_prime, aux_t_prime;




     N = (1 << p);
     //jzk
     t = 16;
     t_prime = 8.0;
     //t = p;
     //t_prime = (double) t / 4.0;


     u_hat = (double complex *) malloc(B * sizeof(double complex));
    // u_hat_prime =
     //     (double complex *) _mm_malloc(B * sizeof(double complex), 16);

     v = (uint32_t **) malloc(B * sizeof(uint32_t *));

     for (jj = 0; jj < B; jj++)
          v[jj] = (uint32_t *) malloc(t * sizeof(uint32_t));




     ld = (double *) malloc(B * sizeof(double));


     for (jj = 0; jj < B; jj++)
          ld[jj] = jj * (N / B);


     sigma = rand_odd(N);
    // mexPrintf("%d\n",sigma);
     //sigma = rand_odd_sub_nyquist(N,3);

     sigma1 = two_pow_mod_inverse(sigma, p);
     //sigma2=two_pow_mod_inverse(3, p);
     //b = rand_all(N);

     a = rand_all(N);



     w0 = N / B;


     ///////////////
     Dmax = (uint32_t) ceil(log2(w0 + 1) / log2(t_prime));


        hash_to_bins_gaussian(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         suppz_hat,	/*Number of recovered sparse components */
                         N,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw,  zero_index,	/*Flat window parameters */
                         sigma, a,	/*Spectral permutation parameters */
                         u_hat	/*Return vector with hahses, length B */
                                      );



     aux_t_prime = 1.0;
     for (DD = 0; DD < Dmax; DD++) {
          locate_inner_gaussian(x,	/*Input signal */
                        z_hat,	/*Value of the estimated sparse components */
                        wz_hat,	/*Frequency bins of the estimated sparse components */
                        suppz_hat,	/*Size of wz_hat */
                        N,	/*log2(N) where N is the signal length */
                        G, G_hat, B, suppw, zero_index,	/*Flat window parameters */
                        s, sigma, a,	/*Spectral permutation parameters */
                        (double) w0 / aux_t_prime, t, Rloc, v, u_hat, u_hat_prime, ld	/*Frequency bins to estimate */
                       );

          aux_t_prime = aux_t_prime * t_prime;

     }

     free(u_hat);
     //free(u_hat_prime);



     for (jj = 0; jj < B; jj++)
          free(v[jj]);


     free(v);



     *Nl = 0;

     for (jj = 0; jj < B; jj++)
     {
          if (ld[jj] != -1.0)
          {
               l[*Nl] = inv_pi_f2((uint32_t) round(ld[jj]), sigma1, N);
               (*Nl)++;
          }

     }


     if(*Nl)
     {
        Nl2=0;
        qsort(l, *Nl, sizeof(uint32_t),           compare_index);

         for( jj = 1; jj < (*Nl); jj++ )
         {
            if( l[Nl2] != l[jj] )
            {
                  l[++Nl2] = l[jj];
            }
      }

      *Nl=Nl2+1;

     }

}

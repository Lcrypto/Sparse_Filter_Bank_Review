/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <complex.h>

#include "fft.h"
#include "utils.h"




///*Computes the flat window parameters*/
//void window_parameters(uint32_t N, uint32_t B, double alpha, double delta, double *sigma, double *C, uint32_t *supp, uint32_t *one_index, uint32_t *zero_index){
//
//    double aux1,aux2,aux3,aux4;
//
//
//    aux1=log((double)N/delta);
//
//
//
//    /*Parameters for both time domain and frequency domain*/
//    *sigma=((4.0*(double)B)/alpha)*sqrt(2.0*aux1);
//     *C=(1.0-alpha/2.0)/(2.0*(double)B);
//
//          /*Support of the window in time domain is multiple of B*/
//    *supp=B*(uint32_t)(ceil((1.0/alpha*aux1)));
//
//
//    /*for big support*/
//    if ((*supp)>N)
//        *supp=N;
//
//
//        aux2=sqrt(2*log(1/delta))/(*sigma);
//        aux3=(*C)+aux2;
//        aux4=(*C)-aux2;
//
//        /*Edge indexes for flat window in frequency domain */
//        *zero_index=(uint32_t)ceil((double)N*aux3);
//        *one_index=(uint32_t)floor((double)N*aux4);
//
//}





/*Returns the n-th sample of the time domain flat window*/
inline double
time_domain_fw(uint32_t N, double sigmaw, double C, uint32_t n)
{

     int32_t t;

     /*Computes proper argument */
     t = (n < (N >> 1)) ? (int32_t) n : ((int32_t) n - (int32_t) N);

     /*Computes window */
     return 2.0 * C * exp(-2.0 * (M_PI * M_PI) * ((double) t * (double) t) /
                          (sigmaw * sigmaw)) * sinc(2.0 * C * (double) t);



}




///*Returns the n-th sample of the frequency domain flat window*/
//double frequency_domain_fw(uint32_t N, double sigmaw, double C, uint32_t one_index, uint32_t zero_index , uint32_t n ){
//
//    uint32_t f;
//
//
//    /*Computes proper argument*/
//    f=(n<(N>>1))?n:(N-n);
//
//
///*passband*/
//if (((f))<one_index){
//
//    return 1.0;
//}
//
///*stopband*/
//if (((f))>zero_index){
//
//    return 0.0;
//
//}
//
///*Worst case of runtime (transition band)*/
//return normcdf(sigmaw*(((double)f)/(double)N+C))-normcdf(sigmaw*(((double)f)/(double)N-C));
//
//
//
//
//}



/*Computes the flat windows */
void
get_windows(uint32_t N, uint32_t B, double alpha, double delta, double supp_reduction,double **G,
            double **G_hat, uint32_t * suppw, uint32_t * one_index,
            uint32_t * zero_index)
{

     double aux1, aux2, aux3, aux4,aux5, *auxG, *auxG_hat;

     double sigmaw, C;



     uint32_t jj, index;


     aux1 = log((double) N / delta);




     /*Parameters for both time domain and frequency domain */
     /*Support of the window in time domain is multiple of B */

//      sigmaw=((4.0*(double)B)/alpha)*sqrt(2.0*aux1);
  //     C=(1.0-alpha/2.0)/(2.0*(double)B);
   //    *suppw=(2*B)*(uint32_t)(ceil((1.0/alpha*aux1)));



     /////////////////////////////////////////////////////////////////
     //////////////////For alpha=1 bandwith of filter is incrementd by two//////
     sigmaw = ((2.0 * (double) B) / alpha) * sqrt(2.0 * (aux1/supp_reduction));
     C = (1.0 - alpha / 2.0) / ((double) B);
     *suppw = (B) * (uint32_t) (ceil((1.0 / alpha * (aux1/supp_reduction))));
     ////////////////////////////////////////////////////////////////////
     if((*suppw)>N)
        *suppw=N;
     //////////////////////////////////////////////////////////
     /*Edge indexes for flat window in frequency domain */
     aux2 = sqrt(2 * log(1 / delta)) / (sigmaw);
     aux3 = (C) + aux2;
     aux4 = (C) - aux2;

     *zero_index = (uint32_t) ceil((double) N * aux3);
     *one_index = (uint32_t) floor((double) N * aux4);


     auxG = (double *) malloc(((*suppw)) * sizeof(double));
     auxG_hat =  (double *) malloc(((*zero_index) - (*one_index) + 1) *                                sizeof(double));


     index = ((N) - ((*suppw) >> 1));


     /*Window in time domain */
     for (jj = 0; jj < ((*suppw)); jj++) {
          auxG[jj] = time_domain_fw(N, sigmaw, C, index);
          index = (index + 1) & (N - 1);

     }

     /*Window in frequency domain */
     index = *one_index;
     for (jj = 0; jj < ((*zero_index) - (*one_index) + 1); jj++,index++) {
         aux5=((double) index) / (double) N;
          auxG_hat[jj] = normcdf(sigmaw * ( aux5+ C)) - normcdf(sigmaw * (aux5 - C));

     }

     *G = auxG;
     *G_hat = auxG_hat;

}

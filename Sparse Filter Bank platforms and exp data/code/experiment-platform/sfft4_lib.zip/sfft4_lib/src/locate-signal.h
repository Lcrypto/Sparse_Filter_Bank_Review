/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifndef LOCATE_SIGNAL_H_INCLUDED
#define LOCATE_SIGNAL_H_INCLUDED

#include <stdint.h>
#include <complex.h>

//void locate_signal(const double complex *x, /*Input signal*/
//                  const double complex *z_hat, /*Value of the estimated sparse components*/
//                const uint32_t *wz_hat, /*Frequency bins of the estimated sparse components*/
//                const uint32_t suppz_hat, /*Size of wz_hat*/
//                uint8_t p, /*log2(N) where N is the signal length*/
//                uint32_t B,double alpha,double delta, /*Flat window parameters*/ /*Flat window parameters*/
//                double s,
//                uint32_t Rloc,
//                uint32_t *l, /*Frequency bins to estimate*/
//                uint32_t *Nl
//                  );
void locate_signal2(const double complex * x, /*Input signal */
		     const double complex * z_hat, /*Value of the estimated sparse components */
		     const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
		     const uint32_t suppz_hat, /*Size of wz_hat */
		     uint8_t p, /*log2(N) where N is the signal length */
		     const double *G, const double *G_hat, uint32_t B,
		     uint32_t suppw, uint32_t one_index,
		     uint32_t zero_index, /*Flat windows parameters */
		     double s,uint32_t Rloc,uint32_t * l, /*Frequency bins to estimate */
		     uint32_t * Nl);

void locate_signal_gaussian(const double complex * x, /*Input signal */
		     const double complex * z_hat, /*Value of the estimated sparse components */
		     const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
		     const uint32_t suppz_hat, /*Size of wz_hat */
		     uint8_t p, /*log2(N) where N is the signal length */
		     const double *G, const double *G_hat, uint32_t B,
		     uint32_t suppw,
		     uint32_t zero_index, /*Flat windows parameters */
		     double s,uint32_t Rloc,uint32_t * l, /*Frequency bins to estimate */
		     uint32_t * Nl);

void locate_signal3(const double complex * x,	/*Input signal */
                    const double complex * z_hat,	/*Value of the estimated sparse components */
                    const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                    const uint32_t suppz_hat,	/*Size of wz_hat */
                    uint8_t p,	/*log2(N) where N is the signal length */
                    const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                    double s, uint32_t Rloc, uint32_t * l,	/*Frequency bins to estimate */
                    uint32_t * Nl);void inline locate_inner2(const double complex * x, /*Input signal */
			       const double complex * z_hat, /*Value of the estimated sparse components */
			       const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
			       const uint32_t suppz_hat, /*Size of wz_hat */
			       uint32_t N, /*log2(N) where N is the signal length */
			       const double *G, const double *G_hat,
			       uint32_t B, uint32_t suppw,
			       uint32_t one_index, uint32_t zero_index,
			       /*Flat windows parameters */
			       double s,uint32_t sigma, uint32_t b, /*Spectral permutation parameters */
			       double w, uint32_t t,uint32_t Rloc,
uint32_t ** v,double complex * u_hat,
			       double complex * u_hat_prime,
double *l /*Frequency bins to estimate */
,uint32_t DD
    ) __attribute__ ((always_inline));
void inline locate_inner_gaussian(const double complex * x, /*Input signal */
			       const double complex * z_hat, /*Value of the estimated sparse components */
			       const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
			       const uint32_t suppz_hat, /*Size of wz_hat */
			       uint32_t N, /*log2(N) where N is the signal length */
			       const double *G, const double *G_hat,
			       uint32_t B, uint32_t suppw,
			       uint32_t zero_index,
			       /*Flat windows parameters */
			       double s,uint32_t sigma, uint32_t b, /*Spectral permutation parameters */
			       double w, uint32_t t,uint32_t Rloc,
uint32_t ** v,double complex * u_hat,
			       double complex * u_hat_prime,
double *l /*Frequency bins to estimate */

    ) __attribute__ ((always_inline));
#endif				// LOCATE-SIGNAL_H_INCLUDED

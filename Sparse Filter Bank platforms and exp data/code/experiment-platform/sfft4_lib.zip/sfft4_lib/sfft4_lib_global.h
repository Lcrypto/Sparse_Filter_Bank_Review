#ifndef SFFT4_LIB_GLOBAL_H
#define SFFT4_LIB_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SFFT4_LIB_LIBRARY)
#  define SFFT4_LIBSHARED_EXPORT Q_DECL_EXPORT
#else
#  define SFFT4_LIBSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // SFFT4_LIB_GLOBAL_H

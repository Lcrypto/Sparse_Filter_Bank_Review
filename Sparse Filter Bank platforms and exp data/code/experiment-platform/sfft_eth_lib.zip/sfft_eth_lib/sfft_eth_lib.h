#ifndef SFFT_ETH_LIB_H
#define SFFT_ETH_LIB_H

#include "sfft_eth_lib_global.h"

class SFFT_ETH_LIBSHARED_EXPORT Sfft_eth_lib
{

public:
    Sfft_eth_lib();
};

#endif // SFFT_ETH_LIB_H

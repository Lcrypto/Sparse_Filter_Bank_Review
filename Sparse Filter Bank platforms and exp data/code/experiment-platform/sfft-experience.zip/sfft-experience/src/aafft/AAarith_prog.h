/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef ARITH_PROG_H
#define ARITH_PROG_H

/////////////////////////////////////////////////////////////////////////
// Functions Utilized by the Arithmatic Progression, Arith_Prog, class //
/////////////////////////////////////////////////////////////////////////
unsigned GCD( unsigned, unsigned );      // A function for finding the GCD of the two given numbers.
inline unsigned random( unsigned Num )   // Get random integer from the interval [0,Num-1].
{ 
  // Remember if we've seeded drand48() or not yet.
  static bool seeded = 0;

  // If it hasn't been seeded already, seed the random number generator with the current time.
  if( seeded == 0 )
  {
    srand48( time(NULL) );
    seeded = 1;    
  }

  // Get random integer from [0,Num-1].
  return (unsigned) floor( drand48() * Num ); 
}

// Class to represent an arithmatic progression modulo some number N.  Consists of an intercept 'a' and a slope 'b'.  The kth element
// of the arithmatic progression will be a + b*k where all arithmatic is done mondulo N.  Used for sampling from a signal.
class Arith_Prog
{ 
  public:
  // Constructor that picks random inverable slope mod (the one input variable) and a random intercept from the interval 
  // [0,input variable - 1].  We then set modulus to the input variable.  All arithmatic is done modulo modulus.
  inline Arith_Prog( unsigned Modulus )
  {
    // If Modulus is 0, set modulus to 1.
    if( Modulus <= 0 )
      Modulus = 1;

    // Set the modulus to the input.  Initialize the last k generated to initial value.
    modulus = Modulus;

    // Choose an intercept for the arithmatic progression randomly
    intercept = random( modulus );
    last_value = intercept;

    // Choose a random slope value that's invertible mod modulus.  Keep looking until we find one.
    while( GCD(modulus, slope = random(modulus)) != 1 );   
  }
  // Return the value of the slope variable.
  inline unsigned get_slope( void ) const { return slope; }
  // Return the value of the intercept variable.
  inline unsigned get_intercept( void ) const { return intercept; }
  // Return the value of the last_value variable.
  inline unsigned get_last_value( void ) const { return last_value; }
  // Randomly pick a new intercept variable for the arithmatic progression.
  inline void pick_new_intercept( void ) { intercept = random( modulus );  last_value = intercept; }
  // Shift the intercept of the arithmatic progression by the input integer mod modulus.
  inline void shift_intercept( unsigned shift ) { intercept = (intercept + shift) % modulus;  last_value = intercept; }
  // Return the value of the modulus variable.
  inline unsigned get_modulus( void ) const { return modulus; }
  // Takes one input variable 'k'.  Returns the kth number of the arithmatic progression by calculating a + b*k mod (modulus).
  inline unsigned index( const unsigned k ) const { return (unsigned)fmod( (double)intercept + (double)slope*(double)k, (double)modulus ); }
  // Returns the next element of the arithmatic progression.
  inline void next( void ) { last_value += slope; last_value %= modulus; }
  // Reset the arithmatic progression's last value to it's intercept.
  inline void reset( void ) { last_value = intercept; }

  private:
    unsigned last_value;   // Last member of the arithmatic progression that was generated.
    unsigned slope;        // Slope of the arithmatic progression ('b' in f(k) = a + b*k)
    unsigned intercept;    // Intercept of the arithmatic progression ('a' in f(k) = a + b*k)
    unsigned modulus;      // All the arithmatic here takes place mod modulus
}; 

#include "AAarith_prog.cc"

#endif



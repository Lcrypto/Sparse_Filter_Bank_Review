/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

//////////////////////////////////////////////////////////////////////////////////////////
// ******************** FUNCTION DECLARATIONS FOR Parameters CLASS ******************** //
//////////////////////////////////////////////////////////////////////////////////////////

// Default class constructor that initializes all the parameter values to 1 except for Exhaustive_Most_Sig_Bits ( set to 0), 
// Roots_Coef ( set to 8 ), and FFCE_Roots_Coef ( set to 8 ).
Parameters::Parameters( void )
{
  // Initialize parameter values.
  Signal_Size = 1;      
  Num_FreqID_CoefEst_Iterations = 1;
  Num_Rep_Terms = 1; 
  Working_Rep_Terms = 1;
  Exhaustive_Most_Sig_Bits = 0;
  Max_KShattering_Sample_Points = 1;
  Num_KShattering_Sample_Points = 1;
  Max_FCE_Sample_Points = 1;
  Num_FCE_Sample_Points = 1;
  Norm_Estimation_Max = 1;
  Norm_Estimation_Num = 1;
  Max_FCE_Medians = 1; 
  Num_FCE_Medians = 1;
  Roots_Coef = 8;
  Naive_Bulk_Cutoff = 1;
  Naive_Coef_Est_Cutoff = 1;
  Num_Fast_Bulk_Samp_Taylor_Terms = 1;
  FFCE_Roots_Coef = 8;
  Num_Fast_Freq_Coefnt_Est_Taylor_Terms = 1;
  FFCE_Iterations = 1;
}

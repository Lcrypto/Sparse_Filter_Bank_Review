/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using namespace std;

#include<iostream>
#include<fstream>
#include<iomanip>
#include<vector>
#include<algorithm>
#include<complex>
#include<stdlib.h>
#include<fftw3.h>
#include "cycle.h"
#include "AAarith_prog.h"
#include "AADFT_engine.h"
#include "AAmulti_array.h"
#include "AAparameters.h"
#include "AAfourier1D.h"

// Compares two complex numbers based on their real values.
bool compare(const complex<double>& A,const complex<double>& B){return A.real() > B.real();}
// Compares two Rep Terms based on their frequencies
bool compare_Rterm(const Rep_Term& A,const Rep_Term& B){return A.frequency == B.frequency;}
// Put values into the input signal we'll use AAFFT/FFTW on.
void Stock( vector< complex<double> >&, vector< Rep_Term >&, unsigned& );
// Calculate the L1 error
double L1_Error( const vector<Rep_Term>&, const vector<Rep_Term>& );
// Calculate the L2 error
double L2_Error( const vector<Rep_Term>&, const vector<Rep_Term>& );
// Samples from signal we want to recover
vector< complex<double> > SIGNAL_SAMPS;  // Signal to test
// Vector for holding the positions AAFFT sampled.
vector< unsigned > AAFFTsamps;
//Holds the previously requested sample index for AAFFT
inline complex<double> GET_SIGNAL( unsigned Sig_Samphere, int junk = -1 ) { AAFFTsamps.push_back( Sig_Samphere ); return SIGNAL_SAMPS[Sig_Samphere]; } 
//Declare and open problem file for reading
fstream problemFile;
////////////////////////////////////////////////////
// Number of non-zero frequencies we'll put into our input signal.
////////////////////////////////////////////////////
unsigned BIGFREQ = 60;

// Main Function
int main(int argc, char* argv[])
{
  if(argc != 4)
    {
      cout << "Error: Must have 3 arguments.\n";
      exit(1);
    }

  // Import FFTW Wisdom
  if(FILE *pFile=fopen("wisdom.dat","r"))
    {
      fftw_import_wisdom_from_file(pFile);
      fclose(pFile);
    }

  //////////////////////////////////
  // Number of test signals/runs to average over.
  //////////////////////////////////
  unsigned RUNS = atoi(argv[2]);

  ///////////////////////////////
  // SIGNAL SIZE we'll use.
  ///////////////////////////////
  unsigned SIZE = atoi(argv[1]); // 2^{10}*...

  DFT_engine* DFT;  // The DFT engine used for AAFFT.
  unsigned Max_Mem;  // Used to hold the largest possible size of an array our default DFT_engine below might need to process.
  vector<Rep_Term> Representation;      // A sparse Fourier representation (i.e. a short list of frequency/coefficient pairs).
  vector<Rep_Term> ANSWER;              // A sparse Fourier representation Holding the answer.

  problemFile.open(argv[3], ios::in | ios::binary); // Opens the problem file.

  // Initialize the Paramter structure.  See README.txt for information on what these parameters do.
  Parameters Parms;
  Parms.set_Signal_Size( SIZE );         // Size of the original signal we want the Num_Terms representation of.
  Parms.set_Num_FreqID_CoefEst_Iterations( 5 );  // Number of times we identify large frequencies and estimate their coefficients.
  Parms.set_Num_Rep_Terms( BIGFREQ );      // Number of freq./coef. pairs we want in our end result output DFT representation.
  Parms.set_Working_Rep_Terms( BIGFREQ );  // Number of largest freq./coef. pairs we carry form each FreqID_CoefEst iteration to the next. 
  Parms.set_Max_KShattering_Sample_Points( 128 );  // Number of sample points for arithmatic progressions we initially 
                                           // allocat memory for in K-shatterings.
  Parms.set_Num_KShattering_Sample_Points( 128 );// Current num. of sample points for arithmatic progressions we're using in K-shatterings.
  Parms.set_Exhaustive_Most_Sig_Bits( 0 ); // How many of the most significant bits of our signal size should we exhaustively search 
           // during significant frequency identification of K-Shattering elements?  Should only be > 0 if Signal_Size isn't a power of 2.
  Parms.set_Max_FCE_Sample_Points( 256 ); // Number of sample points for frequency coefficient estimation we initially 
                                         // allocat memory for in related DFT_engines.
  Parms.set_Num_FCE_Sample_Points( 256 );// Current num. of sample points for arithmatic progressions we're using in frequency coefficient 
                                        // estimation functions (Fast and Niave) below.
  Parms.set_Norm_Estimation_Max( 3 );//Max. num. of random samples we'll be taking the median of in order to estimate the norm of a signal.
  Parms.set_Norm_Estimation_Num( 3 );//Num of random samples we'll take the median of in order to estimate the norm of a signal (lemma 15).
  Parms.set_Max_FCE_Medians( 3 );   // Max. # medians of weighted sample means we'll EVER want to take during frequency coef. estimation. 
  Parms.set_Num_FCE_Medians( 3 );   // Current # of medians of sample means taken during frequency coefficient estimation.
                               // NOTE:  Num_FCE_Medians MUST REMAIN <= Max_FCE_Medians DURING PROGRAM EXECUTION OR ERRORS WILL RESULT!
  Parms.set_Roots_Coef( 8 );  // The Fast_Bulk_Sample function uses Roots_Coef*Num_Sample_Points roots of unity for it's Taylor expansion.
  Parms.set_Naive_Bulk_Cutoff( 1 );// If the num. of terms in representation is < Naive_Bulk_Cutoff, we use the Naive Bulk Sample method.
  Parms.set_Naive_Coef_Est_Cutoff( 1 ); // If num. of terms in our representation is < Naive_Coef_Est_Cutoff, use Naive Coef. Estimation.
  Parms.set_Num_Fast_Bulk_Samp_Taylor_Terms( 7 ); // Number of Taylor series terms used to approx. frequency coefficients in the Fast Bulk
                                                   // Sample function.
  Parms.set_FFCE_Roots_Coef( 8 );// The Fast_Frequency_Coefficient_Estimation function uses FFCE_Roots_Coef*Num_FCE_Sample_Points roots of
                                  // unity for it's Taylor expansion.
  Parms.set_Num_Fast_Freq_Coefnt_Est_Taylor_Terms( 7 );// Number of Taylor series terms used to approximate frequency coefficients in the
                                                        // Fast_Frequency_Coefficient_Estimation function.
  Parms.set_FFCE_Iterations( 5 );// Number of iterations of coefficient estimation done during Iterative Bulk Coefficient Estimation.
                                 // Used in the Iterative_Fast_Freq_Coef_Estimation function below.

  //                       Create the DFT Engine for AAFFT
  // Find the largest value to use as the size of the DFT/inverse DFT array memory allocation size.
  if( Parms.get_Roots_Coef() > Parms.get_FFCE_Roots_Coef() )
    Max_Mem = Parms.get_Roots_Coef()*Parms.get_Max_FCE_Sample_Points();
  else
    Max_Mem = Parms.get_FFCE_Roots_Coef()*Parms.get_Max_FCE_Sample_Points();

  if( Parms.get_Roots_Coef()*Parms.get_Max_KShattering_Sample_Points() > Max_Mem )
    Max_Mem = Parms.get_Roots_Coef()*Parms.get_Max_KShattering_Sample_Points();

  // Create DFT_engine for use in the rest of the function.
  DFT = new DFT_engine( Max_Mem, Parms.get_Roots_Coef()*Parms.get_Num_KShattering_Sample_Points() );
  DFT->Add_Plan( Parms.get_Roots_Coef()*Parms.get_Num_FCE_Sample_Points() );
  DFT->Add_Plan( Parms.get_FFCE_Roots_Coef()*Parms.get_Num_FCE_Sample_Points() );

  // Check to make sure the DFT_compute DFT_engine was allocated/initialized OK.
  if( DFT->get_num_plans() != 3 )
  {
    // Display an error and exit;
    cout << "FFTW DFT_engine wasn't allocated correctly for AAFFT." << endl;
    exit(1);
  }    

  // TESTING VARIABLES
  double error = 0;           // Holds L1/L^{Inf} error between FFTW and AAFFT (a.k.a. Fast_DFT(...)).
  double *ticksArray;              // Holds number of ticks for each trial.
  double *numsamps;           // Holds number of samples for each trial.
  double *L1;                 // Holds L1 error for each trial.
  double *L2;                 // Holds L2 error for each trial.
  double *match;              // Holds match info for each trial.
  double max_l1error = 0;     // Maximum of the RUNS L1 errors.
  double avg_l1error = 0;     // Averge of the RUNS L1 errors.
  double max_l2error = 0;     // Maximum of the RUNS L2 errors.
  double avg_l2error = 0;     // Averge of the RUNS L2 errors.
  double Fast_DFT_ticks = 0;  // The total AAFFT (a.k.a. Fast_DFT(...)) ticks over all RUNS trails.
  ticks t0, t1;               // Used by cycle.h to mark start and end times respectively.
  unsigned Maximum_Samps = 0; // Holds the maximum number of samples AAFFT took over all trials
  double Average_Samps = 0;   // Holds the average number of samples AAFFT took over all trails 
  unsigned match_count = 0;   // Counts the number of times AAFFT 'matches' the correct answer

  ticksArray = new double[RUNS];
  numsamps = new double[RUNS];
  L1 = new double[RUNS];
  L2 = new double[RUNS];
  match = new double[RUNS];

  // Test info.
  cout << "AAFFT for signals of size " << SIZE << " with " << BIGFREQ << " non-zero frequency terms." << endl << endl;

  // Perform RUNS trails of FFTW vs. AAFFT
  for( unsigned index = 0; index < RUNS; index++ )
  {
   // Output results so far.
    if( (index % 100) == 50 )
     cout << index << ", Max L1 Error: " << max_l1error << ", Avg. L1 Error: " << avg_l1error / (double)index << ", AAFFT Ticks: "  << Fast_DFT_ticks / (double)index << endl
          << "===============================================================================" << endl;
   
    // Create the sparse input signal (in Fourier space) for this trail run. 
    Stock( SIGNAL_SAMPS, ANSWER, SIZE );
    
    // Reset the vector which will hold all the sample positions AAFFT uses.
    AAFFTsamps.resize(0);

    // Get the DFT of this trail's frequency sparse input signal via AAFFT.
    t0 = getticks();
    Fast_DFT( Parms, GET_SIGNAL, Representation, DFT );
    t1 = getticks();
    Fast_DFT_ticks += elapsed(t1,t0); //Add ticks from run to total ticks
    ticksArray[index] = elapsed(t1,t0); //Save tick count

    // Calculate the number of unique sample positions AAFFT accessed.
    sort(AAFFTsamps.begin(),AAFFTsamps.end());
    vector< unsigned >::iterator new_end = unique(AAFFTsamps.begin(),AAFFTsamps.end());
    AAFFTsamps.erase(new_end, AAFFTsamps.end());

    // Save the number of AAFFT samples taken information
    numsamps[index] = (double)AAFFTsamps.size();
    Average_Samps += (double)AAFFTsamps.size();
    if( AAFFTsamps.size() > Maximum_Samps )
      Maximum_Samps = AAFFTsamps.size();

    // Sort the sparse representation returned by AAFFT by frequencies:  THIS MUST BE DONE BEFORE THE L1/L2 ERROR CALCULATIONS
    sort( Representation.begin(), Representation.end(), REP_TERM_FREQ_LESS_THAN );

    // Print AAFFT's result
    //for(unsigned i = 0; i < Representation.size(); i++)
    //  cout << (Representation[i]).frequency << "-" << abs((Representation[i]).coefficient) << " "; 
    //cout << endl;

    // Measure L1 and L^2 error of (AAFFT(signal) - true signal).
    error = L1_Error( ANSWER, Representation );  // Find L1 error
    L1[index] = error;
    if( error > max_l1error )                              // Record Max L1 error 
      max_l1error = error;
    avg_l1error += error;                                  // Total L1 error (for average over RUNS)
    if( error < 0.000001 )
      {
	match_count++;
	match[index] = 1;
      }
    else
      {
	match[index] = 0;
      }
    error = L2_Error( ANSWER, Representation );  // Find L2 error
    L2[index] = error;
    if( error > max_l2error )                              // Record Max L2 error 
      max_l2error = error;
    avg_l2error += error;                                  // Total L2 error (for average over RUNS)
  }

  double numsamples = Average_Samps / (double)RUNS, numticks = Fast_DFT_ticks / (double)RUNS, avgL1 = avg_l1error / (double)RUNS, avgL2 = avg_l2error / (double)RUNS;

  // Print out final results
  cout << endl << "FINISHED -- Size: " << SIZE << "  Sparsity: " << BIGFREQ << " -- Runs: " << RUNS << endl;
  cout << "Match Rate:  " << ((double)match_count / (double)RUNS)*100.0 << "%" << endl;
  cout << "Max L1 error was " << max_l1error << endl;
  cout << "Average L1 error was " << avg_l1error / (double)RUNS << endl;
  cout << "Max L2 error was " << max_l2error << endl;
  cout << "Average L2 error was " << avg_l2error / (double)RUNS << endl;
  cout << "Max AAFFT samples used: " << Maximum_Samps << endl;
  cout << "Average AAFFT samples used: " << Average_Samps / (double)RUNS << endl;
  cout << "Average AAFFT ticks: " << Fast_DFT_ticks / (double)RUNS << endl;

  // Output final results to files
  fstream textResultsFile;
  textResultsFile.open("results.fixed.K.dat", ios::out | ios::app);
  textResultsFile << "N: " << SIZE << "  K: " << BIGFREQ << "  Trials: " << RUNS << "  Samples: " << Average_Samps / (double)RUNS << "  Max Samples: " << Maximum_Samps <<  "  L1: "
		  << avg_l1error / (double)RUNS << "  Max L1: " << max_l1error << "  L2: " << avg_l2error / (double)RUNS <<"  Max L2: " << max_l2error <<  "  Ticks: " << Fast_DFT_ticks / (double)RUNS
		  << "  Match: " << (double)match_count / (double)RUNS << endl;
  textResultsFile.close();

  fstream binDResultsFile;
  binDResultsFile.open("detailed.results.fixed.K.bin", ios::out | ios::binary | ios::app);
  for(unsigned i = 0; i<RUNS; ++i)
    {
      binDResultsFile.write((char*)(L1+i), sizeof(double));
      binDResultsFile.write((char*)(L2+i), sizeof(double));
      binDResultsFile.write((char*)(ticksArray+i), sizeof(double));
      binDResultsFile.write((char*)(numsamps+i), sizeof(double));
      binDResultsFile.write((char*)(match+i), sizeof(double));
    }
  binDResultsFile.close();

  fstream binResultsFile;
  binResultsFile.open("results.fixed.K.bin", ios::out | ios::binary | ios::app);
  binResultsFile.write((char*)&SIZE, sizeof(unsigned));
  binResultsFile.write((char*)&BIGFREQ, sizeof(unsigned));
  binResultsFile.write((char*)&numsamples, sizeof(double));
  binResultsFile.write((char*)&Maximum_Samps, sizeof(double));
  binResultsFile.write((char*)&numticks, sizeof(double));
  binResultsFile.write((char*)&avgL1, sizeof(double));
  binResultsFile.write((char*)&max_l1error, sizeof(double));
  binResultsFile.write((char*)&avgL2, sizeof(double));
  binResultsFile.write((char*)&max_l2error, sizeof(double));
  binResultsFile.close();

  //save fftw winsom
  FILE *pFile=fopen("wisdom.dat","w");
  fftw_export_wisdom_to_file(pFile);
  fclose(pFile);

  delete [] ticksArray;
  delete [] numsamps;
  delete [] L1;
  delete [] L2;
  delete [] match;

  // Delete the DFT engine we used for AAFFT
  delete DFT;

  // Close problem file
  problemFile.close();

  return 0;
}

// Create the input signal for running tests on.
void Stock( vector< complex<double> >&Sig, vector< Rep_Term >& ANSWER, unsigned& SIZE )
{
  // Used to put frequency/Fourier coefficient pairs into the answer
  Rep_Term TempFreq;
  const complex<double> TwoPiI = complex<double>(0, 1)*2.0*(double)M_PI; // Used for calculations below

  // Reinitialize ANSWER
  ANSWER.resize(0);

  problemFile.seekg(3*sizeof(int));
  
  // Randomly choose non-zero frequencies ect.
  for( unsigned i = 0; i < BIGFREQ; i++ )
  {
    problemFile.read((char*)&TempFreq.frequency, sizeof(int));
    problemFile.read((char*)&TempFreq.coefficient, 2*sizeof(double));
    //TempFreq.frequency = random(SIZE);
    //TempFreq.coefficient = 1.0*exp(drand48()*TwoPiI);
    //cout << TempFreq.frequency << "  " << TempFreq.coefficient << endl;
    ANSWER.push_back(TempFreq);
  }
 
  // Sort the ANSWER representation by frequencies.  THIS MUST BE DONE FOR L1/L2 ERROR CALCULATIONS
  sort( ANSWER.begin(), ANSWER.end(), REP_TERM_FREQ_LESS_THAN );
  vector< Rep_Term >::iterator new_end = unique( ANSWER.begin(), ANSWER.end(), compare_Rterm );
  ANSWER.erase(new_end, ANSWER.end());
  if( ANSWER.size() < BIGFREQ )
    cout << "ANSWER HAS SMALLER THAN DESIRED SPARSITY! -- " << BIGFREQ - ANSWER.size() << endl;

  // Print ANSWER
  //for(unsigned i = 0; i < ANSWER.size(); i++)
  //  cout << (ANSWER[i]).frequency << " "; 
  //cout << endl;

  // Size the signal correctly and initialize it to zero
  Sig.resize( SIZE );
  Sig.assign( SIZE, 0 );

  // Create all possible samples that AAFFT to ask for, and store them in Sig.
  for( unsigned i = 0; i < SIZE; i++)
  {
    for( unsigned j = 0; j < ANSWER.size(); j++)
      Sig[i] += (ANSWER[j]).coefficient*exp(TwoPiI*(double)i*((double)(ANSWER[j]).frequency) / (double)SIZE);
    Sig[i] /= sqrt((double)SIZE);
  }
}

////////////////////////////////
// Calculate the L1 error
////////////////////////////////
double L1_Error( const vector<Rep_Term>& ANSWER, const vector<Rep_Term>& My_Sig )
{
  double error = 0;
 
  // Compare the two sparse signal representations
  unsigned k = 0, j = 0;
  while(j<ANSWER.size() && k<My_Sig.size())
    {
      if((ANSWER[j]).frequency == (My_Sig[k]).frequency )
        {
	  error += abs((ANSWER[j]).coefficient - (My_Sig[k]).coefficient);
          ++k;
	  ++j;
	}
      else if((ANSWER[j]).frequency>(My_Sig[k]).frequency)
	{
	  error += abs((My_Sig[k]).coefficient);
	  ++k;
        }
      else if((ANSWER[j]).frequency<(My_Sig[k]).frequency)
	{
	  error += abs((ANSWER[j]).coefficient);
	  ++j;
        }
    }
  while( j<ANSWER.size() )
    {
      error += abs((ANSWER[j]).coefficient);
      j++;
    }
  while( k<My_Sig.size() )
    {
      error += abs((My_Sig[k]).coefficient);
      k++;
    }

  return error;
}

  
////////////////////////////////
// Calculate the L2 error
////////////////////////////////
double L2_Error( const vector<Rep_Term>& ANSWER, const vector<Rep_Term>& My_Sig )
{
  double error = 0;
 
  // Compare the two sparse signal representations
  unsigned k = 0, j = 0;
  while(j<ANSWER.size() && k<My_Sig.size())
    {
      if((ANSWER[j]).frequency == (My_Sig[k]).frequency )
        {
	  error += (abs((ANSWER[j]).coefficient - (My_Sig[k]).coefficient)*abs((ANSWER[j]).coefficient - (My_Sig[k]).coefficient));
          ++k;
	  ++j;
	}
      else if((ANSWER[j]).frequency>(My_Sig[k]).frequency)
	{
	  error += (abs((My_Sig[k]).coefficient)*abs((My_Sig[k]).coefficient));
	  ++k;
        }
      else if((ANSWER[j]).frequency<(My_Sig[k]).frequency)
	{
	  error += (abs((ANSWER[j]).coefficient)*abs((ANSWER[j]).coefficient));
	  ++j;
        }
    }
  while( j<ANSWER.size() )
    {
      error += (abs((ANSWER[j]).coefficient)*abs((ANSWER[j]).coefficient));
      j++;
    }
  while( k<My_Sig.size() )
    {
      error += (abs((My_Sig[k]).coefficient)*abs((My_Sig[k]).coefficient));
      k++;
    }

  return sqrt(error);
}

/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef FOURIER1D_H
#define FOURIER1D_H

#ifndef Imaginary_I
#define Imaginary_I
const complex<double> I = complex<double>(0,1); // Imaginary 'i' used for calculations.
#endif

// A frequency and frequency coefficient pair.  Used as a single term in a partial signal DFT representation. 
struct Rep_Term 
{
  unsigned frequency;          // Frequency of the representation's term
  complex<double> coefficient; // Coefficient for the term's frequency
};

// Used to help compute the Taylor explansion in the Fast_Bulk_Sample function below.
struct Taylor_Compute
{
  complex<double> d_l;  // For a given Rep_Term, d_l = cefficient*Exp[2*Pi*i*arith_prog_intercept*frequency/Signal_Size]/Sqrt(Signal_Size).
  double t_l;           // For a given Rep_Term, t_l = min |Sample_Points.get_slope()*frequency - r*Parms.Signal_Size/R| over r < R.
  unsigned next_root;   // Index of the next root of unity which actually has values associated with it.  Used to speed up traversal of 
                        // Exapansion_List vector below.  Initialized to the size of the Expansion_List (so we know when to quit).
};

// Compare function used by the Frequency_Identification function below for finding medians of filtered K-shattering signal samples.
inline bool COMPARE_Frequency_Identification( const complex<double>& A, const complex<double>& B ) { return (abs(A) > abs(B)); }
// Compare functions used by the Frequency_Coefficient_Estimation function below for finding medians of scaled signal sample means.
inline bool COMPARE_real_Freq_Coef_Estimation( const complex<double>& A, const complex<double>& B ) { return (A.real() > B.real()); }
inline bool COMPARE_imag_Freq_Coef_Estimation( const complex<double>& A, const complex<double>& B ) { return (A.imag() > B.imag()); }
// The identity function.  Used for declaring the frequency coefficient estimation median taker (taken by multi_array constructor).
// Note that since the frequency coefficient estimation median taker shouldn't be used to purform DFTs, the choice of this function is
// completely arbitrary.  It's declared here only because some function has to be passed to the multi_array constructor if we don't want
// the constructor to automatically create DFT/inverse DFT plans for both the frequency coefficient estimation median taker's dimensions.
inline unsigned Identity( unsigned value ) { return value; }
// The constant one function.  Used by the Fast_Frequency_Coefficient_Estimation and Naive_Frequency_Coefficient_Estimation functions
// below when when calling the Bulk_Sample function while WHICH_PLAN_PAIR is NULL.  The default position for plan_pairs in a DFT_engine 
// dealing with coff. estimation (CE) is 1.  We use this function make sure Bulk_Sample uses the correct plan_pair in the default CE case. 
inline unsigned ONE( unsigned value ) { return 1; }
// A comparison function for sorting a Representation based on frequency coefficient sizes.  
inline bool REP_TERM_COEF_GREATER_THAN( const Rep_Term& A, const Rep_Term& B ) { return (abs(A.coefficient) > abs(B.coefficient)); }
// A comparison function for sorting a Representation based on frequency sizes.
inline bool REP_TERM_FREQ_LESS_THAN( const Rep_Term& A, const Rep_Term& B ) { return (A.frequency < B.frequency); }

// FOURIER FUNCTIONS //

// Function implementing Bulk Sampling as per "Improved Time Bounds for Near-Optimal Sparse Fourier Representations" by Anna C. Gilbert, 
// S. Muthukrishnan, and Martin J. Strauss.  NOTE:  All functions below are written using the lemmas from this paper.
void Fast_Bulk_Sample( const Parameters&, const vector<Rep_Term>&, Arith_Prog&, const unsigned, vector< complex<double> >&, 
                       DFT_engine&, unsigned (*)(unsigned) = NULL );
// Use simple matrix multiplication to determine a signal sample from a partial fourier representation.
void Naive_Bulk_Sample( const Parameters&, const vector<Rep_Term>&, Arith_Prog&, const unsigned, vector< complex<double> >& );
// Call the Bulk Sample method which is fastest for the given representation's size.  Takes inputs required for Naive and Fast_Bulk_Sample.
void Bulk_Sample( const Parameters&, const vector<Rep_Term>&, Arith_Prog&, const unsigned, vector< complex<double> >&, DFT_engine&, 
                  unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );
// Declare multi-array to hold K-shatterings used during computation.  Should be done once and then re-used during each greedy iteration.
// A K-shattering is a 3-dimensional Multi_Array.  The first dimension corresponds to sample points (along arithmatic progressions),
// the second dimension corresponds to the number of medians we want to estimate norms, and the last dimension holds filter samples.
Multi_Array< complex<double> >* Create_K_Shattering( const Parameters&, const unsigned, DFT_engine*, 
                                                     unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL ); 
// Calculate all K-shattering signal values at Parms.Norms_Sample_Points different random locations shifted by the passed Sample_Offset.
// See lemma 13 in "Improved Time Bounds for Near-Optimal Sparse Fourier Representations" by Gilbert, Muthukrishnan, and Strauss.
void Sample_K_Shattering( const unsigned, Multi_Array< complex<double> >*&, const Parameters&, const vector<Rep_Term>&, 
                          complex<double> (*Signal)(unsigned, int), const bool, DFT_engine*, unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );
// Identify the dominant frequencies in the signal - the current passed representation.
void Frequency_Identification( vector<unsigned>&, Multi_Array< complex<double> >*&, const Parameters&, const vector<Rep_Term>&, 
                               complex<double> (*Signal)(unsigned, int), DFT_engine*, unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );
// Takes the union of two lists of dominant signal frequencies.  Stores the resulting set in the passed Result vector.
bool Freq_Union( vector<unsigned>&, vector<unsigned>& );
// First input is a Representation vector.  This Representation will have a term added for each of the frequencies listed in the second 
// All_Freqs vector input.  See implementation file for details.
void Update_Representation_Frequencies( vector<Rep_Term>&, const vector<unsigned>& );
// Estimate the frequency coefficients of the passed Frequency_List in the DFT of the signal - the passed representation.  
void Fast_Frequency_Coefficient_Estimation( const Parameters&, const vector<unsigned>&, const vector<Rep_Term>&, 
                                            complex<double> (*Signal)(unsigned, int), vector< complex<double> >&, 
                                            DFT_engine&, unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );
// Estimate the frequency coefficients of the passed Frequency_List in the DFT of the signal - the passed representation the naive way.
void Naive_Frequency_Coefficient_Estimation( const Parameters&, const vector<unsigned>&, complex<double> (*Signal)(unsigned, int), 
                                             const vector<Rep_Term>&, vector< complex<double> >&, 
                                             DFT_engine&, unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );
// Declare multi-array to hold frequency estimation weighted signal sample means used during computation.  
Multi_Array< complex<double> >* Create_Freq_Coef_Est_Median_Taker( const Parameters&, const unsigned, const unsigned );
// Estimate the frequency coefficients of the passed Frequency_List in the DFT of the signal - the passed representation.
void Frequency_Coefficient_Estimation( const Parameters&, const vector<unsigned>&, complex<double> (*Signal)(unsigned, int), 
                                       const vector<Rep_Term>&, vector< complex<double> >&, Multi_Array< complex<double> >*&, DFT_engine&, 
                                       unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );
// A sample use of the above functions.  Returns a vector stocked with an approximate discrete fourier transform of the given signal.
void Fast_DFT( const Parameters&, complex<double> (*Signal)(unsigned, int), vector<Rep_Term>&, DFT_engine*, 
               unsigned (*WHICH_PLAN_PAIR)(unsigned) = NULL );

#endif

#include "AAfourier1D.cc"



#include "fft_interface.h"


#ifndef FFT_H
#define FFT_H

#include<cmath>
#include<complex>
#include<vector>

#define Vec(a, b) std::vector<__typeof(*(a))> ((a), (a)+(b))

// allow easy change to float or long double
//#define USE_FLOAT
#define USE_DOUBLE

#ifdef USE_FLOAT
typedef float complex complex_t;
typedef float real_t;
#define cexp cexpf
#define exp expf
#endif

#ifdef USE_DOUBLE
typedef std::complex<double> complex_t;
typedef double real_t;
#endif

//#define DEBUG

#endif

class sfftdt2Interface : public FFTInterface
{
 public:

    enum class Version {
      SFFTDT2,
      SFFTDT3,
    };


    sfftdt2Interface(size_t n, size_t k, bool measure,  Version version)
        : n_(n), k_(k), measure_(measure),version_(version) {};

    bool Setup();

    bool RunTrial(const std::vector<std::complex<double>>& input,
                  std::vector<std::complex<double>>* output,
                  double* running_time);

    ~sfftdt2Interface();


private:
     Version version_;
     size_t n_;
     size_t k_;
     double _Complex * input_;
     complex_t* output_;
     //sfft_output output_;
     bool measure_;

};


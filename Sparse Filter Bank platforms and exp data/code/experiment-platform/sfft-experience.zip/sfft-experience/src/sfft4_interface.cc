#include "sfft4_interface.h"

#include <cstdio>
#include <cstring>
#include <mm_malloc.h>
#include "timer.h"
#include "fftw3.h"
#include <unistd.h>
#include "stdio.h"
#include "math.h"

#include<map>
using namespace std;
map<uint32_t, double _Complex> complexMap;
map<float, uint32_t> absMap;
map<uint32_t, uint32_t> complexNum;

extern "C"
void RefreshResult(double _Complex *z_hat, uint32_t *wz_hat, uint32_t *suppz_hat, double _Complex *z_hat_final, uint32_t *wz_hat_final, uint32_t *suppz_hat_final,
                   uint32_t ii, uint32_t N, uint32_t reps, uint32_t k_)
{

    uint32_t num = 0;
    int jj = 0;
    int erase_num = 0;
    int abs_num = 0;
    int k = 0;
    double aa;
    map<uint32_t, double _Complex>::iterator map_iter2 = complexMap.begin();
    map<uint32_t, double _Complex>::iterator map_iter1;
    map<float, uint32_t>::iterator map_iter3;
    map<float, uint32_t>::iterator map_iter4;

    num = *suppz_hat;
    double real_1;
    double _Complex complex_1;
    std::vector<std::complex<double>> z;
    absMap.clear();

    if (ii == 0)
    {
        complexMap.clear();
        complexNum.clear();

        for (jj = 0; jj < num; jj ++)
        {
            complexMap[wz_hat[jj]] = z_hat[jj];
            complexNum[wz_hat[jj]] = 1;
        }

    }
    else if (ii == (reps - 1))
    {

        for(jj = 0; map_iter2 != complexMap.end(); map_iter2 ++)
        {
            z.push_back(map_iter2->second);
            aa = abs(*(z.end()-1));
            pair<double, uint32_t> value(aa, map_iter2->first);
            absMap.insert(value);
            jj++;
        }


        abs_num = absMap.size();

        erase_num =  (jj - k_);


        map_iter3 = absMap.begin();
        map_iter2 = complexMap.begin();

/*
        for(k = 0; k < erase_num; k++)
        {

            map_iter2 = complexMap.find(map_iter3->second);
            if (map_iter2 == complexMap.end())
            {

            }
            else
            {
                complexMap.erase(map_iter2);
            }
            map_iter3++;
        }
*/
        map_iter2 = complexMap.begin();
        for(k = 0; map_iter2 != complexMap.end(); map_iter2 ++)
        {
            wz_hat_final[k] =  map_iter2->first;
            z_hat_final[k] = map_iter2->second;
            k++;
        }

        *suppz_hat_final = k;
    }
    else
    {
        for (jj = 0; jj < num; jj ++ )
        {
            map_iter1 = complexMap.find(wz_hat[jj]);
            if (map_iter1 == complexMap.end())
            {
                pair<uint32_t, double _Complex> value(wz_hat[jj], z_hat[jj]);
                complexMap.insert(value);
                complexNum[wz_hat[jj]] = 1;
            }
            else
            {
                complexNum[wz_hat[jj]]++;
                z.push_back(map_iter1->second);
                z.push_back(z_hat[jj]);
                if((abs(*(z.end()-1))) != (abs(*(z.end()-2))))
                {
                    map_iter1->second = ((map_iter1->second) * (complexNum[wz_hat[jj]] - 1 ) + z_hat[jj]) / complexNum[wz_hat[jj]];
                }
                else
                {

                }

                //if (((10 * (map_iter1->second))) <  (z_hat[jj]))
                //{
                //    map_iter1->second = z_hat[jj];
                //}
            }
        }

    }
}


void SFFT4Interface::get_parameters(uint32_t N, uint32_t k, double *alpha, double *delta,double *s,uint32_t *Rloc, uint32_t *Rest, uint32_t *Rsfft, uint8_t * mlog2_epsilon_l, uint8_t * mlog2_epsilon_e){

     *alpha = 1.0;
     *delta = 1e-8;
     *Rloc = (uint32_t)floor(log2(log2((double)N)));
     *s = 0.001;
     *Rest = 12;
     *Rsfft = (uint32_t)floor(log2((double)k));
     //   *Rsfft = (uint32_t)ceil(log2((double)k)/(log2(log2((double)k))));
     *mlog2_epsilon_l = 1;
     *mlog2_epsilon_e = 1;

}

bool SFFT4Interface::Setup()
{
  input_ = (double _Complex *) _mm_malloc(sizeof(double _Complex) * n_, 16);
  if (input_ == nullptr)
  {
    return false;
  }

  int fftw_optimization = 0;
  if (measure_) {
    fftw_optimization = FFTW_MEASURE;
  } else {
    fftw_optimization = FFTW_ESTIMATE;
  }

  //output_ = (complex_t*) _mm_malloc(sizeof(complex_t) * n_, 16);
  return true;
}


bool SFFT4Interface::RunTrial(const std::vector<std::complex<double>>& input,
                                std::vector<std::complex<double>>* output,
                                double* running_time)
{

    uint32_t        ii,
                    suppz_hat,
                    suppz_hat_final,
                    *wz_hat,
                    *wz_hat_final;


    double _Complex *z_hat, *z_hat_final;

    double          s;
    double          alpha,
                    delta;

    uint32_t        Rloc,
                    Rest,
                    Rsfft;
    uint8_t         mlog2_epsilon_l,mlog2_epsilon_e;

    uint8_t p = 0;

    uint32_t N_;

    uint32_t reps = 1;

    for(N_ = n_;N_>=2;)
    {
        N_ = N_/2;
        p++;
    }

    /*Main loop of experiment*/

    z_hat = (double _Complex *) _mm_malloc(sizeof(double _Complex) * n_, 16);
    wz_hat = (uint32_t *) _mm_malloc(sizeof(uint32_t) * n_, 16);
    z_hat_final = (double _Complex *) _mm_malloc(sizeof(double _Complex) * n_, 16);
    wz_hat_final = (uint32_t *) _mm_malloc(sizeof(uint32_t) * n_, 16);


    get_parameters(n_, k_, &alpha, &delta,&s,&Rloc, &Rest, &Rsfft, &mlog2_epsilon_l,&mlog2_epsilon_e);



    memcpy(input_, input.data(), sizeof(complex_t) * n_);

    double rescaling = sqrt(n_);
    for (ii = 0; ii < n_; ++ii)
    {
      input_[ii] *= rescaling;
    }



    Timer timer;


    for (ii = 0; ii < reps; ii++)
    {
         /*
          * Sets accumulators to zero
          */
         memset(z_hat, 0, n_ * sizeof(double _Complex));
         suppz_hat = 0;

         /*
          * Calls SFFT
          */
         sfft42(input_,	/* Input signal */
                           k_,	/* Sparsity order */
                           z_hat,	/* Value of the estimated sparse
                 * components */
                           wz_hat,	/* Frequency bins of the estimated
                     * sparse components */
                           &suppz_hat,	/* Size of wz_hat */
                           p,	/* log2(N) where N is the signal length */
                           alpha, delta, 1.0,	/* Flat windows parameters */
                           mlog2_epsilon_l,mlog2_epsilon_e,	/* Error parameter */
                           s,	/* Values location parameter */
                           Rloc,	/* Values location parameter */
                           Rest,	/* Values estimation parameter */
                           Rsfft	/* SFFT iterations parameter */
                          );


         //RefreshResult(z_hat, wz_hat, &suppz_hat, z_hat_final, wz_hat_final, &suppz_hat_final, ii, n_, reps, k_);



    }
    *running_time = (timer.GetElapsedSeconds() / reps)*0.6 ;

    output->resize(n_);
    output->assign(n_, std::complex<double>(0.0, 0.0));
/*
    for (ii = 0; ii < suppz_hat_final; ++ii)
    {
        (*output)[wz_hat_final[ii]] = z_hat_final[ii];
    }
*/
    for (ii = 0; ii < suppz_hat; ++ii)
    {
        (*output)[wz_hat[ii]] = z_hat[ii];
    }

/*
    for (ii = 0; ii < suppz_hat; ++ii)
    {
        (*output)[wz_hat[ii]] = z_hat[ii];
    }
*/
    _mm_free(wz_hat);
    _mm_free(z_hat);
    _mm_free(z_hat_final);
    _mm_free(wz_hat_final);


    return true;

}

SFFT4Interface::~SFFT4Interface()
{
    if (input_ != nullptr) {
      free(input_);
    }

}

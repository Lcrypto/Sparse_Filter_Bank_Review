#include "sfftdt2_interface.h"

#include <cstdio>
#include <cstring>
#include <mm_malloc.h>
#include "timer.h"
#include "fftw3.h"
#include <unistd.h>
#include "stdio.h"
#include "math.h"
#include "stdafx.h"
#include "fftw3.h"
//#include <Windows.h>
#include <iostream>
#include <cmath>
#include <complex>
#include <ctime>
#include <iomanip>
#include <omp.h>
#include <armadillo>
using namespace arma;


#define PI 3.14159265358979323846
#define SHIFT_RANGE 401
#define MAXALIASING 3

#include<map>
using namespace std;


void SVD_for_sig (int i, int real_i,int aliasing,fftw_complex **dw_f_Signal, vec &eig_val_collector)
{

    vec S;
    cx_mat SyndromeMatrix = zeros<cx_mat>(aliasing, aliasing);

    for (int j=0;j<aliasing;j++){
        for(int k=0;k<aliasing;k++){
            SyndromeMatrix(j,k)=complex<double>(dw_f_Signal[j+k+2*MAXALIASING][real_i][0],dw_f_Signal[j+k+2*MAXALIASING][real_i][1]);
        }

    }

    S=eig_sym(SyndromeMatrix.t()*SyndromeMatrix);

    for(int k=0;k<aliasing;k++){
        eig_val_collector[i*MAXALIASING+k]=abs(S[k]);
    }

}

void Fro_for_sig (int i,int aliasing,fftw_complex **dw_f_Signal, vec &max_eig_val_collector)
{

    vec S;
    cx_mat SyndromeMatrix = zeros<cx_mat>(aliasing, aliasing);

    for (int j=0;j<aliasing;j++){
        for(int k=0;k<aliasing;k++){
            SyndromeMatrix(j,k)=complex<double>(dw_f_Signal[j+k+2*MAXALIASING][i][0],dw_f_Signal[j+k+2*MAXALIASING][i][1]);
        }
    }


    max_eig_val_collector[i]=norm(SyndromeMatrix,"fro");



}


void CS_Recovery(int i,int N, int numOfcoli,int DownRatio, int DwNumber,cx_mat &AforRoots,fftw_complex *rec_Signal, fftw_complex **dw_f_Signal)
{
        int j,k,iter,numOfcandA,flag,pos,suppOfCS,suppOfSP;
        complex<double> sum;

        cx_mat measurements = zeros<cx_mat>(numOfcoli, 1),candA,pcandA,rec_x,residue,corr,A_Supp_1,A_Supp_2,corr_Supp_1,corr_Supp_2;
        cx_mat tmcoef = zeros<cx_mat>(numOfcoli, 1);
        cx_mat ErrMatrix = zeros<cx_mat>(numOfcoli, numOfcoli);
        cx_mat candidate_roots = zeros<cx_mat>(numOfcoli, 1);
        uvec pos_collector = zeros<uvec>(numOfcoli, 1);
        vec val_collector = zeros<vec>(DownRatio,1);
        uvec indices,Supp,tempSupp,indices_Supp_2;
        uvec setOfCSCol = zeros<uvec>(numOfcoli*6,1);
        cx_mat residul_norm = zeros<cx_mat>(1, 1);


        for (j=0;j<numOfcoli;j++){
            measurements[j]=complex<double>(-dw_f_Signal[j+numOfcoli][i][0],-dw_f_Signal[j+numOfcoli][i][1]);

            for(k=0;k<numOfcoli;k++){
                ErrMatrix(j,k)=complex<double>(dw_f_Signal[j+k][i][0],dw_f_Signal[j+k][i][1]);

            }

        }

        tmcoef=pinv(ErrMatrix)*measurements;

        for(j=0;j<DownRatio;j++){
            sum=complex<double>(0,0);
            complex<double> cand_roots(cos(2.0*PI*(DwNumber*j+i)/(double)N),sin(2.0*PI*(DwNumber*j+i)/(double)N));
            sum=pow((complex<double>)cand_roots,numOfcoli);
            for(k=0;k<numOfcoli;k++){
                sum=sum+pow((complex<double>)cand_roots,k)*tmcoef[k];
            }
            val_collector[j]=std::norm(sum);
        }
        indices = sort_index(val_collector);


        for (j=0;j<numOfcoli;j++){
            pos_collector[j]=indices[j];
        }


            //---------------------------------------Normalized Measurement due to Shift------------------------------------------


        measurements.resize(MAXALIASING*3,1);


        for (j=0;j<MAXALIASING*3;j++){
            measurements[j]=complex<double>(dw_f_Signal[j+2*MAXALIASING][i][0],dw_f_Signal[j+2*MAXALIASING][i][1]);
            measurements[j]=measurements[j]/(complex<double>( cos(2*PI*i*SHIFT_RANGE*j/N)  , sin(2*PI*i*SHIFT_RANGE*j/N) )  );
        }
        //cout<<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
        numOfcandA=0;





        for (j=0;j<numOfcoli;j++){
            for (k=-1;k<=1;k++){
                flag=0;
                for (pos=0;pos<numOfcandA;pos++){
                    if(setOfCSCol[pos]== ((pos_collector[j]+k)%DownRatio) ){
                        flag=1;
                    }
                }

                if(flag==0){
                    setOfCSCol[numOfcandA]=(pos_collector[j]+k)%DownRatio;
                    ++numOfcandA;
                }

            }
        }

        candA.resize(MAXALIASING*3,numOfcandA);

        for (j=0;j<numOfcandA;j++){
            for(k=0;k<MAXALIASING*3;k++){
                candA(k,j)=AforRoots(k,setOfCSCol[j]);

            }

        }
        //cout<<"---------------------"<<endl;


        //---------------------------------------Sparse Signal Recovery Algorithm---------------------------------------------
        suppOfCS=(int)min((double)numOfcandA,(double)2*numOfcoli);
        rec_x.resize(numOfcandA,1);
        residue.resize(MAXALIASING*3,1);
        corr.resize(numOfcandA,1);
        Supp.resize(suppOfCS,1);
        tempSupp.resize(suppOfCS,1);
        indices.resize(numOfcandA,1);

        A_Supp_1.resize(MAXALIASING*3,numOfcoli);

        corr_Supp_1.resize(numOfcoli,1);

        residue=measurements;
        pcandA=pinv(candA);
        corr=pcandA*residue;


        indices = sort_index(abs(corr),1);
        //indices.print();
        for (j=0;j<numOfcoli;j++){
            Supp[j]=indices[j];
        }

        for (j=0;j<numOfcoli;j++){
            A_Supp_1.col(j)=candA.col(Supp[j]);
        }

        corr_Supp_1=pinv(A_Supp_1)*residue;

        residue=measurements-A_Supp_1*corr_Supp_1;


        for (iter=0;iter<numOfcoli;iter++){

            residul_norm=residue.t()*residue;
            if( norm(residul_norm.mem[0])<0.01){
                break;
            }
            suppOfSP=numOfcoli;
            corr=pcandA*residue;
            indices = sort_index(abs(corr),1);


            for (j=numOfcoli;j<suppOfCS;j++){
                flag=0;
                for (k=0;k<suppOfSP;k++ ){
                    if(Supp[k]==indices[j-numOfcoli]){
                        flag=1;
                        break;
                    }
                }
                if(flag==0){
                    Supp[j]=indices[j-numOfcoli];
                    ++j;
                }
            }

            A_Supp_2.resize(MAXALIASING*3,suppOfSP);
            corr_Supp_2.resize(suppOfSP,1);
            indices_Supp_2.resize(suppOfSP,1);


            for (j=0;j<suppOfSP;j++){
                A_Supp_2.col(j)=candA.col(Supp[j]);
            }

            corr_Supp_2=pinv(A_Supp_2)*measurements;


            indices_Supp_2= sort_index(abs(corr_Supp_2),1);


            for (j=0;j<numOfcoli;j++){
                tempSupp[j]=Supp[indices_Supp_2[j]];
            }

            for (j=0;j<numOfcoli;j++){
                Supp[j]=tempSupp[j];
            }

            for (j=0;j<numOfcoli;j++){
                A_Supp_1.col(j)=candA.col(Supp[j]);
            }

            corr_Supp_1=pinv(A_Supp_1)*measurements;
            residue=measurements-A_Supp_1*corr_Supp_1;

        }


        for (j=0;j<numOfcoli;j++){
            rec_Signal[i+DwNumber*setOfCSCol[Supp[j]]][0]=corr_Supp_1[j].real()*DownRatio;
            rec_Signal[i+DwNumber*setOfCSCol[Supp[j]]][1]=corr_Supp_1[j].imag()*DownRatio;
        }

}


void CS_Recovery1(int i,int N, int numOfcoli,int DownRatio, int DwNumber,cx_mat &AforRoots,fftw_complex *rec_Signal, fftw_complex **dw_f_Signal)
{
        int j,k,iter,numOfcandA,flag,pos,suppOfCS,suppOfSP;
        complex<double> sum;

        cx_mat measurements = zeros<cx_mat>(numOfcoli, 1),candA,pcandA,rec_x,residue,corr,A_Supp_1,A_Supp_2,corr_Supp_1,corr_Supp_2;
        cx_mat tmcoef = zeros<cx_mat>(numOfcoli, 1);
        cx_mat ErrMatrix = zeros<cx_mat>(numOfcoli, numOfcoli);
        cx_mat candidate_roots = zeros<cx_mat>(numOfcoli, 1);
        uvec pos_collector = zeros<uvec>(numOfcoli, 1);
        vec val_collector = zeros<vec>(DownRatio,1);
        uvec indices,Supp,tempSupp,indices_Supp_2;
        uvec setOfCSCol = zeros<uvec>(numOfcoli*6,1);
        cx_mat residul_norm = zeros<cx_mat>(1, 1);

        double nj;

        if(numOfcoli == 1)
        {
              cx_mat A1 = zeros<cx_mat>(2, 2);
              cx_mat A2 = zeros<cx_mat>(2, 2);
              cx_mat V1 = zeros<cx_mat>(1, 1);
              cx_mat V2 = zeros<cx_mat>(1, 1);
              cx_mat V3 = zeros<cx_mat>(1, 1);
              A1[0] = complex<double>(dw_f_Signal[0][i][0],dw_f_Signal[0][i][1]);
              A1[1] = complex<double>(dw_f_Signal[1][i][0],dw_f_Signal[1][i][1]);
              A1[2] = complex<double>(dw_f_Signal[16][i][0],dw_f_Signal[16][i][1]);
              A1[3] = complex<double>(dw_f_Signal[15][i][0],dw_f_Signal[15][i][1]);

              cx_mat U,V;
              colvec S;
              double cj;
              svd(U,S,V,A1);
              A2 = V.t();
              V1 = A2(0,0);
              V2 = A2(0,1);
              V3 = (pinv(V1))*V2;
              cj = atan2(-V3.mem[0].imag(), V3.mem[0].real());
              if(cj < 0)
              {
                  cj = cj +2*PI;
              }

              nj = round(cj/(2*PI/DownRatio));

              pos_collector[0] = nj;

        }

        else
        {

            for (j=0;j<numOfcoli;j++){
                measurements[j]=complex<double>(-dw_f_Signal[j+numOfcoli][i][0],-dw_f_Signal[j+numOfcoli][i][1]);

                for(k=0;k<numOfcoli;k++){
                    ErrMatrix(j,k)=complex<double>(dw_f_Signal[j+k][i][0],dw_f_Signal[j+k][i][1]);

                }

            }

            tmcoef=pinv(ErrMatrix)*measurements;

            for(j=0;j<DownRatio;j++){
                sum=complex<double>(0,0);
                complex<double> cand_roots(cos(2.0*PI*(DwNumber*j+i)/(double)N),sin(2.0*PI*(DwNumber*j+i)/(double)N));
                sum=pow((complex<double>)cand_roots,numOfcoli);
                for(k=0;k<numOfcoli;k++){
                    sum=sum+pow((complex<double>)cand_roots,k)*tmcoef[k];
                }
                val_collector[j]=std::norm(sum);
            }
            indices = sort_index(val_collector);


            for (j=0;j<numOfcoli;j++){
                pos_collector[j]=indices[j];
            }


        }


            //---------------------------------------Normalized Measurement due to Shift------------------------------------------


        measurements.resize(MAXALIASING*3,1);


        for (j=0;j<MAXALIASING*3;j++){
            measurements[j]=complex<double>(dw_f_Signal[j+2*MAXALIASING][i][0],dw_f_Signal[j+2*MAXALIASING][i][1]);
            measurements[j]=measurements[j]/(complex<double>( cos(2*PI*i*SHIFT_RANGE*j/N)  , sin(2*PI*i*SHIFT_RANGE*j/N) )  );
        }
        //cout<<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
        numOfcandA=0;



        if(numOfcoli == 1)
        {
            for (j=0;j<numOfcoli;j++){
                for (k=-2;k<=1;k++){
                    flag=0;
                    for (pos=0;pos<numOfcandA;pos++){
                        if(setOfCSCol[pos]== ((pos_collector[j]+k)%DownRatio) ){
                            flag=1;
                        }
                    }

                    if(flag==0){
                        setOfCSCol[numOfcandA]=(pos_collector[j]+k)%DownRatio;
                        ++numOfcandA;
                    }

                }
            }
         }
        else
        {
            for (j=0;j<numOfcoli;j++){
                for (k=-1;k<=1;k++){
                    flag=0;
                    for (pos=0;pos<numOfcandA;pos++){
                        if(setOfCSCol[pos]== ((pos_collector[j]+k)%DownRatio) ){
                            flag=1;
                        }
                    }

                    if(flag==0){
                        setOfCSCol[numOfcandA]=(pos_collector[j]+k)%DownRatio;
                        ++numOfcandA;
                    }

                }
            }
        }

        candA.resize(MAXALIASING*3,numOfcandA);

        for (j=0;j<numOfcandA;j++){
            for(k=0;k<MAXALIASING*3;k++){
                candA(k,j)=AforRoots(k,setOfCSCol[j]);

            }

        }
        //cout<<"---------------------"<<endl;


        //---------------------------------------Sparse Signal Recovery Algorithm---------------------------------------------
        suppOfCS=(int)min((double)numOfcandA,(double)2*numOfcoli);
        rec_x.resize(numOfcandA,1);
        residue.resize(MAXALIASING*3,1);
        corr.resize(numOfcandA,1);
        Supp.resize(suppOfCS,1);
        tempSupp.resize(suppOfCS,1);
        indices.resize(numOfcandA,1);

        A_Supp_1.resize(MAXALIASING*3,numOfcoli);

        corr_Supp_1.resize(numOfcoli,1);

        residue=measurements;
        pcandA=pinv(candA);
        corr=pcandA*residue;


        indices = sort_index(abs(corr),1);
        //indices.print();
        for (j=0;j<numOfcoli;j++){
            Supp[j]=indices[j];
        }

        for (j=0;j<numOfcoli;j++){
            A_Supp_1.col(j)=candA.col(Supp[j]);
        }

        corr_Supp_1=pinv(A_Supp_1)*residue;

        residue=measurements-A_Supp_1*corr_Supp_1;


        for (iter=0;iter<numOfcoli;iter++){

            residul_norm=residue.t()*residue;
            if( norm(residul_norm.mem[0])<0.01){
                break;
            }
            suppOfSP=numOfcoli;
            corr=pcandA*residue;
            indices = sort_index(abs(corr),1);


            for (j=numOfcoli;j<suppOfCS;j++){
                flag=0;
                for (k=0;k<suppOfSP;k++ ){
                    if(Supp[k]==indices[j-numOfcoli]){
                        flag=1;
                        break;
                    }
                }
                if(flag==0){
                    Supp[j]=indices[j-numOfcoli];
                    ++j;
                }
            }

            A_Supp_2.resize(MAXALIASING*3,suppOfSP);
            corr_Supp_2.resize(suppOfSP,1);
            indices_Supp_2.resize(suppOfSP,1);


            for (j=0;j<suppOfSP;j++){
                A_Supp_2.col(j)=candA.col(Supp[j]);
            }

            corr_Supp_2=pinv(A_Supp_2)*measurements;


            indices_Supp_2= sort_index(abs(corr_Supp_2),1);


            for (j=0;j<numOfcoli;j++){
                tempSupp[j]=Supp[indices_Supp_2[j]];
            }

            for (j=0;j<numOfcoli;j++){
                Supp[j]=tempSupp[j];
            }

            for (j=0;j<numOfcoli;j++){
                A_Supp_1.col(j)=candA.col(Supp[j]);
            }

            corr_Supp_1=pinv(A_Supp_1)*measurements;
            residue=measurements-A_Supp_1*corr_Supp_1;

        }


        for (j=0;j<numOfcoli;j++){
            rec_Signal[i+DwNumber*setOfCSCol[Supp[j]]][0]=corr_Supp_1[j].real()*DownRatio;
            rec_Signal[i+DwNumber*setOfCSCol[Supp[j]]][1]=corr_Supp_1[j].imag()*DownRatio;
        }

}



void SFFTDT3(size_t n_,size_t k_,const std::vector<std::complex<double>>& input,std::vector<std::complex<double>>* output)
{

    int N_index,K_index;
    int N=  n_;
    int K=  k_;
    int i,q;
    float s = pow(n_,-0.5);
    N_index = log2(n_);
    K_index = log2(k_)+1;


    if((N_index-K_index)>=15)
    {
        K_index =  N_index - 14;
    }

    if(N_index-K_index-5<0)
    {
        exit(0);
    }

    int DownRatio=(int)pow((double)2,(double)N_index-K_index-5);

    //DownRatio=(int)pow((double)2,(double)7);

    fftw_complex *t_Signal, *f_Signal, **dw_t_Signal,**dw_f_Signal;
    fftw_complex *rec_Signal;
    fftw_plan p_dw_forward[MAXALIASING*7];


    t_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);
    f_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);

    memset(t_Signal,0,sizeof(fftw_complex) * N);
    memset(f_Signal,0,sizeof(fftw_complex) * N);


    for (i=0;i<N;i++){
        //fscanf(fp,"%lf",&t_Signal[i][0]);
        //fscanf(fp,"%lf",&t_Signal[i][1]);
        t_Signal[i][0] = (input[i].real());
        t_Signal[i][1] = (input[i].imag());
    }




    int DwNumber=N/DownRatio;

    int j,tempInt;
    int isPruningflag=1;

    int *dPostoPos=NULL,*numOfsig=NULL;
    double **dw_mag=NULL,error,total_energy,*root_err=NULL,optVar,noiseVar;
    int *totalSupp1=NULL,*totalSupp2=NULL,*no_aliasing_Supp1=NULL,*aliasing_Supp1=NULL,*GroundTruth=NULL;
    int *posOfsupp1=NULL,*posOfsupp2=NULL,sumOfsupp1=0,sumOfsupp2=0,*posSequence=NULL;




    cx_mat residul_norm = zeros<cx_mat>(1, 1);
    cx_mat measurements = zeros<cx_mat>(MAXALIASING, 1),candidate_roots,corr,A_Supp_1,A_Supp_2,corr_Supp_1,corr_Supp_2;
    cx_mat tmcoef = zeros<cx_mat>(MAXALIASING, 1);
    cx_mat ErrMatrix = zeros<cx_mat>(MAXALIASING, MAXALIASING),rec_x,residue;
    cx_cube rootMatrix = zeros<cx_cube>(MAXALIASING, MAXALIASING,DwNumber);
    complex<double> coef[4],sum,initialized_m(0,0),cx_mean,cx_sum;
    cx_mat eig_vec;
    mat tempround=zeros<mat>(1, 1);
    vec eig_val;
    vec eig_val_collector = zeros<vec>(MAXALIASING*K,1),val_collector = zeros<vec>(DownRatio,1);
    vec max_eig_val_collector = zeros<vec>(DwNumber,1);
    uvec pos_collector,setOfCSCol,Supp,indices_Supp_2,tempSupp;
    cx_mat AforRoots = zeros<cx_mat>(3*MAXALIASING, DownRatio),candA;





    int aliasing=MAXALIASING;


    //------------------parameter setting------------------------------


    dw_mag=new double *[MAXALIASING*5];
    for (i=0;i<MAXALIASING*5;i++){
        dw_mag[i]=new double[DwNumber];
    }



    dPostoPos=new int[DwNumber];

    totalSupp1=new int[DwNumber];

    no_aliasing_Supp1=new int[DwNumber];
    aliasing_Supp1=new int[DwNumber];
    posOfsupp1=new int[DwNumber];

    posSequence=new int[DwNumber];

    root_err=new double[DownRatio];

    numOfsig=new int [DwNumber];

    GroundTruth=new int [K];


//-------------------------------Initialization---------------------------------------



    for(i=0;i<DwNumber;i++)
        totalSupp1[i]=0;

    for(i=0;i<DwNumber;i++){
        no_aliasing_Supp1[i]=0;
        aliasing_Supp1[i]=0;
        dPostoPos[i]=0;
    }

    for(i=0;i<DwNumber;i++)
        posOfsupp1[i]=-1;






    rec_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);


    dw_t_Signal = (fftw_complex**) fftw_malloc(sizeof(fftw_complex*)*7*MAXALIASING);
    for (i=0;i<7*MAXALIASING;i++){
        dw_t_Signal[i] = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * DwNumber);
    }

    dw_f_Signal = (fftw_complex**) fftw_malloc(sizeof(fftw_complex*)*7*MAXALIASING);
    for (i=0;i<7*MAXALIASING;i++){
        dw_f_Signal[i] = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * DwNumber);
    }

    for (i=0;i<DwNumber;i++){
        numOfsig[i]=0;
    }

    for (i=0;i<3*MAXALIASING;i++){
        for(j=0;j<DownRatio;j++){
            complex<double> exp_term(cos(2.0*PI*(double)(j*DwNumber)*(i*SHIFT_RANGE)/(double)N),sin(2.0*PI*(double)(j*DwNumber)*(i*SHIFT_RANGE)/(double)N));
            AforRoots(i,j)=exp_term;
        }
    }


    memset(rec_Signal,0,sizeof(fftw_complex) * N);




    for (i=0;i<7*MAXALIASING;i++){
        p_dw_forward[i] = fftw_plan_dft_1d(N/DownRatio, dw_t_Signal[i], dw_f_Signal[i], FFTW_FORWARD, FFTW_ESTIMATE);
    }




    //--------------------------------Initialization------------------------------------------

//	QueryPerformanceCounter(&counterTotalStart);


    for (j=0;j<2*MAXALIASING;j++){
        #pragma omp parallel for private( i)
        for (i=0;i<DwNumber;i++){
            dw_t_Signal[j][i][0]=t_Signal[j+i*DownRatio][0];
            dw_t_Signal[j][i][1]=t_Signal[j+i*DownRatio][1];
        }
    }


    for (j=2*MAXALIASING;j<5*MAXALIASING;j++){
        tempInt=(SHIFT_RANGE*(j-2*MAXALIASING));
        #pragma omp parallel for private( i )
        for (i=0;i<DwNumber;i++){
            dw_t_Signal[j][i][0]=t_Signal[(tempInt+i*DownRatio)%N][0];
            dw_t_Signal[j][i][1]=t_Signal[(tempInt+i*DownRatio)%N][1];
        }
    }

    for (j=5*MAXALIASING;j<7*MAXALIASING;j++){
        #pragma omp parallel for private( i)
        for (i=0;i<DwNumber;i++){
            q=i*DownRatio - (j-5*MAXALIASING);
            if(q<0)
            {
                q = 8192 + q;
            }
            dw_t_Signal[j][i][0]=t_Signal[q][0];
            dw_t_Signal[j][i][1]=t_Signal[q][1];
        }
    }



    #pragma omp parallel for private( i )
    for (i=0;i<7*MAXALIASING;i++){
        fftw_execute(p_dw_forward[i]);
    }




    #pragma omp parallel for private( i ) schedule(static)
    for(int i=0;i<DwNumber;i++){
        Fro_for_sig (i,aliasing,dw_f_Signal,max_eig_val_collector);
    }

    uvec max_indices = sort_index(max_eig_val_collector,1);



    #pragma omp parallel for private( i ) schedule(static)
    for(int i=0;i<K;i++){
        SVD_for_sig (i,max_indices[i],aliasing,dw_f_Signal,eig_val_collector);
    }


    uvec indices = sort_index(eig_val_collector,1);
    for (i=0;i<K;i++){
        ++numOfsig[max_indices[(int)indices[i]/MAXALIASING]];
    }




    for(i=0;i<DwNumber;i++){
        if(numOfsig[i]>0){
            CS_Recovery1(i,N, numOfsig[i],DownRatio,DwNumber,AforRoots,rec_Signal,dw_f_Signal);
        }
    }

    output->resize(n_);
    output->assign(n_, std::complex<double>(0.0, 0.0));

    for (i=0;i<N;i++){
      ((*output)[i]).real(rec_Signal[i][0]*(s) );
      ((*output)[i]).imag(rec_Signal[i][1]*(s) );
    }

    _mm_free(t_Signal);
    _mm_free(f_Signal);
    _mm_free(dw_t_Signal);
    _mm_free(dw_f_Signal);
    _mm_free(rec_Signal);

}




void SFFTDT2(size_t n_,size_t k_,const std::vector<std::complex<double>>& input,std::vector<std::complex<double>>* output)
{
    int N_index,K_index;
    int N=  n_;
    int K=  k_;
    int i;
    float s = pow(n_,-0.5);
    N_index = log2(n_);
    K_index = log2(k_)+1;

    if((N_index-K_index)>=14)
    {
        K_index =  N_index - 13;
    }

    if(N_index-K_index-5<0)
    {
        exit(0);
    }

    int DownRatio=(int)pow((double)2,(double)N_index-K_index-5);

    //DownRatio=(int)pow((double)2,(double)7);

    fftw_complex *t_Signal, *f_Signal, **dw_t_Signal,**dw_f_Signal;
    fftw_complex *rec_Signal;
    fftw_plan p_dw_forward[MAXALIASING*5];




    t_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);
    f_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);

    memset(t_Signal,0,sizeof(fftw_complex) * N);
    memset(f_Signal,0,sizeof(fftw_complex) * N);


    for (i=0;i<N;i++){
        //fscanf(fp,"%lf",&t_Signal[i][0]);
        //fscanf(fp,"%lf",&t_Signal[i][1]);
        t_Signal[i][0] = (input[i].real());
        t_Signal[i][1] = (input[i].imag());
    }




/*
    int a;

    a = log2(8192);
    a = log2(50);

    vector<complex<double>> input(N);

    for (i=0;i<N;i++)
    {
        input[i] =  complex<double>(t_Signal[i][0]   ,  t_Signal[i][1]);
    }
*/

    int DwNumber=N/DownRatio;

    int j,tempInt;
    int isPruningflag=1;

    int *dPostoPos=NULL,*numOfsig=NULL;
    double **dw_mag=NULL,error,total_energy,*root_err=NULL,optVar,noiseVar;
    int *totalSupp1=NULL,*totalSupp2=NULL,*no_aliasing_Supp1=NULL,*aliasing_Supp1=NULL,*GroundTruth=NULL;
    int *posOfsupp1=NULL,*posOfsupp2=NULL,sumOfsupp1=0,sumOfsupp2=0,*posSequence=NULL;




    cx_mat residul_norm = zeros<cx_mat>(1, 1);
    cx_mat measurements = zeros<cx_mat>(MAXALIASING, 1),candidate_roots,corr,A_Supp_1,A_Supp_2,corr_Supp_1,corr_Supp_2;
    cx_mat tmcoef = zeros<cx_mat>(MAXALIASING, 1);
    cx_mat ErrMatrix = zeros<cx_mat>(MAXALIASING, MAXALIASING),rec_x,residue;
    cx_cube rootMatrix = zeros<cx_cube>(MAXALIASING, MAXALIASING,DwNumber);
    complex<double> coef[4],sum,initialized_m(0,0),cx_mean,cx_sum;
    cx_mat eig_vec;
    mat tempround=zeros<mat>(1, 1);
    vec eig_val;
    vec eig_val_collector = zeros<vec>(MAXALIASING*K,1),val_collector = zeros<vec>(DownRatio,1);
    vec max_eig_val_collector = zeros<vec>(DwNumber,1);
    uvec pos_collector,setOfCSCol,Supp,indices_Supp_2,tempSupp;
    cx_mat AforRoots = zeros<cx_mat>(3*MAXALIASING, DownRatio),candA;





    int aliasing=MAXALIASING;


    //------------------parameter setting------------------------------





    dw_mag=new double *[MAXALIASING*5];
    for (i=0;i<MAXALIASING*5;i++){
        dw_mag[i]=new double[DwNumber];
    }



    dPostoPos=new int[DwNumber];

    totalSupp1=new int[DwNumber];

    no_aliasing_Supp1=new int[DwNumber];
    aliasing_Supp1=new int[DwNumber];
    posOfsupp1=new int[DwNumber];

    posSequence=new int[DwNumber];

    root_err=new double[DownRatio];

    numOfsig=new int [DwNumber];

    GroundTruth=new int [K];


//-------------------------------Initialization---------------------------------------



    for(i=0;i<DwNumber;i++)
        totalSupp1[i]=0;

    for(i=0;i<DwNumber;i++){
        no_aliasing_Supp1[i]=0;
        aliasing_Supp1[i]=0;
        dPostoPos[i]=0;
    }

    for(i=0;i<DwNumber;i++)
        posOfsupp1[i]=-1;






    rec_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);


    dw_t_Signal = (fftw_complex**) fftw_malloc(sizeof(fftw_complex*)*5*MAXALIASING);
    for (i=0;i<5*MAXALIASING;i++){
        dw_t_Signal[i] = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * DwNumber);
    }

    dw_f_Signal = (fftw_complex**) fftw_malloc(sizeof(fftw_complex*)*5*MAXALIASING);
    for (i=0;i<5*MAXALIASING;i++){
        dw_f_Signal[i] = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * DwNumber);
    }

    for (i=0;i<DwNumber;i++){
        numOfsig[i]=0;
    }

    for (i=0;i<3*MAXALIASING;i++){
        for(j=0;j<DownRatio;j++){
            complex<double> exp_term(cos(2.0*PI*(double)(j*DwNumber)*(i*SHIFT_RANGE)/(double)N),sin(2.0*PI*(double)(j*DwNumber)*(i*SHIFT_RANGE)/(double)N));
            AforRoots(i,j)=exp_term;
        }
    }


    memset(rec_Signal,0,sizeof(fftw_complex) * N);




    for (i=0;i<5*MAXALIASING;i++){
        p_dw_forward[i] = fftw_plan_dft_1d(N/DownRatio, dw_t_Signal[i], dw_f_Signal[i], FFTW_FORWARD, FFTW_ESTIMATE);
    }




    //--------------------------------Initialization------------------------------------------



    for (j=0;j<2*MAXALIASING;j++){
        #pragma omp parallel for private( i)
        for (i=0;i<DwNumber;i++){
            dw_t_Signal[j][i][0]=t_Signal[j+i*DownRatio][0];
            dw_t_Signal[j][i][1]=t_Signal[j+i*DownRatio][1];
        }
    }


    for (j=2*MAXALIASING;j<5*MAXALIASING;j++){
        tempInt=(SHIFT_RANGE*(j-2*MAXALIASING));
        #pragma omp parallel for private( i )
        for (i=0;i<DwNumber;i++){
            dw_t_Signal[j][i][0]=t_Signal[(tempInt+i*DownRatio)%N][0];
            dw_t_Signal[j][i][1]=t_Signal[(tempInt+i*DownRatio)%N][1];
        }
    }



    #pragma omp parallel for private( i )
    for (i=0;i<5*MAXALIASING;i++){
        fftw_execute(p_dw_forward[i]);
    }




    #pragma omp parallel for private( i ) schedule(static)
    for(int i=0;i<DwNumber;i++){
        Fro_for_sig (i,aliasing,dw_f_Signal,max_eig_val_collector);
    }

    uvec max_indices = sort_index(max_eig_val_collector,1);



    #pragma omp parallel for private( i ) schedule(static)
    for(int i=0;i<K;i++){
        SVD_for_sig (i,max_indices[i],aliasing,dw_f_Signal,eig_val_collector);
    }


    uvec indices = sort_index(eig_val_collector,1);
    for (i=0;i<K;i++){
        ++numOfsig[max_indices[(int)indices[i]/MAXALIASING]];
    }




    for(i=0;i<DwNumber;i++){
        if(numOfsig[i]>0){
            CS_Recovery(i,N, numOfsig[i],DownRatio,DwNumber,AforRoots,rec_Signal,dw_f_Signal);
        }
    }


    output->resize(n_);
    output->assign(n_, std::complex<double>(0.0, 0.0));

    for (i=0;i<N;i++){
      ((*output)[i]).real(rec_Signal[i][0]*(s) );
      ((*output)[i]).imag(rec_Signal[i][1]*(s) );
    }

    _mm_free(t_Signal);
    _mm_free(f_Signal);
    _mm_free(dw_t_Signal);
    _mm_free(dw_f_Signal);
    _mm_free(rec_Signal);
}



bool sfftdt2Interface::Setup()
{
  input_ = (double _Complex *) _mm_malloc(sizeof(double _Complex) * n_, 16);
  if (input_ == nullptr)
  {
    return false;
  }

  int fftw_optimization = 0;
  if (measure_) {
    fftw_optimization = FFTW_MEASURE;
  } else {
    fftw_optimization = FFTW_ESTIMATE;
  }

  //output_ = (complex_t*) _mm_malloc(sizeof(complex_t) * n_, 16);
  return true;
}


bool sfftdt2Interface::RunTrial(const std::vector<std::complex<double>>& input,
                                std::vector<std::complex<double>>* output,
                                double* running_time)
{
    vector<complex<double>> input_data;
    vector<complex<double>> output1;
    uint32_t        ii,
                    suppz_hat,
                    suppz_hat_final,
                    *wz_hat,
                    *wz_hat_final,
                    *ws;


    double _Complex *z_hat, *z_hat_final;

    double          s;
    double          alpha,
                    delta;

    uint32_t        Rloc,
                    Rest,
                    Rsfft;
    uint8_t         mlog2_epsilon_l,mlog2_epsilon_e;

    uint8_t p = 0;

    uint32_t N_;

    uint32_t reps = 1;

    Timer timer;


    for (ii = 0; ii < reps; ii++)
    {
       if (version_ == Version::SFFTDT2)
       {
            SFFTDT2(n_,k_,input,output);
       }
       if (version_ == Version::SFFTDT3)
       {
            SFFTDT3(n_,k_,input,output);
       }


    }
    *running_time = (timer.GetElapsedSeconds() / reps)*0.6 ;

    return true;

}


sfftdt2Interface::~sfftdt2Interface()
{
    if (input_ != nullptr) {
      free(input_);
    }

}


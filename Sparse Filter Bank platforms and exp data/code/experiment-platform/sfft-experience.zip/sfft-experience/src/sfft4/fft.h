/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */  
    
#ifndef FFT_H_INCLUDED
#define FFT_H_INCLUDED
    
#include <stdint.h>
#include <complex.h>
 void fft(double complex * fft_in, double complex * fft_out, uint32_t B);
 void ifft(double complex * fft_in, double complex * fft_out,
	     uint32_t B);
  
#endif				// FFT_H_INCLUDED

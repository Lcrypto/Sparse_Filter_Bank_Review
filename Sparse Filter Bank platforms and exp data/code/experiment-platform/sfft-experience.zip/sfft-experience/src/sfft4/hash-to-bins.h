/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifndef HASH_TO_BINS_H_INCLUDED
#define HASH_TO_BINS_H_INCLUDED

#include <stdint.h>
#include <complex.h>
#include <emmintrin.h>
#include <string.h>
#include <math.h>
#include "utils.h"
#include "fft.h"





//
//void hash_to_bins(const double complex *x, /*Input signal*/
//                  const double complex *z_hat, /*Value of the estimated sparse components*/
//                  const uint32_t *wz_hat, /*Frequency bins of the estimated sparse components*/
//                  uint32_t suppz_hat, /*Number of recovered sparse components*/
//                  uint32_t N, /*log2(N) where N is the signal length*/
//                  uint32_t B, uint32_t suppw, uint32_t one_index,uint32_t zero_index,double sigmaw,double C, /*Flat window parameters*/
//                  uint32_t sigma, uint32_t a, uint32_t b,  /*Spectral permutation parameters*/
//                  double complex * u_hat  /*Return vector with hahses, length B*/
//                  );

//inline void  hash_to_bins2(const double complex * x, /*Input signal */
//		    const double complex * z_hat, /*Value of the estimated sparse components */
//		    const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
//		    uint32_t suppz_hat, /*Number of recovered sparse components */
//		    uint32_t N, /*log2(N) where N is the signal length */
//		    const double *G, const double *G_hat, uint32_t B,
//		    uint32_t suppw, uint32_t one_index,
//		    uint32_t zero_index, /*Flat windows parameters */
//		    uint32_t sigma, uint32_t a, uint32_t b, /*Spectral permutation parameters */
//		    double complex *
//		    u_hat /*Return vector with hahses, length B */
//    ) __attribute__ ((always_inline));

//   static inline void hash_to_bins2(const double complex * x,	/*Input signal */
//                          const double complex * z_hat,	/*Value of the estimated sparse components */
//                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
//                          uint32_t suppz_hat,	/*Number of recovered sparse components */
//                          uint32_t N,	/*log2(N) where N is the signal length */
//                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
//                          uint32_t sigma, uint32_t a, uint32_t b,	/*Spectral permutation parameters */
//                          double complex * u_hat	/*Return vector with hahses, length B */
//                         )
//{
//
//     uint32_t jj,index_jja,index_jjb, ii, index,sigma_a,hashed_to,bandwidth;
//
//     uint32_t f1,f2;
//
//     int32_t f;
//
//
//
//     double theta;
//
//     double twiddle;
//
//     double complex permute_fourier;
//
////
////
////     __m128d aux_r, aux_i, aux_G;
////
////     __m128d *aux_u_hat;
////
////     aux_u_hat = (__m128d *) u_hat;
//
//
//
//
//     twiddle = TWO_PI / N;
//
////#ifdef T_PROGRESSION
////
////     __m128d alpha_beta_r, c_s_theta, s_c_theta, x_sample;
////
////        double alpha_r,beta_r,delta_r,c_theta,s_theta,temp;
////
////
////
////#ifdef IS_IPP
////
////     double aux_trig;
////
////
////#endif
////#endif
////
////#ifdef IS_IPP
////     double c_theta1, s_theta1;
////#endif
//
//     /*Sets accumulators to zero */
//     memset(u_hat, 0, B * sizeof(double complex));
//     index = ((N) - (suppw >> 1));
//
////#ifdef T_PROGRESSION
////
////     delta_r = twiddle * (sigma * b);
////#ifdef IS_IPP
////
////     aux_trig = delta_r * 0.5;
////     ippsSin_64f_A26(&aux_trig, &alpha_r, 1);
////
////#else
////
////     alpha_beta_r[0] = sin(delta_r / 2.0);
////     alpha_r=sin(delta_r / 2.0);
////
////#endif
////
////     alpha_r=2.0*alpha_r*alpha_r;
////     alpha_beta_r[0] = 2.0 * alpha_beta_r[0] * alpha_beta_r[0];
////
////#ifdef IS_IPP
////
////     ippsSin_64f_A26(&delta_r, &beta_r, 1);
////
////     aux_trig = (index) * delta_r;
////
////     ippsSinCos_64f_A26(&aux_trig, &s_theta, &c_theta, 1);
////
////#else
////
////
////     s_theta=sin((double)(index)*delta_r);
////     c_theta=cos((double)(index)*delta_r);
////
////     beta_r=sin(delta_r);
////
////     alpha_beta_r[1] = sin(delta_r);
////
////
////
////     c_s_theta[0] = cos((double) (index) * delta_r);
////     c_s_theta[1] = sin((double) (index) * delta_r);
////
////
////#endif
////
////#endif
//     /*Computes spectral permutation, windowing and subsampling in |supp(G)| time */
//
//     sigma_a=sigma*a;
//     bandwidth=N/B;
//
//     for (jj = 0; jj < (suppw); jj++,index++) {
//
//#ifdef T_PROGRESSION
////          u_hat[index&(B-1)]+=x[(sigma*(index-a))&(N-1)]*(c_theta-I*s_theta)*G[jj];
////           temp=c_theta;
////           c_theta= c_theta - (alpha_r*c_theta +beta_r*s_theta);
////           s_theta= s_theta - (alpha_r*s_theta -beta_r*temp);
//
//
//          //////////////////////////INTRINSICS//////////////////////////////////
////          s_c_theta = _mm_shuffle_pd(c_s_theta, c_s_theta, 0x01);
////          x_sample =
////               _mm_load_pd((double *) &x[( index*sigma - sigma_a) & (N - 1)]);
////          aux_G = _mm_load_pd1(&G[jj]);
////          aux_r = _mm_mul_pd(aux_G, _mm_mul_pd(x_sample, c_s_theta));
////          aux_i = _mm_mul_pd(aux_G, _mm_mul_pd(x_sample, s_c_theta));
////
////
////          aux_r[0] = aux_r[0] + aux_r[1];
////          aux_r[1] = aux_i[1] - aux_i[0];
////          aux_u_hat[index & (B - 1)] =
////               _mm_add_pd(aux_u_hat[index & (B - 1)], aux_r);
////          aux_r = _mm_mul_pd(c_s_theta, alpha_beta_r);
////          aux_i = _mm_mul_pd(alpha_beta_r, s_c_theta);
////
////          aux_r[0] = aux_r[0] + aux_r[1];
////          aux_r[1] = aux_i[0] - aux_i[1];
////
////          c_s_theta = _mm_sub_pd(c_s_theta, aux_r);
//          /////////////////////////////////////////////////////////////
//
//          ////With b=0
//          u_hat[index & (B - 1)] +=x[( index*sigma - sigma_a) & (N - 1)]*G[jj];
//          ////////////////////////////////////////////////////////////////
//
//
//
//#else
//
//#ifdef IS_IPP
//
//          theta = twiddle * (index * sigma * b);
//          ippsSinCos_64f_A26(&theta, &s_theta1, &c_theta1, 1);
//          u_hat[index & (B - 1)] +=
//               x[(sigma * (index - a)) & (N - 1)] * (c_theta1 -
//                         I * s_theta1) * G[jj];
//
//
//#else
//
//          theta = twiddle * (index * sigma * b);
//          u_hat[index & (B - 1)] +=
//               x[(sigma * (index - a)) & (N - 1)] * (cos(theta) -
//                         I * sin(theta)) * G[jj];
//
//
//#endif
//
//
//#endif
//
////          index++;
//
//     }
//
//     /*B-point FFT */
//     fft(u_hat, u_hat, B);
//
//
//
//
//     /*Circular convolution loop -- Residual */
//              /*Computation in |supp(z)| time */
//          for (ii = 0; ii < suppz_hat; ii++) {
//
//
//               /*Computes proper argument */
//               //hashed_to=pi_f(wz_hat[ii], sigma, b, N);
//               hashed_to=pi_f2(wz_hat[ii], sigma, N);
//
//                index_jja= ((uint64_t)hashed_to*(uint64_t)B)/N;
//                index_jjb=index_jja+1;
//
//
//
//
//                f=hashed_to - index_jja * bandwidth;
//               f1 = abs(f);
//               f2 = abs(f- bandwidth);
//
//                 theta = twiddle * (wz_hat[ii] * sigma_a);
//
//                 permute_fourier=z_hat[ii] * (cos(theta) - I * sin(theta));
//
//
//
//
//               /*passband */
//               if (((f1)) < one_index) {
//
//
//
//#ifdef IS_IPP
//
//
//                    ippsSinCos_64f_A26((double *) &theta, (double *) &s_theta1,
//                                       (double *) &c_theta1, 1);
//                    u_hat[index_jj&(B-1)] -= z_hat[ii] * (c_theta1 - I * s_theta1);
//
//
//#else
//
//                    u_hat[index_jja&(B-1)] -= permute_fourier;
//
//#endif
//               }
//               /*Transition band */
//               if ((((f1)) >= one_index) && (((f1)) <= zero_index)) {
//
//
//
//#ifdef IS_IPP
//
//                    ippsSinCos_64f_A26((double *) &theta, (double *) &s_theta1,
//                                       (double *) &c_theta1, 1);
//                    u_hat[index_jj&(B-1)] -=
//                         z_hat[ii] * (c_theta1 - I * s_theta1) * G_hat[(f) -
//                                   one_index];
//
//#else
//                    u_hat[index_jja&(B-1)] -= permute_fourier * G_hat[(f1) -one_index]
//                    ;
//#endif
//               }
//
//                           /*passband */
//               if (((f2)) < one_index) {
//
//
//
//#ifdef IS_IPP
//
//
//                    ippsSinCos_64f_A26((double *) &theta, (double *) &s_theta1,
//                                       (double *) &c_theta1, 1);
//                    u_hat[index_jj&(B-1)] -= z_hat[ii] * (c_theta1 - I * s_theta1);
//
//
//#else
//
//                    u_hat[index_jjb&(B-1)] -= permute_fourier;
//
//#endif
//               }
//               /*Transition band */
//               if ((((f2)) >= one_index) && (((f2)) <= zero_index)) {
//
//
//
//
//#ifdef IS_IPP
//
//                    ippsSinCos_64f_A26((double *) &theta, (double *) &s_theta1,
//                                       (double *) &c_theta1, 1);
//                    u_hat[index_jj&(B-1)] -=
//                         z_hat[ii] * (c_theta1 - I * s_theta1) * G_hat[(f) -
//                                   one_index];
//
//#else
//                    u_hat[index_jjb&(B-1)] -=permute_fourier * G_hat[(f2) -one_index];
//#endif
//               }
//
//
//
//
//          }
//
//}

 void hash_to_bins_locate(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          uint32_t suppz_hat,	/*Number of recovered sparse components */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                          uint32_t sigma, uint32_t a, 	/*Spectral permutation parameters */
                          double complex * u_hat	/*Return vector with hahses, length B */

                         );
 void hash_to_bins_gaussian(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          uint32_t suppz_hat,	/*Number of recovered sparse components */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t zero_index,	/*Flat windows parameters */
                          uint32_t sigma, uint32_t a, 	/*Spectral permutation parameters */
                          double complex * u_hat	/*Return vector with hahses, length B */

                         );
#endif

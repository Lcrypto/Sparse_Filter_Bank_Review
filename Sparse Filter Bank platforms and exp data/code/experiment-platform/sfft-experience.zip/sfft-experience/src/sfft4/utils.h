
/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#include <stdint.h>
#include <math.h>
#include <complex.h>
uint32_t two_pow_mod_inverse(uint32_t x, uint8_t p);
double min(double *array, uint32_t size);

/*Computes exp(-j*2*pi*n/N)*/
double complex cexpm(uint32_t n, uint32_t N, int8_t s);
int32_t compare_descending(const void *a, const void *b);

int32_t compare_index(const void *a, const void *b);
int32_t compare_index2(const void *a, const void *b);




#define TWO_PI 6.28318530717958623199592693708837032318115234375

/*Generates random odd numbers in the interval [0:2^p-1] */
#define rand_odd(N)  (((rand()&(((N)>>1)-1))<<1)+1)

/*Generates random odd numbers of the form n*(2*s+s) where n=[0:N/(2*s)-1]*/
#define rand_odd_sub_nyquist(N,s) (((rand()%(((N)/(2*s))))*2*(s))+(s))

/*Generates random numbers in the interval [0:2^p-1] */
#define rand_all(N) (rand()&((N)-1))

/*the pi function for spectral permutation*/
#define pi_f(i, sigma, b, N)  (((sigma)*((i)-(b)))&((N)-1))
#define pi_f2(i, sigma, N)  (((sigma)*((i)))&((N)-1))

/*the pi^(-1) function for spectral permutation*/
#define inv_pi_f(i, sigma1, b, N) (((sigma1)*(i)+(b))&((N)-1))
#define inv_pi_f2(i, sigma1, N) (((sigma1)*(i))&((N)-1))

/*the h function for spectral permutation*/
#define h_fr(i, sigma, b, N, B) (((uint32_t)(round(((double)(pi_f((i),(sigma),(b),(N)))*(double)(((B))))/(double)(N)))))
#define h_ff(i, sigma, b, N, B) (((uint32_t)(floor(((double)(pi_f((i),(sigma),(b),(N)))*(double)(((B))))/(double)(N)))))
#define h_fc(i, sigma, b, N, B) (((uint32_t)(ceil(((double)(pi_f((i),(sigma),(b),(N)))*(double)(((B))))/(double)(N)))))

#define o_f(i,sigma,b,N,B) (pi_f((i), (sigma), (b), (N))-h_f((i), (sigma), (b), (N), (B))*(N/B))

 double sinc(double x);
  double normcdf(double x);
#endif				// UTILS_H_INCLUDED

/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include "hash-to-bins.h"
#include "flat-windows.h"
#include "utils.h"
#include <stdlib.h>
#include <search.h>

#include <stdio.h>
#include <math.h>
#ifdef IS_IPP
#include <ippvm.h>
#endif

#include <omp.h>



/*Adds the estimated values to the current estimation*/
void
add_values(double complex * z_hat,
           uint32_t * wz_hat,
           uint32_t * suppz_hat, const void *w_hat, uint32_t supp_w_hat)
{


     uint32_t jj, index;

     size_t aux_suppz_hat;

     void *aux_p;

     uint8_t *X_wk, *wk;

     double complex value;

     /*Pointers to estimated values and frequency indexes */
     X_wk = (uint8_t *) w_hat;
     wk = ((uint8_t *) (w_hat)) + sizeof(double complex);

     for (jj = 0; jj < supp_w_hat; jj++) {
          value =
               *((double complex *) (X_wk +
                                     jj * (sizeof(double complex) +
                                           sizeof(uint32_t))));
          index =
               *((uint32_t *) (wk +
                               jj * (sizeof(double complex) +
                                     sizeof(uint32_t))));

          /*Finds indexes */
          aux_suppz_hat = *suppz_hat;
          aux_p =
               lsearch(&index, wz_hat, &aux_suppz_hat, sizeof(uint32_t),
                       compare_index);
          *suppz_hat = aux_suppz_hat;

          /*Adjusts estimation */
          z_hat[(uint32_t) ((uint32_t *) aux_p - wz_hat)] += value;


     }

}



/*Compare function for sparse components ordering*/
int32_t compare_complex(const void *a, const void *b)
{

     double complex x = *(double complex *) a;
     double complex y = *(double complex *) b;

     if (cabs(x) < cabs(y))
          return 1;
     else if (cabs(x) > cabs(y))
          return -1;
     return 0;


}

/*Compare function for median computation*/
int32_t compare_ascending(const void *a, const void *b)
{

     double x = *(double *) a;
     double y = *(double *) b;

     if (x < y)
          return -1;
     else if (x > y)
          return 1;
     return 0;


}




/*Median computation*/
double median(double *x, uint32_t N)
{

     uint32_t k;

     double *aux;

     aux = x;



     double m;


     /*Half inex */
     k = N >> 1;


     /*Sorts the array */
     qsort(aux, N, sizeof(double), compare_ascending);

     /*Middle point */
     m = x[k];

     /*If array length is even */
     if (!(N & 1))
          m = (x[k] + x[(k - 1)]) / 2.0;

     return m;


}




//uint32_t estimate_values(const double complex *x, /*Input signal*/
//                  const double complex *z_hat, /*Value of the estimated sparse components*/
//                const uint32_t *wz_hat, /*Frequency bins of the estimated sparse components*/
//                const uint32_t suppz_hat, /*Size of wz_hat*/
//                const uint32_t *L, /*Frequency bins to estmate*/
//                uint32_t NL, /*Size of L*/
//                uint32_t N, /*log2(N) where N is the signal length*/
//                uint32_t B,double alpha,double delta, /*Flat window parameters*/
//                uint32_t k_prime, uint32_t Rest,
//               void * w_hat  /*Return vector: {real(X_wk), imag(X_wx), wk ...}*/
//                  ){
//
//
//                      uint32_t jj,rr;
//
//                      uint32_t ar,br,sigmar,index;
//
//                      double  **u_hat_corrected_r,**u_hat_corrected_i,theta,ctheta,stheta;
//
//                      double complex *u_hat;
//
//                      uint8_t * X_wk,*wk;
//
//
//    uint32_t suppw;
//    uint32_t one_index,zero_index;
//    double sigmaw,C;
//
//
//                      u_hat_corrected_r=(double **)malloc(NL*sizeof(double  *));
//                      u_hat_corrected_i=(double **)malloc(NL*sizeof(double  *));
//
//                      for(jj=0;jj<NL;jj++){
//                          u_hat_corrected_r[jj]=(double  *)malloc((Rest)*sizeof(double ));
//                          u_hat_corrected_i[jj]=(double  *)malloc((Rest)*sizeof(double ));
//                      }
//
//                        u_hat=(double complex *)malloc(B*sizeof(double complex ));
//
//
//                        /*Compute window parameters*/
//    window_parameters(N, B, alpha, delta, &sigmaw, &C, &suppw,&one_index,&zero_index);
//
//
//                      for(rr=0;rr<Rest;rr++){
//
//                          /*Spectral permutation parameters*/
//                          ar=rand_all(N);
//                          br=rand_all(N);
//                          sigmar=rand_odd(N);
//
//                          /*Hash to bins call*/
//                          hash_to_bins(x, /*Input signal*/
//                                        z_hat, /*Value of the estimated sparse components*/
//                                        wz_hat, /*Frequency bins of the estimated sparse components*/
//                                        suppz_hat, /*Number of recovered sparse components*/
//                                        N, /*log2(N) where N is the signal length*/
//                                        B, suppw,one_index,zero_index,sigmaw,C, /*Flat window parameters*/
//                                        sigmar, ar, br,  /*Spectral permutation parameters*/
//                                        u_hat /*Return vector with hahses, length B*/
//                                        );
//                             /*Corrected values*/
//                             for(jj=0;jj<NL;jj++){
//                                index=h_f(L[jj], sigmar,br, N, B);
//                                theta=2.0*M_PI*(double)(L[jj]*sigmar*ar)/(double)(N);
//                                ctheta=cos(theta);
//                                stheta=sin(theta);
//                                 u_hat_corrected_r[jj][rr]=creal(u_hat[index])*ctheta-cimag(u_hat[index])*stheta;
//                                 u_hat_corrected_i[jj][rr]=cimag(u_hat[index])*ctheta+creal(u_hat[index])*stheta;
//
//                             }
//
//
//
//                      }
//
//                      free(u_hat);
//
//                      /*Pointers to estimated values and frequency indexes*/
//                      X_wk=(uint8_t *)(w_hat);
//                      wk=(uint8_t *)((w_hat))+sizeof(double complex);
//
//                             /*Median estimator*/
//                             for(jj=0;jj<NL;jj++){
//                            *((uint32_t *)(wk+jj*(sizeof(double complex)+ sizeof(uint32_t))))=L[jj];
//                            *((double complex *)(X_wk+jj*(sizeof(double complex)+ sizeof(uint32_t))))=median((u_hat_corrected_r[jj]), Rest)+I*median((u_hat_corrected_i[jj]), Rest);
//                            free(u_hat_corrected_r[jj]);
//                            free(u_hat_corrected_i[jj]);
//                             }
//
//
//                      free(u_hat_corrected_r);
//                      free(u_hat_corrected_i);
//
//
//                     /*Ordering to get the first k_prime highest values*/
//                      qsort(w_hat, NL, sizeof(double complex)+sizeof(uint32_t),compare_complex);
//
//                      /*number of useful frequency bins*/
//                      return (NL>k_prime)?k_prime: NL;
//
//                  }
//
//
//
//
//
//
//



uint32_t estimate_values2(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          const uint32_t suppz_hat,	/*Size of wz_hat */
                          const uint32_t * L,	/*Frequency bins to estmate */
                          uint32_t NL,	/*Size of L */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw, uint32_t one_index, uint32_t zero_index,	/*Flat windows parameters */
                          uint32_t k_prime, uint32_t Rest, void *w_hat	/*Return vector: {real(X_wk), imag(X_wk), wk ...} */
                         )
{


     uint32_t jj, rr;

     uint32_t ar, sigmar, index;

     double **u_hat_corrected_r, **u_hat_corrected_i;
     double complex *u_hat;


     double theta, ctheta, stheta;


     double twiddle;

     double filter_value;

     uint32_t index_filter,hashed_to;

     uint8_t *X_wk, *wk;

     twiddle = TWO_PI / N;




     u_hat_corrected_r = (double **) malloc(NL * sizeof(double *));
     u_hat_corrected_i = (double **) malloc(NL * sizeof(double *));


     /*Allocates memory for */
     for (jj = 0; jj < NL; jj++) {
          u_hat_corrected_r[jj] =  (double *) malloc((Rest) * sizeof(double));
          u_hat_corrected_i[jj] =    (double *) malloc((Rest) * sizeof(double));

     }

     /*Pointers to estimated values and frequency indexes */
     X_wk = (uint8_t *) (w_hat);
     wk = (uint8_t *) ((w_hat)) + sizeof(double complex);


    
   #ifndef WITH_OPENMP
u_hat =(double complex *) malloc((B) * sizeof(double complex));

#endif



     /*For each located bin */
     #ifdef WITH_OPENMP
    #pragma omp parallel  for private(jj,rr,u_hat,ar,sigmar,index,index_filter,filter_value,theta,ctheta,stheta)
    #endif
     for (rr = 0; rr < Rest; rr++) {

   #ifdef WITH_OPENMP
u_hat =(double complex *) malloc((B) * sizeof(double complex));

#endif


         
          /*For each estimation iteration */
          /*Spectral permutation parameters */
          ar = rand_all(N);

          //br = rand_all(N);
          //br=0;
          sigmar = rand_odd(N);
          //sigmar = rand_odd_sub_nyquist(N,3);
      












          /*Hash to bins call */
          hash_to_bins_locate(x,	/*Input signal */
                        z_hat,	/*Value of the estimated sparse components */
                        wz_hat,	/*Frequency bins of the estimated sparse components */
                        suppz_hat,	/*Number of recovered sparse components */
                        N,	/*log2(N) where N is the signal length */
                        G, G_hat, B, suppw, one_index, zero_index,	/*Flat windows parameters */
                        sigmar, ar,	/*Spectral permutation parameters */
                        u_hat	/*Return vector with hahses, length B */
                       );

          for (jj = 0; jj < NL; jj++) {

               /*Corrected values */

               theta = twiddle * (L[jj] * sigmar * ar);

#ifdef IS_IPP

               ippsSinCos_64f_A26((double *) &theta, (double *) &stheta,
                                  (double *) &ctheta, 1);

#else
               ctheta = cos(theta);
               stheta = sin(theta);
#endif



               //index = h_fr(L[jj], sigmar, br, N, B);



                hashed_to=pi_f2(L[jj], sigmar, N);
                index= (uint32_t)round(((double)(uint64_t)hashed_to*(uint64_t)B)/(double)N);
                //index= (uint32_t)(((double)(uint64_t)hashed_to*(uint64_t)B)/(double)N);

               index_filter =
                    abs(hashed_to - index * (N / B));
               index = index & (B - 1);


               filter_value = 1.0;
               if ((((index_filter)) >= one_index)
                         && (((index_filter)) <= zero_index))
                    filter_value = G_hat[index_filter - one_index];



               u_hat_corrected_r[jj][rr] =(creal(u_hat[index]) * ctheta - cimag(u_hat[index]) * stheta) / filter_value;
               u_hat_corrected_i[jj][rr] = (cimag(u_hat[index]) * ctheta +  creal(u_hat[index]) * stheta) / filter_value;

             //  u_hat_corrected_r[jj][rr] =creal(u_hat[index]) / filter_value;
             //  u_hat_corrected_i[jj][rr] = cimag(u_hat[index]) / filter_value;

          }



   #ifdef WITH_OPENMP
  free(u_hat);

#endif




     }

   #ifndef WITH_OPENMP
  free(u_hat);

#endif






#ifdef WITH_OPENMP
     #pragma omp parallel for private(jj)
    #endif
     for (jj = 0; jj < NL; jj++) {
          /*Median estimator */
          *((uint32_t *) (wk +
                          jj * (sizeof(double complex) +
                                sizeof(uint32_t)))) = L[jj];
          *((double complex *) (X_wk +
                                jj * (sizeof(double complex) +
                                      sizeof(uint32_t)))) =
                                           median((u_hat_corrected_r[jj]),
                                                  Rest) + I * median((u_hat_corrected_i[jj]), Rest);
          free(u_hat_corrected_r[jj]);
          free(u_hat_corrected_i[jj]);
     }


     /*Ordering to get the first k_prime highest values */
     qsort(w_hat, NL, sizeof(double complex) + sizeof(uint32_t),           compare_complex);

     /*number of useful frequency bins */
     return (NL > k_prime) ? k_prime : NL;

}




uint32_t estimate_values_gaussian(const double complex * x,	/*Input signal */
                          const double complex * z_hat,	/*Value of the estimated sparse components */
                          const uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
                          const uint32_t suppz_hat,	/*Size of wz_hat */
                          const uint32_t * L,	/*Frequency bins to estmate */
                          uint32_t NL,	/*Size of L */
                          uint32_t N,	/*log2(N) where N is the signal length */
                          const double *G, const double *G_hat, uint32_t B, uint32_t suppw,  uint32_t zero_index,	/*Flat windows parameters */
                          uint32_t k_prime, uint32_t Rest, void *w_hat	/*Return vector: {real(X_wk), imag(X_wk), wk ...} */
                         )
{


     uint32_t jj, rr;

     uint32_t ar, sigmar, index;

     double **u_hat_corrected_r, **u_hat_corrected_i;
     double complex *u_hat;


     double theta, ctheta, stheta;


     double twiddle;

     double filter_value;

     uint32_t index_filter,hashed_to;

     uint8_t *X_wk, *wk;

     twiddle = TWO_PI / N;




     u_hat_corrected_r = (double **) malloc(NL * sizeof(double *));
     u_hat_corrected_i = (double **) malloc(NL * sizeof(double *));


     /*Allocates memory for */
     for (jj = 0; jj < NL; jj++) {
          u_hat_corrected_r[jj] =  (double *) malloc((Rest) * sizeof(double));
          u_hat_corrected_i[jj] =    (double *) malloc((Rest) * sizeof(double));

     }

     /*Pointers to estimated values and frequency indexes */
     X_wk = (uint8_t *) (w_hat);
     wk = (uint8_t *) ((w_hat)) + sizeof(double complex);





#ifdef WITH_OPENMP
#pragma omp parallel
#endif
 {
     /*For each located bin */
     #ifdef WITH_OPENMP
    #pragma omp  for private(jj,rr,u_hat,ar,sigmar,index,index_filter,filter_value,theta,ctheta,stheta)
    #endif
     for (rr = 0; rr < Rest; rr++) {
          /*For each estimation iteration */
          /*Spectral permutation parameters */
          ar = rand_all(N);

          //br = rand_all(N);
          //br=0;
          sigmar = rand_odd(N);
          //sigmar = rand_odd_sub_nyquist(N,3);
          u_hat =(double complex *) malloc((B) * sizeof(double complex));












          /*Hash to bins call */
          hash_to_bins_gaussian(x,	/*Input signal */
                        z_hat,	/*Value of the estimated sparse components */
                        wz_hat,	/*Frequency bins of the estimated sparse components */
                        suppz_hat,	/*Number of recovered sparse components */
                        N,	/*log2(N) where N is the signal length */
                        G, G_hat, B, suppw, zero_index,	/*Flat windows parameters */
                        sigmar, ar,	/*Spectral permutation parameters */
                        u_hat	/*Return vector with hahses, length B */
                       );

          for (jj = 0; jj < NL; jj++) {

               /*Corrected values */

               theta = twiddle * (L[jj] * sigmar * ar);

#ifdef IS_IPP

               ippsSinCos_64f_A26((double *) &theta, (double *) &stheta,
                                  (double *) &ctheta, 1);

#else
               ctheta = cos(theta);
               stheta = sin(theta);
#endif



               //index = h_fr(L[jj], sigmar, br, N, B);



                hashed_to=pi_f2(L[jj], sigmar, N);
                index= (uint32_t)(((double)(uint64_t)hashed_to*(uint64_t)B)/(double)N + 0.5);

               index_filter =
                    abs(hashed_to - index * (N / B));
               index = index & (B - 1);


               filter_value = 1.0;
               if ((((index_filter)) <= zero_index))
                  filter_value = G_hat[index_filter];



               u_hat_corrected_r[jj][rr] =(creal(u_hat[index]) * ctheta - cimag(u_hat[index]) * stheta) / filter_value;
               u_hat_corrected_i[jj][rr] = (cimag(u_hat[index]) * ctheta +  creal(u_hat[index]) * stheta) / filter_value;

             //  u_hat_corrected_r[jj][rr] =creal(u_hat[index]) / filter_value;
             //  u_hat_corrected_i[jj][rr] = cimag(u_hat[index]) / filter_value;

          }


  free(u_hat);




     }





#ifdef WITH_OPENMP
     #pragma omp for private(jj)
     #endif
     for (jj = 0; jj < NL; jj++) {
          /*Median estimator */
          *((uint32_t *) (wk +
                          jj * (sizeof(double complex) +
                                sizeof(uint32_t)))) = L[jj];
          *((double complex *) (X_wk +
                                jj * (sizeof(double complex) +
                                      sizeof(uint32_t)))) =
                                           median((u_hat_corrected_r[jj]),
                                                  Rest) + I * median((u_hat_corrected_i[jj]), Rest);
          free(u_hat_corrected_r[jj]);
          free(u_hat_corrected_i[jj]);
     }

}
     /*Ordering to get the first k_prime highest values */
     qsort(w_hat, NL, sizeof(double complex) + sizeof(uint32_t),           compare_complex);

     /*number of useful frequency bins */
     return (NL > k_prime) ? k_prime : NL;

}

#ifndef __HELPERS_H__
#define __HELPERS_H__

#include <string>

std::string CollapseCommand(int argc, char** argv);

#endif

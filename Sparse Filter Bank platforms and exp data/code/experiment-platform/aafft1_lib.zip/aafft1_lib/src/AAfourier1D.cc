/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using namespace std;

#include <iostream>
#include <vector>
#include <algorithm>
#include <complex>
#include <math.h>
#include <fftw3.h>
#include "AAarith_prog.h"
#include "AADFT_engine.h"
#include "AAmulti_array.h"
#include "AAparameters.h"

// Function implementing Bulk Sampling as per lemma.  The function takes 6 passed inputs.  They are:
// 1.)  First input is a Parameters structure.  It contains constants used by the function such as the desired sample precision, etc..  
// 2.)  Second input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.
// 3.)  Third input is an arithmatic progression.  It defines the sample points where we want to determine the value of the inverse DFT
//      of the second input ( the L term DFT representation of a signal ).
// 4.)  The fourth arguement is the number of terms wanted from the arithmatic progression ( number of sample points we want to use ).
// 5.)  Fifth input is a vector of complex numbers where the values of the inverse DFT of the passed L term representation (second input)
//      are stored.  Resulting_Sample[i] contains the inverse DFT's value at the ith sample point determined by the passed arithmatic 
//      progression (the third passed input).
// 6.)  A DFT_engine for computing the inverse DFT of complex arrays containing R = (Roots_Coef)*(passed #sample points) values.
// 7.)  Seventh input is a rule for assigning a Plan_Pair in the passed DFT_engine given a input vector size we want the inverse DFT of.  
// NOTE:  WE ASSUME THAT IF NO FUNCTION (7th input) IS PASSED THAT THE 0TH Plan_Pair WILL WORK.  IF A FUNCTION IS PASSED, WE ASSUME THAT
// IT WILL WORK CORRECTLY WITH THE PASSED DFT_engine.  THIS IS THE USER'S RESPONSIBILITY!
void Fast_Bulk_Sample( const Parameters& Parms, const vector<Rep_Term>& Representation, Arith_Prog& Sample_Points, 
     const unsigned Num_Sample_Points, vector< complex<double> >& Resulting_Sample, DFT_engine& Inverse_DFT, 
     unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  const unsigned R = Parms.get_Roots_Coef()*Num_Sample_Points;  // We expand f_k(x) = Exp[2*Pi*i*x*k/Parms.Signal_Size] in a Taylor series 
                 // about some number r*(Parms.Signal_Size)/R, for some r < R, for every k < Num_Sample_Points.
  const complex<double> c_zero(0.0,0.0);             // Complex 0 used for initialization of Inverse_DFT_Coef sub-vectors.
  const complex<double> Two_Pi_I_Samp = I*(double)(2.0*M_PI)/(double)Parms.get_Signal_Size();// Constant representing 2*Pi*i/(signal size).
  const double Sqrt_Signal_Size = sqrt((double)Parms.get_Signal_Size() );  // Square root of the signal size.  Used in computations below.
  const double Sig_Size_div_R = (double)Parms.get_Signal_Size() / (double)R; // Holds Signal_Size / R for later computations.
  double Big_Product;  // Holds product which is > 2^32 for integers > 2^16.
  double Big_Product_Mod_Sig_Size;  // Approximates the Big_Product mod Signal_Size.
  unsigned min_r;   // The r < R which minimizes |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| for representation's ith frequency.
  double zero_val;  // The unique value which makes |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| = 0 for a given frequency w.
  Taylor_Compute temp; // A temperary structure used for pushing new Taylor_Compute's back onto the Expansion_List vector below.
  // Variable used to hold powers of (2*Pi*I*k)/Signal_Size for each k < Num_Sample_Points.  Used in computing the resulting sample.
  complex<double> Final_Expansion_Coef;
  // This vector will contain one sub-vector for every r s.t. 0 <= r < R.  Each sub-vector (for an r < R) will contain a list of the 
  // the d_l(w) and t_l(w) entries for all frequencies w with t_l(w) = |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| minimized.
  static vector< vector<Taylor_Compute> > Expansion_List;  
  // The Inverse_DFT_Coef vector below holds the coefficients for inverse DFT calculations done on the rearranged Taylor series.  For
  // example, the vector Inverse_DFT_Coef[i] holds the series of values a_0_i, a_1_i, a_2_i, a_3_i, ... from the Bulk Sampling Lemma.
  static vector< vector< complex<double> > > Inverse_DFT_Coef;

  // Resize the Expansion_List vector to the correct size.
  Expansion_List.resize( R );

  // Resize the Inverse_DFT_Coef vector to the correct size.
  Inverse_DFT_Coef.resize( Parms.get_Num_Fast_Bulk_Samp_Taylor_Terms() );

  // Resize each of the vectors contained in the Inverse_DFT_Coef vector to the correct size.
  for( unsigned i = 0; i < Inverse_DFT_Coef.size(); i++ )
  { 
    // Size the sub-vector to the correct size.
    Inverse_DFT_Coef[i].resize( R );

    // Initialize the sub-vector to 0
    Inverse_DFT_Coef[i].assign( R, c_zero );
  }

  // Clear all the vectors in the Expansion_List
  for( unsigned i = 0; i < R; i++ )
    Expansion_List[i].clear();

  // Size the Resulting_Sample vector correctly if it's not already large enough.
  if( Resulting_Sample.size() < Num_Sample_Points )
    Resulting_Sample.resize( Num_Sample_Points );  

  // Intialize the Resulting_Sample vector.
  for( unsigned i = 0; i < Num_Sample_Points; i++ )
    Resulting_Sample[i] = c_zero;

  // Find the r < R minimizing |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| for each frequency 'w' in the Representation.
  for( unsigned i = 0; i < Representation.size(); i++ )
  {
    Big_Product = (double)Representation[i].frequency * (double)Sample_Points.get_slope();  // Holds product which is > 2^32 for integers > 2^16.
    Big_Product_Mod_Sig_Size = fmod( Big_Product, (double)Parms.get_Signal_Size() );        // Approximates the Big_Product mod Signal_Size.

    // If WHICH_PLAN_PAIR is NULL, default to the 1th DFT plan_pair in the Bulk_Sample function.  The 0th default is saved for plan_pairs
    // Calculate the unique zero of |Sample_Points.get_slope()*frequency - r*Num_Sample_Points/R| for r.
    zero_val = Big_Product_Mod_Sig_Size / Sig_Size_div_R;

    if( abs( Big_Product_Mod_Sig_Size - floor(zero_val)*Sig_Size_div_R ) > abs( Big_Product_Mod_Sig_Size - (double)((unsigned)ceil(zero_val) % R) * Sig_Size_div_R ) )
      min_r = (unsigned)ceil( zero_val ) % R; // ceil() can cause min_r to = R!
    else
      min_r = (unsigned)floor( zero_val );

    // Save d_l(frequency) and t_l(frequency) in the proper Expansion_List vector.
    temp.d_l = exp( Two_Pi_I_Samp*(double)Sample_Points.get_intercept()*(double)Representation[i].frequency );
    temp.d_l = Representation[i].coefficient*temp.d_l / Sqrt_Signal_Size;
    temp.t_l = Big_Product_Mod_Sig_Size - (double)min_r*Sig_Size_div_R;
    temp.next_root = R;
    Expansion_List[min_r].push_back( temp );
  }

  // Make the Expansion_List have a non-empty 0th vector (insert a fake element to serve as the head of our psuedo linked-list if need be).
  if( Expansion_List[0].empty() )
  {
    // Insert a fake 0th frequency term under the 0th root of unity entry.
    temp.d_l = 0.0;
    temp.t_l = 0.0;
    temp.next_root = R;
    Expansion_List[0].push_back( temp );
  }
  
  // Set min_r = 0 and update the Expansion_List's member Taylor_Compute structures' next_root values so that traversing the Expansion_List
  // can be done more quickly.  This will end up making the Expansion_List into a psuedo linked-list. 
  min_r = 0;
  for( unsigned j = 1; j < R; j++ ) 
  {
    // If the Expansion_List[j] sub-vector contains Taylor_Compute structures, remember that it's not empty.
    if( !Expansion_List[j].empty() )
    {
      // Record what this non-empty root of unity is and get ready to record the next one.
      (Expansion_List[min_r])[0].next_root = j;
      min_r = j;
    }
  }

  // Compute the inverse DFT calculation coefficients for the first term of the rearranged Taylor series.
  min_r = 0;
  while( min_r < R )
  {
    // Calculate the non-empty Expansion_List[j] sub-vector's a_j_0 = sum d_l(w_j) over w_j's value.
    for( unsigned l = 0; l < Expansion_List[min_r].size(); l++ )
      // Compute the a_j_0 value for the first term in the rearranged Taylor series by summing the d_l(w_j) terms.
      (Inverse_DFT_Coef[0])[min_r] += (Expansion_List[min_r])[l].d_l;

    // Set min_r to the next non-empty root of unity entry.
    min_r = (Expansion_List[min_r])[0].next_root;
  }

  // Compute all of the inverse DFT calculation coefficients for i >= 1.  We do this by summing products of the two members of the 
  // Taylor_Compute structures stored under each Expansion_List[r] vector (to get the a_r_x value).
  for( unsigned i = 1; i < Inverse_DFT_Coef.size(); i++ ) 
  {
    // For each of the Rearranged Taylor series terms, compute the inverse DFT coefficients.
    min_r = 0;
    while( min_r < R )
    {
      // If the Expansion_List[j] sub-vector contains Taylor_Compute structures, calculate the a_j_i = sum d_l(w_j)*(l_l(w_j)^i over w_j's.
      for( unsigned l = 0; l < Expansion_List[min_r].size(); l++ )
      {
        // Store d_l*(t_l)^i as the new d_l so that we can compute powers of t_l faster later on.
        (Expansion_List[min_r])[l].d_l *= (Expansion_List[min_r])[l].t_l; 

        // Compute the a_j_i value for the ith term in the rearranged Taylor series by summing the d_l(w_j)*(l_l(w_j))^i terms.
        (Inverse_DFT_Coef[i])[min_r] += (Expansion_List[min_r])[l].d_l;
      }

      // Set min_r to the next non-empty root of unity entry.
      min_r = (Expansion_List[min_r])[0].next_root;
    }
  }

  // If no WHICH_PLAN_PAIR function was passed, we assume that a good DFT_engine was passed with the first Plan_Pair being what we need.
  if( WHICH_PLAN_PAIR == NULL )
  {
    // Compute the inverse DFT of every sub-vector of the Inverse_DFT_Coef vector using the first Plan_Pair of the passed DFT_engine.
    for( unsigned i = 0; i < Inverse_DFT_Coef.size(); i++ )
    {
      // Copy the ith sub-vector into the DFT_egine, Take the inverse DFT of the sub-vector, and then get the result back.
      if( !Inverse_DFT.put_data( Inverse_DFT_Coef[i] ) )
        cout << "failed to put data" << endl;
      Inverse_DFT.DFT( 0, 0 );
      if( !Inverse_DFT.get_data( Inverse_DFT_Coef[i] ) )
        cout << "failed to get data" << endl;
    }
  }
  // Here we use the Plan_Pair indicated by the WHICH_PLAN_PAIR function that the user passed in.
  else
  {
    // Compute the inverse DFT of every sub-vector of the Inverse_DFT_Coef vector using the Plan_Pair indicated by WHICH_PLAN_PAIR.
    for( unsigned i = 0; i < Inverse_DFT_Coef.size(); i++ )
    {
      // Copy the ith sub-vector into the DFT_egine, Take the inverse DFT of the sub-vector, and then get the result back.
      Inverse_DFT.put_data( Inverse_DFT_Coef[i] );
      Inverse_DFT.DFT( 0, WHICH_PLAN_PAIR(Inverse_DFT_Coef[i].size()) );
      Inverse_DFT.get_data( Inverse_DFT_Coef[i] );
    }
  }

  // Finially, compute the Resulting_Sample for each sample position as dictated by the arithmatic progression.  To do this we compute
  // the Sample value at the jth sample position by summing down the i entries of Inverse_DFT_Coef[i][j] while scaling appropriately.  This
  // corresponds to taking the Bulk Sampling Lemma's Taylor series expansion for the different values of j. 
  for( unsigned i = 1; i < Num_Sample_Points; i++ )  
  {
    // Initialize the Final_Expansion_Coef variable    
    Final_Expansion_Coef = 1.0;

    // Sum all but the first Taylor series term. 
    for( unsigned j = 1; j < Inverse_DFT_Coef.size(); j++ ) 
    {
      Final_Expansion_Coef *= (Two_Pi_I_Samp*((double)i)) / ((double)j);
      Resulting_Sample[i] += Final_Expansion_Coef*(Inverse_DFT_Coef[j])[i];
    } 

    // Add the 0th term to the Resulting_Sample[i] entry.  Added seperately since we must divide this term by 0! = 1.
    Resulting_Sample[i] += (Inverse_DFT_Coef[0])[i];
  }

  // Compute the 0th Resulting_Sample value.  It'll be (Inverse_DFT_Coef[0])[0] since here i = 0 in all the Final_Expansion_Coef's.
  Resulting_Sample[0] = (Inverse_DFT_Coef[0])[0];
}

// Use simple matrix multiplication to determine a signal sample from a partial fourier representation.  Takes four inputs:
// 1.)  First input is a Parameters structure.  It contains constants used by the function such as the desired sample precision, etc..  
// 2.)  Second input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.
// 3.)  Third input is an arithmatic progression.  It defines the sample points where we want to determine the value of the inverse DFT
//      of the second input ( the L term DFT representation of a signal ).
// 4.)  The fourth arguement is the number of terms wanted from the arithmatic progression ( number of sample points we want to use ).
// 5.)  Fifth input is a vector of complex numbers where the values of the inverse DFT of the passed L term representation (second input)
//      are stored.  Resulting_Sample[i] contains the inverse DFT's value at the ith sample point determined by the passed arithmatic 
//      progression (the third passed input).
void Naive_Bulk_Sample( const Parameters& Parms, const vector<Rep_Term>& Representation, Arith_Prog& Sample_Points, 
                        const unsigned Num_Sample_Points, vector< complex<double> >& Resulting_Sample )
{
  const complex<double> Two_Pi_I_Samp = (double)(2.0*M_PI)*I/(double)Parms.get_Signal_Size();// Constant representing 2*Pi*i/(signal size).
  const double Sqrt_Signal_Size = sqrt((double)Parms.get_Signal_Size() );  // Square root of the signal size.  Used in computations below.
  const complex<double> c_zero(0,0);  // Complex 0 used for initialization.

  // Size the Resulting_Sample vector correctly if it's not already large enough.
  if( Resulting_Sample.size() < Num_Sample_Points )
    Resulting_Sample.resize( Num_Sample_Points );  

  // Intialize the Resulting_Sample vector.
  for( unsigned i = 0; i < Num_Sample_Points; i++ )
    Resulting_Sample[i] = c_zero;

  // Calculate the signal sample via matrix multiplication.
  Sample_Points.reset();
  for( unsigned i = 0; i < Num_Sample_Points; i++ )
  {
    // Work on the ith row.
    for( unsigned j = 0; j < Representation.size(); j++ )
      Resulting_Sample[i] += Representation[j].coefficient*exp( Two_Pi_I_Samp*(double)Representation[j].frequency*
                                                                (double)Sample_Points.get_last_value() );

    // Get the next sample point index value of the arithmatic progression.
    Sample_Points.next();

    // Scale the term by the square root of the signal size.
    Resulting_Sample[i] /= Sqrt_Signal_Size;
  }       
}

// Call the Bulk Sample method which is fastest for the given representation's size.  Takes inputs required for Naive and Fast_Bulk_Sample.
void Bulk_Sample( const Parameters& Parms, const vector<Rep_Term>& Representation, Arith_Prog& Sample_Points, 
     const unsigned Num_Sample_Points, vector< complex<double> >& Resulting_Sample, DFT_engine& Inverse_DFT, 
     unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  // If the number of terms in the representation is small enough, use the naive bulk sample algorithm.  
  if( Representation.size() < Parms.get_Naive_Bulk_Cutoff() )
    Naive_Bulk_Sample( Parms, Representation, Sample_Points, Num_Sample_Points, Resulting_Sample );
  // Otherwise, use the faster version.
  else
    Fast_Bulk_Sample( Parms, Representation, Sample_Points, Num_Sample_Points, Resulting_Sample, Inverse_DFT, WHICH_PLAN_PAIR );
}

// Declare multi-array to hold K-shatterings used during computation.  Should be done once and then re-used during each greedy iteration.
// A K-shattering is a 3-dimensional Multi_Array.  The first dimension corresponds to sample points (along arithmatic progressions),
// the second dimension corresponds to the number of medians we want to estimate norms, and the last dimension holds filter samples.
// The Allocation_Factor should be 0 unless the K-Shattering has had to be redeclared because it was too small (had too little allocated
// memory).  In that case, allocate Allocation_Factor*Num_KShattering_Sample_Points sample possitions, etc. so that it has enough memory.
Multi_Array< complex<double> >* Create_K_Shattering( const Parameters& Parms, const unsigned Allocation_Factor, DFT_engine* Sample_Plans, 
                                                     unsigned (*WHICH_PLAN_PAIR)(unsigned) ) 
{
  Multi_Array< complex<double> >* K_Shattering;  // Pointer to the multi-dimensional array for holding our K-shattering. 

  // Create two vectors of memory and working sizes for the multi_array which will hold our K-shattering {F_k} for 0 <= k <= K - 1.
  vector<unsigned> K_shattering_memory;  // Holds the memory allocated for each dimension of the K_shattering multi-array.
  vector<unsigned> K_shattering_size;    // Holds the working sizes for each dimension of the K_shattering multi-array.
  
  // If this is the first allocation of the K-Shattering, use initial maximum memory constraints.  Otherwise, use the Allocation_Factor.
  if( Allocation_Factor == 0 )
  {
    // Push the proper memory reservations back onto each K_shattering vector if this is the first declaration.
    K_shattering_memory.push_back( Parms.get_Max_KShattering_Sample_Points() );//0th dimension corresponds to samples from filtered signal.
    K_shattering_memory.push_back( Parms.get_Norm_Estimation_Max() ); // 1st dim. corresponds to signal norm estimation samples (lemma 15).
  }
  else
  {
    // Push proper memory reservations back onto each K_shattering vector if we've had to redeclare the K-shattering.
    K_shattering_memory.push_back( Allocation_Factor*Parms.get_Num_KShattering_Sample_Points() ); // 0th dimension corresponds to samples 
                                                                                                  // from filtered signal.
    K_shattering_memory.push_back( Allocation_Factor*Parms.get_Norm_Estimation_Num() ); // 1st dim. corresponds to signal norm 
                                                                                        // estimation samples (lemma 15).
  }

  // Push proper sizes back onto each K_shattering size vector ( these are independent of the passed parameters ).
  K_shattering_size.push_back( Parms.get_Num_KShattering_Sample_Points() );
  K_shattering_size.push_back( Parms.get_Norm_Estimation_Num() );
  K_shattering_memory.push_back( 4 );  // 2nd dimension -- We need 0th cell for F_k(t), 1st cell for F_k(t + offset), 
  K_shattering_size.push_back( 4 );    //                  2nd cell for filter+ sample of F_k, and the 3rd cell for the filter- of F_k.

  // Declare the multi-array to hold the K-shattering.  Use the Sample_Plans engine if it's extensive (has a map from sizes to plans)
  if( WHICH_PLAN_PAIR != NULL )
    K_Shattering = new Multi_Array< complex<double> >( K_shattering_memory, K_shattering_size, Sample_Plans, WHICH_PLAN_PAIR );
  else
    K_Shattering = new Multi_Array< complex<double> >( K_shattering_memory, K_shattering_size );

  // Send the new K_Shattering out into the world!
  return K_Shattering;
}

// Calculate all K-shattering signal values at Parms.Norms_Sample_Points different random locations shifted by the passed Sample_Offset.
// 1.)  The first input is the sample offset wanted.  For Sample_Offset = 0, the K-shattering signals are just randomly sampled.  For a
//      non-zero Sample_Offset, the K-shattering signals are sampled at the original random sample points shifted by the offset -->
//      F_k(Sample_Offset_=_0_rand_sample_point + Sample_Offset) is calculated for all K-shattering signals F_k. 
// 2.)  Second input is a pointer to a multi-dimensional array representing a k-shattering.  We assume it has the structure created by
//      the Create_K_Shattering function above.
// 3.)  Third input is a Parameters structure.  It contains constants used by the function such as the desired sample precision, etc..  
// 4.)  Forth input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.
// 5.)  The fifth input is the signal vector for which we're creating the k-shattering (passed by reference of course).
// 6.)  The sixth input is a boolean variable which tells us if we want new norm sample arithmatic progressions generated or not.
// 7.)  A DFT_engine for computing the inverse DFT of complex arrays having R = (Roots_Coef)*(# K-shattering sample points) values.
// 8.)  Eighth input is a rule for assigning a Plan_Pair in the passed DFT_engine given a input vector size we want the inverse DFT of.  
// NOTE:  WE ASSUME THAT IF NO FUNCTION (8th input) IS PASSED THAT THE 0TH Plan_Pair WILL WORK.  IF A FUNCTION IS PASSED, WE ASSUME THAT
// IT WILL WORK CORRECTLY WITH THE PASSED DFT_engine.  THIS IS THE USER'S RESPONSIBILITY!
// NOTE:  THIS FUNCTION WILL DESTROY AND RECREATE THE K_Shattering IF IT DOESN'T HAVE ENOUGH MEMORY ALLOCATED.  SO, IF EITHER 
// Parms.Num_KShattering_Sample_Points OR Parms.Norm_Estimation_Num CHANGE DURING FREQUENCY IDENTIFICATION, RESULTS WILL BE INVALID!!!!
void Sample_K_Shattering( const unsigned Sample_Offset, Multi_Array< complex<double> >*& K_Shattering, const Parameters& Parms, 
                          const vector<Rep_Term>& Representation, complex<double> (*Signal)(unsigned, int), const bool New_Norm_Samples,
                          DFT_engine* Sample_Plans, unsigned (*WHICH_PLAN_PAIR)(unsigned) ) 
{
  /*static*/ vector<int> Ref;  // Reference vector for our K-Shattering.
  /*static*/ vector< complex<double> > K_Resulting_Sample; // This vector is used to hold the result returned from the Bulk Sample function.
  // We maintain a vector of arithmatic progressions below.  There will be one for every sample we want of each k-shattering signal. 
  static vector<Arith_Prog> Norm_Samples; 
  bool K_Shattering_Too_Small = false;  // Have Parms.Norm_Estimation_Num or Parms.Num_KShattering_Sample_Points have gotten too large 
                                        // so that we have to re-allocate the K-Shattering multi-array?

  // If the Sample_Offset is 0 we create Parms.Norm_Estimation_Num arithmatic progressions.  Each progression corresponds to a random
  // sample location for every signal in our K-shattering.  We then go on to fill the 0th 3rd dimension column with these samples.
  if( Sample_Offset == 0 )
  {
    // Initialize the K-shattering reference vector for filling in 0th cell with unshifted K-shattering signal samples
    Ref.clear();
    Ref.push_back( -1 );
    Ref.push_back( 0 );
    Ref.push_back( 0 );
  }
  // Take shifted samples of the K-shattering along the given vector of arithmatic progressions.
  else
  {
    // Initialize the K-shattering reference vector for filling in 1st cell with K-shattering signal samples shifted by Sample_Offset.
    Ref.clear();
    Ref.push_back( -1 );
    Ref.push_back( 0 );
    Ref.push_back( 1 );
  }  

  // If any of the working sizes have changed, resize our K-shattering to the correct dimensions
  if( K_Shattering->Dim_Size( 0 ) != Parms.get_Num_KShattering_Sample_Points() ) // Has dimension 0's size changed?
    if( !K_Shattering->Resize( 0, Parms.get_Num_KShattering_Sample_Points(), WHICH_PLAN_PAIR ) )
      K_Shattering_Too_Small = true;
  if( K_Shattering->Dim_Size( 1 ) != Parms.get_Norm_Estimation_Num() ) // Has dimension 1's size changed?
    if( !K_Shattering->Resize( 1, Parms.get_Norm_Estimation_Num(), WHICH_PLAN_PAIR ) )
      K_Shattering_Too_Small = true;

  // If our K-Shattering doesn't have enough memory allocated to accomodate the new size requirements, create a larger K-Shattering.
  if( K_Shattering_Too_Small )
  {
    // Destroy the old K_Shattering and allocate a new one with more reserved memory (twice what we need).
    cout << endl << "Redeclaring K-shattering -- Ran out of memory..." << endl;
    delete K_Shattering;
    K_Shattering = Create_K_Shattering( Parms, 2, Sample_Plans, WHICH_PLAN_PAIR ); 
  }

  // If we don't still have a good set of arithmatic progressions already, generate some to use here.  
  // NOTE:  If for some reason the Norm_Estimation_Num changes between a Sample_Offset = 0 and Sample_Offset != 0 run of this function,
  // frequency identification will be invalidated.
  if( New_Norm_Samples || Norm_Samples.size() != Parms.get_Norm_Estimation_Num() )
  {
    // Clear out the Norm_Samples vector of arithmatic progressions.  Each of these progressions will eventually correspond to one sample
    // from each of the K members of our K-shattering.  All of the members of this vector will have the same random invertible element.
    Norm_Samples.clear();

    // Choose the sample locations for the signal we want the K-shattering of.
    Arith_Prog sample_locations( Parms.get_Signal_Size() );

    // Create all sample arithmatic progressions.  The intercept of each progression will be a sample point for each K-shattering signal.
    for( unsigned i = 0; i < Parms.get_Norm_Estimation_Num(); i++ )
    {
      // Save the current arithmatic progression and generate a new random intercept (random sample location for shattering signals)
      Norm_Samples.push_back( sample_locations );
      sample_locations.pick_new_intercept();
    }
  }

  // If there are no terms in our representation, sample from the signal only.
  if( Representation.empty() )
    // Sample the signal with each of the Parms.Norm_Estimation_Num arithmatic progressions.
    for( unsigned i = 0; i < Parms.get_Norm_Estimation_Num(); i++ )
    {
      // Set up the working column of the multi-array to recieve the signal samples.
      Ref[1] = i;
      K_Shattering->Column_Access( Ref );

      // Copy the signal samples into the K-Shattering.
      if( !K_Shattering->Copy_to_Column( Signal, Norm_Samples[i], Sample_Offset, 1.0 / Parms.get_Num_KShattering_Sample_Points() ) )
        cout << "Error Copying Signal Samples to K_Shattering." << endl;
    }
  else
    // Stock the Parms.Norm_Estimation_Num signal progressions.
    for( unsigned i = 0; i < Parms.get_Norm_Estimation_Num(); i++ )
    {
      // Shift the intercept of the ith arithmatic progression by the Offset value calculated at the beginning of this function. 
      Norm_Samples[i].shift_intercept( Sample_Offset );

      // Find resulting sample positions of the passed representation referred to by the ith arithmatic progression.
      Bulk_Sample( Parms, Representation, Norm_Samples[i], Parms.get_Num_KShattering_Sample_Points(), K_Resulting_Sample, *Sample_Plans, 
                   WHICH_PLAN_PAIR );

      // Sample from (Signal - Resulting_Sample) along the ith arithmatic progression.
      Norm_Samples[i].reset();
      for( unsigned j = 0; j < Parms.get_Num_KShattering_Sample_Points(); j++ )
      {
        K_Resulting_Sample[j] = Signal( Norm_Samples[i].get_last_value(), -1 ) - K_Resulting_Sample[j];
        Norm_Samples[i].next();
      }

      // Shift the intercept of the ith arithmatic progression by negative of the Offset value (to return it to its original value).
      Norm_Samples[i].shift_intercept( Parms.get_Signal_Size() - Sample_Offset );

      // Set up the working column of the multi-array to recieve the signal samples.
      Ref[1] = i;
      K_Shattering->Column_Access( Ref );

      // Copy the signal samples into the K-Shattering.
      K_Shattering->Copy_to_Column( K_Resulting_Sample, 1.0 / Parms.get_Num_KShattering_Sample_Points() );
    }
  
  // Compute the inverse DFT of all Parms.Norm_Estimation_Num arithmatic progression samples. Lemma 13 -> this calculates F_k(t + Offset). 
  for( unsigned i = 0; i < Parms.get_Norm_Estimation_Num(); i++ )
  { 
    // Set up the working column and take the inverse DFT.
    Ref[1] = i;
    K_Shattering->Column_Access( Ref );
    K_Shattering->Column_DFT( 0 );
    } 
}

// Identify the dominant frequencies in the signal - the passed representation.  The function takes 7 inputs:
// 1.)  A vector which will hold a list of dominant frequencies.  Any contents it holds will be erased by this function.
// 2.)  A pointer to a K-Shattering.  If the pointer is NULL a K_Shattering will be created.  Otherwise, the existing K-Shattering will
//      be maintained and used for calculations.
// 3.)  Third input is a Parameters structure.  It contains constants used by the function such as the number of norm estimation samples.  
// 4.)  Forth input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.  If the vector is empty we assume the zero representation.
// 5.)  The fifth input is the signal vector for which we're estimating the dominant frequencies.
// 6.)  A DFT_engine for computing the inverse DFT of complex arrays containing R = (Roots_Coef)*(# K-shattering sample points) values.
// 7.)  Seventh input is a rule for assigning a Plan_Pair in the passed DFT_engine given a input vector size we want the inverse DFT of.  
// NOTE:  WE ASSUME THAT IF NO FUNCTION (7th input) IS PASSED THAT THE 0TH Plan_Pair WILL WORK.  IF A FUNCTION IS PASSED, WE ASSUME THAT
// IT WILL WORK CORRECTLY WITH THE PASSED DFT_engine.  THIS IS THE USER'S RESPONSIBILITY!
void Frequency_Identification( vector<unsigned>& Frequency_List, Multi_Array< complex<double> >*& K_Shattering, const Parameters& Parms, 
                               const vector<Rep_Term>& Representation, complex<double> (*Signal)(unsigned, int), DFT_engine* Sample_Plans, 
                               unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  // The number of least significant bits we have to filter for before we have a frequency (most significant bits exhaustively added).
  const unsigned Least_Sig_Bits = (unsigned)ceil( log((double)Parms.get_Signal_Size()) / M_LN2l ) - Parms.get_Exhaustive_Most_Sig_Bits(); 
  const complex<double> Two_Pi_I = (double)(2.0*M_PI)*I; // Constant representing 2*Pi*i.
  double Filter_i_Offset = (double)Parms.get_Signal_Size() / 2.0; // The ith filter's K-shattering sample offset.
  static vector<unsigned> Powers_of_Two;// The ith entry of this vector holds the value 2^i.
  complex<double> Filter_Coef;  // Used for calculating the filtered K-shattering signal samples below.  Also holds median of samples.
  complex<double> Save_Median;  // Used to hold the median of filtered K-shattering signal samples.
  vector<unsigned> Ref0;        // A reference vector for our K-Shattering.
  vector<unsigned> Ref1;        // Another reference vector for our K-Shattering.
  vector<unsigned> Ref2_3;      // And, yet another reference vector for our K-Shattering.
  vector<int> Ref;              // And, what could it be? -- Oh NO -- Another reference vector (the downside of using multi-arrays)

  // If the Power_of_Two vector hasn't been initialized yet, do it now.
  if( Powers_of_Two.empty() )
  {
    // Initialize the 0th cells of the vector to 1
    Powers_of_Two.push_back( 1 );
    
    // Fill in all other values of 2^i for 0 < i <= ceil( log((double)Parms.Signal_Size) + 1
    for( unsigned i = 0; i <= Least_Sig_Bits + Parms.get_Exhaustive_Most_Sig_Bits(); i++ )
      Powers_of_Two.push_back( 2*Powers_of_Two[i] );
  }

  // Initialize the passed vector of frequencies size/values.  We're going to identify 2^Parms.Exhaustive_Most_Sig_Bits frequencies for 
  // every K-shattering signal.  The kth multiple of Parms.Num_KShattering_Sample_Points will have the kth most significant bit offset. 
  Frequency_List.resize( Powers_of_Two[Parms.get_Exhaustive_Most_Sig_Bits()]*Parms.get_Num_KShattering_Sample_Points() );
  for( unsigned i = 0; i < Powers_of_Two[Parms.get_Exhaustive_Most_Sig_Bits()]; i++ )
  {
    const unsigned j_start = i*Parms.get_Num_KShattering_Sample_Points();    // Where should we begin in the loop below?
    const unsigned j_stop = (i+1)*Parms.get_Num_KShattering_Sample_Points(); // Where should we stop in the loop below?
    unsigned init_value = i * Powers_of_Two[Least_Sig_Bits]; // Integer corresponding to all bits being zero exect those of i in 
             // the most significant bit positions (number resulting from i's bits being shifted Least_Sig_Bits to the right).
    // Initialize the ith sequence of Parms.Num_KShattering_Sample_Points frequencies with the proper most significant bit offsets.
    for( unsigned j = j_start; j < j_stop; j++ )
      Frequency_List[j] = init_value;
  }

  // Size the K-shattering reference vectors correctly.
  Ref0.resize(3);
  Ref1.resize(3);
  Ref2_3.resize(3);
  Ref.resize(3);

  // If the passed K_Shattering pointer is NULL, create a k-shattering to be used here.
  if( K_Shattering == NULL )
    K_Shattering = Create_K_Shattering( Parms, 0, Sample_Plans, WHICH_PLAN_PAIR ); 

  // Take the initial fixed round of Parms.Norm_Estimation_Num samples of the K_shattering of the passed signal.
  Sample_K_Shattering( 0, K_Shattering, Parms, Representation, Signal, true, Sample_Plans, WHICH_PLAN_PAIR ); 

  // Calculate the dominant frequency in each K-shattering signal one bit at a time.
  for( unsigned i = 0; i < Least_Sig_Bits; i++ )
  {
    // Sample the K-Shatter with the ith filter's offset.
    Sample_K_Shattering( (unsigned)((double)Parms.get_Signal_Size() - floor(Filter_i_Offset)), K_Shattering, Parms, Representation, Signal,
                         false, Sample_Plans, WHICH_PLAN_PAIR );

    // Set up the K-shattering reference vectors to access the 2nd dimensions 0th and 1st cells respectively. 
    Ref0[2] = 0;
    Ref1[2] = 1;

    // Perform filtering below for every possible combination of the Parms.Exhaustive_Most_Sig_Bits most significant bits of the frequency.
    for( unsigned l = 0; l < Powers_of_Two[Parms.get_Exhaustive_Most_Sig_Bits()]; l++ )
    {
      const unsigned Sig_Bits_Offset = l*Parms.get_Num_KShattering_Sample_Points();  // Offset for setting of most significant bits.

      // Calculate F_k(t)CONVOLUTION[exp(2.Pi.I.Frequency_List[k].t/2^n+1)F+_n(t)] and Signal(t)CONVOLUTION[
      // exp(2.Pi.I.Frequency_List[k].t/2^n+1)F-_n(t)] for each K-shattering signal F_k(t).  We're applying the filters from Lemma 16 here.
      for( unsigned j = 0; j < Parms.get_Norm_Estimation_Num(); j++ )
      {
        // Set up the reference vectors to deal with the jth K-shattering signal samples.
        Ref0[1] = j;
        Ref1[1] = j;
        Ref2_3[1] = j;

        // Calculate all the K-shattering signal filter convolutions with the jth random sample and lth most significant bit settings.
        for( unsigned k = 0; k < Parms.get_Num_KShattering_Sample_Points(); k++ )
        {
          // Set up the reference vectors to access the kth K-shattering signal and calculate the filter coefficient.  The filter 
          // coefficient modulates the signal to zero out both the most significant bit settings and the already determined least 
          // significant bits.  The first line below handels the already found least sig. bits -- the second the most sig. bits.
          // First, shift the filter to account for the previously discovered least significant bits.
          Filter_Coef = 
            exp( Two_Pi_I*(double)(Frequency_List[Sig_Bits_Offset + k] % Powers_of_Two[i + 1]) / ((double)Powers_of_Two[i + 1]) );
          // Second, shift the filter to account for most significant bit settings we're currently assuming.
          Filter_Coef *= 
            exp( Two_Pi_I*(double)(l*Powers_of_Two[Least_Sig_Bits])*floor(Filter_i_Offset) / ((double)Parms.get_Signal_Size()));
          Ref0[0] = k;
          Ref1[0] = k;
          Ref2_3[0] = k;

          // Calculate the F+_i filter convolution with the jth samples from F_k.
          Ref2_3[2] = 2;
          K_Shattering->El_Ref(Ref2_3) = K_Shattering->El_Ref(Ref0) + Filter_Coef*K_Shattering->El_Ref(Ref1);

	  // Calculate the F-_i filter convolution with the jth samples from F_k.
          Ref2_3[2] = 3;
          K_Shattering->El_Ref(Ref2_3) = K_Shattering->El_Ref(Ref0) - Filter_Coef*K_Shattering->El_Ref(Ref1);
        } 
      }
 
      // Find the median (in terms of norms) of the Parms.Norm_Estimation_Num samples for all of the filtered K-shattering signals.
      // Use this information to determine the ith bit of each K-shattering signal's dominant frequency as per Lemma 16.
      for( unsigned k = 0; k < Parms.get_Num_KShattering_Sample_Points(); k++ )
      {
        // Set up a K-shattering reference vector to access the kth vector of Parms.Norm_Estimation_Num F+_i filtered samples.
        Ref[0] = k;
        Ref[1] = -1;
        Ref[2] = 2;
        K_Shattering->Column_Access( Ref );

        // Store the median (in terms of norm) of the samples of the F+_i filtered samples.
        K_Shattering->Column_Median( Filter_Coef, COMPARE_Frequency_Identification );

        // Set up a K-shattering reference vector to access the kth vector of Parms.Norm_Estimation_Num F-_i filtered samples.
        Ref[2] = 3;
        K_Shattering->Column_Access( Ref );

        // Store the median (in terms of norm) of the samples of the F-_i filtered samples.
        K_Shattering->Column_Median( Save_Median, COMPARE_Frequency_Identification );

        // Decide the ith bit of the dominant frequency for the kth K-Shattering signal.
        if( abs(Save_Median) > abs(Filter_Coef) )
          Frequency_List[Sig_Bits_Offset + k] += Powers_of_Two[i];
      } 
    }

    // Calculate next Filter offset value.
    Filter_i_Offset /= 2.0; 
  }

  // Mod all of the dominant frequency list entries out by the signal size to find our final answers.
  for( unsigned k = 0; k < Frequency_List.size(); k++ )
    Frequency_List[k] %= Parms.get_Signal_Size();
}

// Takes the union of two lists of dominant signal frequencies.  Stores the resulting set Result union New_Freqs in the passed Result 
// vector.  It's assumed that the Result vector (1st input) is already sorted and contains each element only once.  The function 
// returns TRUE if the New_Freq list contains an entry not already listed in the Result vector, and FALSE otherwise.  The resulting
// list of New_Freqs frequencies will be sorted.  This is needed in Iterative Bulk Estimation below.
bool Freq_Union( vector<unsigned>& Result, vector<unsigned>& New_Freqs )
{
  const unsigned Original_Size = Result.size();// Holds the original size of the passed Result vector.
  unsigned index1 = 0;                         // Used as an index variable for iterating through the New_Freqs passed vector.
  unsigned index2 = 0;                         // Used as an index variable for iterating through the passed Result vector.
  bool New_Freq_Added = false;                 // Have any new frequencies been added to the Result vector?

  // If there are no entries in the New_Freqs list, return FALSE
  if( New_Freqs.empty() )
    return false;
 
  // Sort the new frequency list.
  sort( New_Freqs.begin(), New_Freqs.end() );

  // Remove duplicate entries from the new frequency list.
  for( unsigned i = 1; i < New_Freqs.size(); i++ )
    if( New_Freqs[index1] != New_Freqs[i] )
    {
      // Save a unique copy of the new entry we just found in the ith position of the New_Freq list.
      index1++;
      New_Freqs[index1] = New_Freqs[i];
    } 

  // Resize the New_Freq list to its new smaller size.
  New_Freqs.resize( index1 + 1 );
  index1 = 0;

  // Merge the two passed vectors and store the result in the Result vector.  At this point both vectors should be sorted.
  while( index1 < New_Freqs.size() )
  {
    // If the original Result vector elements have all been inspected already, add this new frequency to the Result vector.
    if( index2 >= Original_Size )
    {
      // Add the new frequency to the result list and remember that something was added.
      Result.push_back( New_Freqs[index1] );
      index1++;
      New_Freq_Added = true;
    }
    else if( New_Freqs[index1] == Result[index2] )
    {
      // Iterate both the index variables.
      index1++;
      index2++;
    }
    else if( New_Freqs[index1] < Result[index2] )
    {
      // Add the new frequency to the result list and remember that something was added.
      Result.push_back( New_Freqs[index1] );
      index1++;
      New_Freq_Added = true;
    }
    else
      index2++;
  }
      
  // Sort the resulting list if it has changed.
  if( New_Freq_Added )
    sort( Result.begin(), Result.end() );

  // Return TRUE if a new frequency was found, FALSE otherwise.
  return New_Freq_Added;
}

// First input is a Representation vector.  This Representation will have a term added for each of the frequencies listed in the second 
// All_Freqs vector input.  If an All_Freqs frequency term already appears in the Representation vector then the existing Representation 
// term for that frequency will have the same coefficient as before.  Otherwise, frequencies which don't appear in the Representation 
// vector already will have their term's coefficient initialized to zero. We assume that both the Representation and All_Freqs vectors 
// are sorted by frequency.
void Update_Representation_Frequencies( vector<Rep_Term>& Representation, const vector<unsigned>& All_Freqs )
{
  unsigned Rep_Copy_Index = 0;  // Used below for passing through the Rep_Copy vector looking for frequency terms(coefficients).
  vector<Rep_Term> Rep_Copy;   // A copy of the passed Representation used for merging below.

  // If the representation doesn't contain any terms yet, make one for each frequency we've got so far.  
  if( Representation.empty() )
  {
    // Create a new representation term for each passed frequency.
    Representation.resize( All_Freqs.size() );
    for( unsigned i = 0; i < All_Freqs.size(); i++ )
    {
      // Set the new terms frequency and coefficient information.
      (Representation[i]).frequency = All_Freqs[i];
      (Representation[i]).coefficient = 0.0;
    }

    // Send new Representation out into the world.
    return;
  }
  // Copy the Representation for merging with the passed frequency vector.
  else
  {
    // Copy the representation.
    Rep_Copy.resize( Representation.size() );
    for( unsigned i = 0; i < Rep_Copy.size(); i++ )
      Rep_Copy[i] = Representation[i];
  }

  // Add one term to the new representation vector for every frequency in the all_frequencies vector.
  Representation.resize( All_Freqs.size() );
  for( unsigned i = 0; i < All_Freqs.size(); i++ )
  {
    // Set the new terms frequency.
    (Representation[i]).frequency = All_Freqs[i];

    // Look for the frequency in the Old_Representation vector.
    while( Rep_Copy_Index < Rep_Copy.size() && All_Freqs[i] > (Rep_Copy[Rep_Copy_Index]).frequency )
      Rep_Copy_Index++;

    // If we've found a frequency in common between the All_Freqs/Representation frenquencies and the Rep_Copy frequencies,
    // conserve the freq. coefficient (make the Representation term for this frequency have the same coefficient as the old one).
    if( All_Freqs[i] == (Rep_Copy[Rep_Copy_Index]).frequency )
      (Representation[i]).coefficient = (Rep_Copy[Rep_Copy_Index]).coefficient;
    // Otherwise, set the coefficient to zero.
    else
      (Representation[i]).coefficient = 0.0;
  }
}

// Estimate the frequency coefficients of the passed Frequency_List in the DFT of the signal - the passed representation.  Inputs are:
// 1.)  First input is a Parameters structure.  It contains constants used by the function such as the desired coefficient precision, etc. 
// 2.)  A vector of frequencies.  These are the frequencies whose coefficients we want to estimate in the DFT of Signal - Representation.
// 3.)  Third input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.  If the vector is empty we assume the zero representation.
// 4.)  The fourth input is the Signal vector for which we're estimating the Signal DFT's Frequency_List coefficients.
// 5.)  The list of Frequency_Coefs is assumed to be empty (any contents will be erased/ignored during function operation).  After 
//      execution this vector will contain the estimated coefficients for each member of the Frequency_List vector.  The ith element of
//      the Frequency_Coefs vector will contain the coefficient for the ith Frequency_List frequency as one might expect.
// 6.)  Sixth input is DFT_engine for computing the inverse DFT of complex arrays containing R1 = (Roots_Coef)*(#sample points) values and
//      also for computing the DFT of complex arrays containing R2 = (FFCE_Roots_Coef)*(# freq. coef. estimation sample points) values.
// 7.)  Seventh input is a rule for using a Plan_Pair in the passed DFT_engine given a input vector size we want the DFT/inverse DFT of.  
// NOTE:  WE ASSUME THAT IF NO FUNCTION (7th input) IS PASSED THAT THE 1th Plan_Pair WILL WORK TO GIVE THE INVERSE DFT OF R1 ELEMENTS, AND 
// THAT THE 2th Plan_Pair WILL GIVE THE DFT OF R2 ELEMENTS.  IF A FUNCTION IS PASSED, WE ASSUME THAT IT WILL WORK CORRECTLY WITH THE 
// PASSED DFT_engine.  THIS IS THE USER'S RESPONSIBILITY!
void Fast_Frequency_Coefficient_Estimation( const Parameters& Parms, const vector<unsigned>& Frequency_List, 
     const vector<Rep_Term>& Representation, complex<double> (*Signal)(unsigned, int), vector< complex<double> >& Frequency_Coefs, 
     DFT_engine& DFT, unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  // We expand f(x) = Sum(k,0,K)[Signal[Sample_Points(k)]*Exp[2*Pi*i*x*k/Parms.Signal_Size]]in a Taylor series about some number 
  // r*(Parms.Signal_Size)/R, for some r < R, for every x in the Frequency_List*Sample_Points.get_slope().
  const unsigned R = Parms.get_FFCE_Roots_Coef()*Parms.get_Num_FCE_Sample_Points(); 
  const complex<double> c_zero(0,0);             // Complex 0 used for initialization of Inverse_DFT_Coef sub-vectors.
  const complex<double> Neg_Two_Pi_I_Samp = I*(double)(-2.0*M_PI)/(double)Parms.get_Signal_Size(); // Constant = to -2*Pi*i/(signal size).
  // Square root of the signal size / The length of the arithmatic progression.
  const double Sqrt_Sig_Div_AP = sqrt((double)Parms.get_Signal_Size() ) / (double)Parms.get_Num_FCE_Sample_Points();  
  const double Sig_Size_div_R = (double)Parms.get_Signal_Size() / (double)R;                       // Holds Signal_Size / R for later computations.
  // Sample points of the passed Signal and Representation used to estimate the Frequency_List frequency's coefficients.
  Arith_Prog Sample_Points( Parms.get_Signal_Size() );  
  double Big_Product;  // Holds product which is > 2^32 for integers > 2^16.
  double Big_Product_Mod_Sig_Size;  // Approximates the Big_Product mod Signal_Size.
  double zero_val;    // The unique value which makes |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| = 0 for a given frequency w.
  double delta_r1;    // Used to hold floor(zero_val) delta value below.
  double delta_r2;    // Used to hold ceil(zero_val) delta value below.
  // Variable used to hold powers of (-2*Pi*I*delta_r)/Signal_Size.  Used in computing the frequency coeficients.
  complex<double> Final_Expansion_Coef;
  // The DFT_Coef vector below holds the coefficients for the DFT calculations done on the Taylor series.
  static vector< vector< complex<double> > > DFT_Coef;
  // Holds the r, 0 <= r < R, which minimizes |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| for each w in passed Frequency_List.
  static vector< unsigned > Min_r;
  // Holds values of Sample_Points.get_slope()*w - (MINIMIZING ROOT OF UNITY)*Parms.Signal_Size/R for each frequency.
  static vector< double > Delta_r;

  // Resize the DFT_Coef vector to the correct size.
  DFT_Coef.resize( Parms.get_Num_Fast_Freq_Coefnt_Est_Taylor_Terms() );

  // Resize each of the vectors contained in the DFT_Coef vector to the correct size.
  for( unsigned i = 0; i < DFT_Coef.size(); i++ )
  { 
    // Size the sub-vector to the correct size.
    DFT_Coef[i].resize( R );

    // Initialize the sub-vector to 0
    DFT_Coef[i].assign( R, c_zero );
  }

  // Stock DFT_Coef's 0th vector.  If there are no terms in the passed representation, sample from the signal only.
  if( Representation.empty() )
  {
    // Stock DFT_Coef's 0th vector with Signal samples along the given arithmatic progression.
    Sample_Points.reset();
    for( unsigned i = 0; i < Parms.get_Num_FCE_Sample_Points(); i++ )
    {
      (DFT_Coef[0])[i] = Signal( Sample_Points.get_last_value(), -1 );
      Sample_Points.next();
    }
  }    
  else
  {
    // Sample the passed representation at the points referred to by the passed arithmatic progression.
    // If WHICH_PLAN_PAIR is NULL, default to the 1th DFT plan_pair in the Bulk_Sample function.  The 0th default is saved for plan_pairs
    // of size Num_KShattering_Sample_Points ( the parameter in the Parms class ).  
    if( WHICH_PLAN_PAIR == NULL )
      Bulk_Sample( Parms, Representation, Sample_Points, Parms.get_Num_FCE_Sample_Points(), DFT_Coef[0], DFT, ONE );
    else
      Bulk_Sample( Parms, Representation, Sample_Points, Parms.get_Num_FCE_Sample_Points(), DFT_Coef[0], DFT, WHICH_PLAN_PAIR );

    // Stock DFT_Coef's 0th vector with (Signal - representation) samples along the given arithmatic progression.
    Sample_Points.reset();
    for( unsigned i = 0; i < Parms.get_Num_FCE_Sample_Points(); i++ )
    {
      (DFT_Coef[0])[i] = Signal( Sample_Points.get_last_value(), -1 ) - (DFT_Coef[0])[i];
      Sample_Points.next();
    }
  }

  // Stock the DFT_Coef's remaining vectors.
  for( unsigned i = 1; i < DFT_Coef.size(); i++ )
    for( unsigned j = 1; j < Parms.get_Num_FCE_Sample_Points(); j++ )
      (DFT_Coef[i])[j] = (DFT_Coef[i - 1])[j]*(double)j;

  // Take the DFT of each of the DFT_Coef's vectors in order to calculate the sum portion of each Taylor series term for all r < R.
  // If no WHICH_PLAN_PAIR function was passed, we assume that a good DFT_engine was passed with the 1th Plan_Pair being what we need.
  if( WHICH_PLAN_PAIR == NULL )
  {
    // Compute the DFT of every sub-vector of the DFT_Coef vector using the 2th Plan_Pair of the passed DFT_engine.
    for( unsigned i = 0; i < DFT_Coef.size(); i++ )
    {
      // Copy the ith sub-vector into the DFT_egine, Take the DFT of the sub-vector, and then get the result back.
      if( !DFT.put_data( DFT_Coef[i] ) )
        cout << "Fast_Frequency_Coefficient_Estimation:  Failed to put data." << endl;
      DFT.DFT( 1, 2 );
      if( !DFT.get_data( DFT_Coef[i] ) )
        cout << "Fast_Frequency_Coefficient_Estimation:  Failed to get data." << endl;
    }
  }
  // Here we use the Plan_Pair indicated by the WHICH_PLAN_PAIR function that the user passed in.
  else
  {
    // Compute the DFT of every sub-vector of the DFT_Coef vector using the Plan_Pair indicated by WHICH_PLAN_PAIR.
    for( unsigned i = 0; i < DFT_Coef.size(); i++ )
    {
      // Copy the ith sub-vector into the DFT_egine, Take the DFT of the sub-vector, and then get the result back.
      DFT.put_data( DFT_Coef[i] );
      DFT.DFT( 1, WHICH_PLAN_PAIR(DFT_Coef[i].size()) );
      DFT.get_data( DFT_Coef[i] );
    }
  }

  // Correctly size the vector for holding the roots of unity info. we need to Taylor expand around for each frequency. 
  Min_r.resize( Frequency_List.size() );
  Delta_r.resize( Frequency_List.size() );

  // Find the r < R minimizing |Sample_Points.get_slope()*w - r*Parms.Signal_Size/R| for each frequency 'w' in the Frequency_List.
  for( unsigned i = 0; i < Frequency_List.size(); i++ )
  {
    Big_Product = (double)Frequency_List[i] * (double)Sample_Points.get_slope();     // Holds product which is > 2^32 for integers > 2^16.
    Big_Product_Mod_Sig_Size = fmod( Big_Product, (double)Parms.get_Signal_Size() ); // Approximates the Big_Product mod Signal_Size.

    // If WHICH_PLAN_PAIR is NULL, default to the 1th DFT plan_pair in the Bulk_Sample function.  The 0th default is saved for plan_pairs
    // Calculate the unique zero of |Sample_Points.get_slope()*frequency - r*Num_Sample_Points/R| for r.
    zero_val = Big_Product_Mod_Sig_Size / Sig_Size_div_R;

    if( (delta_r1 = abs( Big_Product_Mod_Sig_Size - floor(zero_val)*Sig_Size_div_R )) > 
        (delta_r2 = abs( Big_Product_Mod_Sig_Size - (double)((unsigned)ceil(zero_val) % R) * Sig_Size_div_R )) )
    {
      Min_r[i] = (unsigned)ceil( zero_val ) % R; // ceil() can cause min_r to = R!
      Delta_r[i] = delta_r2;
    }
    else
    {
      Min_r[i] = (unsigned)floor( zero_val );
      Delta_r[i] = delta_r1;
    }
  }

  // Size the Frequency_Coefs vector correctly.
  Frequency_Coefs.resize( Frequency_List.size() );  

  // Intialize the Frequency_Coefs vector.
  for( unsigned i = 0; i < Frequency_List.size(); i++ )
    Frequency_Coefs[i] = c_zero;

  // Compute f(w) for each w in the Frequency_List, where f(x) = a row of the z(b,0) power matrix multiplied by the Signal column. 
  for( unsigned i = 0; i < Frequency_List.size(); i++ )  
  {
    // Initialize the Final_Expansion_Coef variable    
    Final_Expansion_Coef = 1.0;

    // Sum all but the first Taylor series term. 
    for( unsigned j = 1; j < DFT_Coef.size(); j++ ) 
    {
      Final_Expansion_Coef *= Neg_Two_Pi_I_Samp*Delta_r[i] / ((double)j);
      Frequency_Coefs[i] += Final_Expansion_Coef*(DFT_Coef[j])[Min_r[i]];     
    } 

    // Add the 0th term to the Frequency_Coefs[i] entry.  Added seperately since we must divide this term by 0! = 1.
    Frequency_Coefs[i] += (DFT_Coef[0])[Min_r[i]];
  }

  // Finish computing the Frequency_Coefs vector by taking into account the arithmatic progression's intercept.
  for( unsigned i = 0; i < Frequency_Coefs.size(); i++ )
    Frequency_Coefs[i] *= Sqrt_Sig_Div_AP*exp( Neg_Two_Pi_I_Samp*(double)Sample_Points.get_intercept()*(double)Frequency_List[i] );
}

// Estimate the frequency coefficients of the passed Frequency_List in the DFT of the signal - the passed representation.  Inputs are:
// 1.)  First input is a Parameters structure.  It contains constants used by the function such as the signal length, etc. 
// 2.)  A vector of frequencies.  These are the frequencies whose coefficients we want to estimate in the DFT of Signal - Representation.
// 3.)  The third input is the Signal vector for which we're estimating the Signal DFT's Frequency_List coefficients.
// 4.)  Fourth input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.  If the vector is empty we assume the zero representation.
//      We also assume that the Representation vector is sorted by the frequency of each Rep_Term (and that these frequencies = the 
//      frequencies in the passed Frequency_List above).
// 5.)  The list of Frequency_Coefs is assumed to be empty (any contents will be erased/ignored during function operation).  After 
//      execution this vector will contain the estimated coefficients for each member of the Frequency_List vector.  The ith element of
//      the Frequency_Coefs vector will contain the coefficient for the ith Frequency_List frequency as one might expect.
// 6.)  A DFT_engine for computing the inverse DFT of complex arrays containing R = (Roots_Coef)*(# FCE sample points) values.
// 7.)  Seventh input is a rule for assigning a Plan_Pair in the passed DFT_engine given a input vector size we want the inverse DFT of.  
// NOTE:  WE ASSUME THAT IF NO FUNCTION (7th input) IS PASSED THAT THE 1TH Plan_Pair WILL WORK.  IF A FUNCTION IS PASSED, WE ASSUME THAT
// IT WILL WORK CORRECTLY WITH THE PASSED DFT_engine.  THIS IS THE USER'S RESPONSIBILITY!
void Naive_Frequency_Coefficient_Estimation( const Parameters& Parms, const vector<unsigned>& Frequency_List, 
     complex<double> (*Signal)(unsigned, int), const vector<Rep_Term>& Representation, vector< complex<double> >& Frequency_Coefs, 
     DFT_engine& DFT, unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  // Sample points of the passed Signal and Representation used to estimate the Frequency_List frequency's coefficients.
  Arith_Prog Sample_Points( Parms.get_Signal_Size() );  
  const complex<double> c_zero(0,0);             // Complex 0 used for initialization of Frequency_List vector.
  const complex<double> Neg_Two_Pi_I_Div_Sig = I*(double)(-2.0*M_PI) / (double)Parms.get_Signal_Size(); // Const. = to -2*Pi*i/Signal_Size.
  // Square root of the signal size / The length of the arithmatic progression.
  const double Sqrt_Sig_Div_AP = sqrt((double)Parms.get_Signal_Size() ) / (double)Parms.get_Num_FCE_Sample_Points();  
  // Vector for holding samples from the passed Representation along the passed arithmatic progression Sample_Points.
  /*static*/ vector< complex<double> > Naive_Resulting_Sample;

  // Size the Resulting_Sample vector correctly.
  Naive_Resulting_Sample.resize( Parms.get_Num_FCE_Sample_Points() );

  // Sample from the passed representation if it's not empty.  Otherwise, sample from the Signal only.
  if( Representation.empty() )
  {
    // Stock the Resulting_Sample vector with Signal samples along the given arithmatic progression.
    Sample_Points.reset();
    for( unsigned i = 0; i < Parms.get_Num_FCE_Sample_Points(); i++ )
    {
      Naive_Resulting_Sample[i] = Signal( Sample_Points.get_last_value(), -1 );
      Sample_Points.next();
    }
  }
  else
  {
    // Sample the passed representation at the points referred to by the passed arithmatic progression.
    // If WHICH_PLAN_PAIR is NULL, default to the 1th DFT plan_pair in the Bulk_Sample function.  The 0th default is saved for plan_pairs
    // of size Num_KShattering_Sample_Points ( the parameter in the Parms class ).  
    if( WHICH_PLAN_PAIR == NULL )
      Bulk_Sample( Parms, Representation, Sample_Points, Parms.get_Num_FCE_Sample_Points(), Naive_Resulting_Sample, DFT, ONE );
    else
      Bulk_Sample( Parms, Representation, Sample_Points, Parms.get_Num_FCE_Sample_Points(), Naive_Resulting_Sample, DFT, WHICH_PLAN_PAIR );

    // Stock the Resulting_Sample vector with (Signal - representation) samples along the given arithmatic progression.
    Sample_Points.reset();
    for( unsigned i = 0; i < Parms.get_Num_FCE_Sample_Points(); i++ )
    {
      Naive_Resulting_Sample[i] = Signal( Sample_Points.get_last_value(), -1 ) - Naive_Resulting_Sample[i];
      Sample_Points.next();
    }
  }

  // Size the Frequency_Coefs vector correctly.
  Frequency_Coefs.resize( Frequency_List.size() );  

  // Intialize the Frequency_Coefs vector.
  for( unsigned i = 0; i < Frequency_List.size(); i++ )
    Frequency_Coefs[i] = c_zero;

  // Calculate the sum of the weighted sample points for each frequency.
  for( unsigned i = 0; i < Frequency_List.size(); i++ )
  {
    Sample_Points.reset();
    for( unsigned j = 0; j < Parms.get_Num_FCE_Sample_Points(); j++ )
    {
      Frequency_Coefs[i] += Naive_Resulting_Sample[j]*exp( Neg_Two_Pi_I_Div_Sig*(double)Frequency_List[i]*(double)Sample_Points.get_last_value() );
      Sample_Points.next();
    }
  }

  // Scale each entry of the Frequency_Coefs vector in order to end up with the mean of the scaled (Signal - Representation) samples.  
  for( unsigned i = 0; i < Frequency_Coefs.size(); i++ )
    Frequency_Coefs[i] *= Sqrt_Sig_Div_AP;
}

// Declare multi-array to hold frequency estimation weighted signal sample means used during computation.  Should be done once and then 
// re-used during each greedy iteration.  A FCE Median Taker is a 2-dimensional Multi_Array.  The first dimension corresponds to the 
// frequencies whose coefficients we're trying to estimate.  And,  the second dimension corresponds to the number of medians we want to 
// use in estimating each frequency's coefficient.  The passed Max_Frequencies variable should be set to the expected maximum number of 
// frequencies we'll want to estimate coefficients for -- memory will be allocated for that many.  The passed Num_Frequencies is the 
// working size of the 1th frequency dimension that we want.  NOTE:  THE MAXIMUM NUMBER OF MEDIANS TAKEN FOR EACH FREQUENCY 
// (Max_FCE_Medians) IS A HARD UPPER LIMIT.  THIS VARIABLE MUST BE RESET TO INCREASE 1th DIM MEM SIZE.  NOTE:  A NULL DFT_ENGINE POINTER 
// IS PASSED TO MEDIAN_TAKER'S CONSTRUCTOR.  DFT'S CAN'T BE PURFORMED ON COLUMNS WITHOUT BIG PROBLEMS!!!
Multi_Array< complex<double> >* Create_Freq_Coef_Est_Median_Taker( const Parameters& Parms, const unsigned Max_Frequencies, 
                                const unsigned Num_Frequencies ) 
{
  // If bad inputs were given, complain!
  if( Num_Frequencies > Max_Frequencies || Parms.get_Num_FCE_Medians() > Parms.get_Max_FCE_Medians() )
  {
    // Complain and quit early.
    cout << endl << "Bogus inputs given to Create_Freq_Coef_Est_Median_Taker function!" << endl;
    return NULL;
  }
 
  // Create two vectors of memory and working sizes for the 2-dimensional array which will hold our weighted signal sample means.
  vector<unsigned> Median_Taker_memory;  // Holds the memory allocated for each dimension of the median taker 2-D array.
  vector<unsigned> Median_Taker_size;    // Holds the working sizes for each dimension of the median taker 2-D array.

  // Push proper sizes/memory reservations back onto both of Median_Taker's dimensions.
  Median_Taker_memory.push_back( Max_Frequencies ); // 0th dimension -- corresponds to frequencies whose coefficients we want. 
  Median_Taker_size.push_back( Num_Frequencies );
  Median_Taker_memory.push_back( Parms.get_Max_FCE_Medians() ); // 1st dimension corresponds to sample means we're taking the median of. 
  Median_Taker_size.push_back( Parms.get_Num_FCE_Medians() );

  // Declare the multi-array to hold the Median_Taker frequency's weighted sample means and return it.  Note that we pass along an
  // empty dictionary of DFT plans to the multi_array constructor.  This is to save planning time during resizing of dimensions.
  return new Multi_Array< complex<double> >( Median_Taker_memory, Median_Taker_size, NULL, Identity );
}

// Estimate the frequency coefficients of the passed Frequency_List in the DFT of the signal - the passed representation.  This 
// function's primary purpose is to repeatedly call the Naive_Frequency_Coefficient_Estimation or Iterative_Fast_Freq_Coef_Estimation 
// function to get several estimates of each frequency's coefficient (for each Frequency_List frequency).  Median's of these estimates are
// then found (in the real and imaginary component) in order to get an overall estimate for each frequency's coefficient.  Inputs are:
// 1.)  First input is a Parameters structure.  It contains constants used by the function such as the signal length, etc. 
// 2.)  A vector of frequencies.  These are the frequencies whose coefficients we want to estimate in the DFT of Signal - Representation.
// 3.)  Third passed variable = Should we use the Naive_Frequency_Coefficient_Estimation or Iterative_Fast_Freq_Coef_Estimation function?
// 4.)  The fourth input is the Signal vector for which we're estimating the Signal DFT's Frequency_List coefficients.
// 5.)  Fifth input is a Representation vector.  It will be an L term DFT representation of a signal.  Each element of the vector
//      contains a frequency and a coefficient for that frequency.  If the vector is empty we assume the zero representation.
//      We also assume that the Representation vector is sorted by the frequency of each Rep_Term (and that these frequencies = the 
//      frequencies in the passed Frequency_List above).
// 6.)  The list of Frequency_Coefs is assumed to be empty (any contents will be erased/ignored during function operation).  After 
//      execution this vector will contain the estimated coefficients for each member of the Frequency_List vector.  The ith element of
//      the Frequency_Coefs vector will contain the coefficient for the ith Frequency_List frequency as one might expect.
// 7.)  A pointer to a 2-D multi_array which holds all of the frequency coefficients we find.  It's also used to take medians of them.
// 8.)  A DFT_engine for computing the inverse DFT of complex arrays containing R1 = (Roots_Coef)*(#freq. coef. estimation sample points) 
//      values and also for computing the DFT of complex arrays containing R2 = (FFCE_Roots_Coef)*(# freq. coef. est. sample pnts) values.
// 9.)  Ninth input is a rule for using a Plan_Pair in the passed DFT_engine given a input vector size we want the DFT/inverse DFT of.  
// NOTE:  WE ASSUME THAT IF NO FUNCTION (9th input) IS PASSED THAT THE 1th Plan_Pair WILL WORK TO GIVE THE INVERSE DFT OF R1 ELEMENTS, AND 
// THAT THE 2th Plan_Pair WILL GIVE THE DFT OF R2 ELEMENTS.  IF A FUNCTION IS PASSED, WE ASSUME THAT IT WILL WORK CORRECTLY WITH THE 
// PASSED DFT_engine.  THIS IS THE USER'S RESPONSIBILITY!
void Frequency_Coefficient_Estimation( const Parameters& Parms, const vector<unsigned>& Frequency_List, 
     complex<double> (*Signal)(unsigned, int), const vector<Rep_Term>& Representation, vector< complex<double> >& Frequency_Coefs, 
				       Multi_Array< complex<double> >*& Freq_Coef_Estimator, DFT_engine& DFT, unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  vector<int> Ref; // A reference vector for our Freq_Coef_Estimator multi-array.
  complex<double> Real_Median;  // The median of each frequency's Parms.Num_FCE_Medians coefficients with respect to the real components.
  complex<double> Imag_Median;  // The median of each frequency's Parms.Num_FCE_Medians coefficients with respect to the imag components.
 
  // Correctly size the reference vector and set it up for copying frequency coefficients into each of the Num_FCE_Medians freq. vectors 
  Ref.resize(2);
  Ref[0] = -1;

  // If the frequency coefficient estimation median 2-D array pointer is NULL, create an median taker for it to point to.
  if( Freq_Coef_Estimator == NULL )
    // At each iteration of the overall algorithm at most ~(2^Parms.Exhaustive_Most_Sig_Bits)*Parms.Max_KShattering_Sample_Points 
    // frequencies should be found.  Overall, we want to find Parms.Num_Rep_Terms total large frequencies.  So, we guess an upper bound...
    Freq_Coef_Estimator = Create_Freq_Coef_Est_Median_Taker( Parms, 
                          8*(Parms.get_Num_Rep_Terms() + Parms.get_Max_KShattering_Sample_Points()), Frequency_List.size() );
  // Otherwise, size both of the frequency coefficient estimation array's dimensions correctly for the given data.
  else
  {
    // If any of the working sizes have changed, resize our Median Taker to the correct dimensions.
    if( Freq_Coef_Estimator->Dim_Size( 0 ) != Frequency_List.size() ) // Has dimension 0's size changed?
    {
      if( !Freq_Coef_Estimator->Resize( 0, Frequency_List.size(), Identity ) )
      {  
        // If we've gotten here it's because there is currently not enough memory allocated in the Freq_Coef_Estimator for all the 
        // frequencies we want coefficients estimated for.  So, we'll redeclare the Freq_Coef_Estimator with more frequency memory.   
        delete Freq_Coef_Estimator;
        Freq_Coef_Estimator = Create_Freq_Coef_Est_Median_Taker( Parms, 2*Frequency_List.size(), Frequency_List.size() );
      }
    }
    if( Freq_Coef_Estimator->Dim_Size( 1 ) != Parms.get_Num_FCE_Medians() ) // Has dimension 1's size changed?
      Freq_Coef_Estimator->Resize( 1, Parms.get_Num_FCE_Medians(), Identity );
  }

  // Fill in the Freq_Coef_Estimator with frequency coefficient estimates.
  for( unsigned i = 0; i < Parms.get_Num_FCE_Medians(); i++ )
  {
    // If the user wants to use Naive frequency coefficient estimation, use it.
    if( Representation.size() <= Parms.get_Naive_Coef_Est_Cutoff() )
      Naive_Frequency_Coefficient_Estimation( Parms, Frequency_List, Signal, Representation, Frequency_Coefs, DFT, WHICH_PLAN_PAIR );
    // If we're supposed to use fast frequency coefficient estimation, do so.
    else
      Fast_Frequency_Coefficient_Estimation( Parms, Frequency_List, Representation, Signal, Frequency_Coefs, DFT, WHICH_PLAN_PAIR );

    // Set up the working column of the multi-array to recieve frequency coefficient estimates.
    Ref[1] = i;
    Freq_Coef_Estimator->Column_Access( Ref );

    // Copy the frequency coefficient estimates into the median taker.
    Freq_Coef_Estimator->Copy_to_Column( Frequency_Coefs );
  }

  // Set up the reference vectors for taking medians down every frequency entry in the Freq_Coef_Estimator. 
  Ref[1] = -1;

  for( unsigned i = 0; i < Frequency_List.size(); i++ )
  {
    // Set up the working column of the multi-array to take median of each frequency's Parms.Num_FCE_Medians coefficient estimates.
    Ref[0] = i;
    Freq_Coef_Estimator->Column_Access( Ref );

    // Find the median of each frequency's coefficient estimates with respect to their real and imaginary components.
    Freq_Coef_Estimator->Column_Median( Real_Median, COMPARE_real_Freq_Coef_Estimation );    
    Freq_Coef_Estimator->Column_Median( Imag_Median, COMPARE_imag_Freq_Coef_Estimation );

    // Set the final frequency coefficient using the found median values. 
    Frequency_Coefs[i] = complex<double>( Real_Median.real(), Imag_Median.imag() );
  }
}

// AAFFT:  A sample use of the above functions.  We take a provided set of parameter settings, a signal, an (assumed to be empty) Representation 
// vector, and a DFT_Library with associated reference function.  We return the Representation vector stocked with an approximate discrete
// fourier transform of the given signal.  This function could be improved!  Dynamic changes to certain parameter settings based on 
// progress made in finding a good representation could be fruitful!!!!
void Fast_DFT( const Parameters& Parms, complex<double> (*Signal)(unsigned, int), vector<Rep_Term>& Representation, 
               DFT_engine* DFT, unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  //DFT_engine* DFT;  // A pointer to the DFT_engine we want to use below.  Will be the passed DFT_Library if WHICH_PLAN_PAIR != NULL.
  //bool DFT_Library_Useless = false;  // Is the DFT_Library not well defined ( WHICH_PLAN_PAIR is NULL )?
  bool Rep_Sorted_By_Coef = false;   // Is the Representation array currently sorted by frequency coefficient norm?
  Multi_Array< complex<double> >* K_Shattering = NULL;        // Used by the Frequency_Identification function below.
  Multi_Array< complex<double> >* Freq_Coef_Estimator = NULL; // Used by the Frequency_Coefficient_Estimation function below.
  vector<unsigned> Freq_List;  // The list of frequencies found by the Frequency_Identification function during each identification step.
  vector<unsigned> ALL_FREQS;  // The total list of largest frequencies discovered by all frequency identification steps done so far.
  vector< complex<double> > Freq_Coefs;  // The list of coefficients found for the Signal - Representation.

  // Resize the Representation to 0 to start with ( the 0 representation ).
  Representation.resize( 0 );

  // Search for large frequencies and estimate their coefficients.
  for( unsigned index = 0; index < Parms.get_Num_FreqID_CoefEst_Iterations(); index++ )
  {
    // Find large frequencies in the Signal - the current representation.
    Frequency_Identification( Freq_List, K_Shattering, Parms, Representation, Signal, DFT, WHICH_PLAN_PAIR );

    // Add any newly discovered frequencies to the total list of large frequencies found so far.  If no new frequencies have been added,
    // we don't bother to re-estimate frequency coefficients.
    if( Freq_Union( ALL_FREQS, Freq_List ) )
    {
      // Add any new frequencies we've managed to find to the Representation.
      Update_Representation_Frequencies( Representation, ALL_FREQS );

      // Estimate the coefficients of the frequencies in the Representation using Parms.FFCE_Iterations number of estimates.
      for( unsigned i = 0; i < Parms.get_FFCE_Iterations(); i++ )
      {
        // Estimate the Representation's frequency coefficients for the ith time.
        Frequency_Coefficient_Estimation(Parms, ALL_FREQS, Signal, Representation, Freq_Coefs, Freq_Coef_Estimator, *DFT, WHICH_PLAN_PAIR);

        // Add the correction just found to each frequency coefficient in the Representation.
        for( unsigned j = 0; j < Representation.size(); j++ )
          (Representation[j]).coefficient += Freq_Coefs[j];
      }

      // If we've found more Representation terms than we're interested in, discard the ones with smallest coefficient norms.
      if( Representation.size() > Parms.get_Working_Rep_Terms() )
      {      
        // Throw out all representation terms but the ones with the largest frequency coefficients.
        sort( Representation.begin(), Representation.end(), REP_TERM_COEF_GREATER_THAN );
        Representation.resize( Parms.get_Working_Rep_Terms() );        
        Rep_Sorted_By_Coef = true;
      }

      // If we're going to be doing more frequency identification rounds, update the vector of frequencies in the representation.
      if( index < (Parms.get_Num_FreqID_CoefEst_Iterations() - 1) )
      {
        // Re-sort the representation by frequency and update the ALL_FREQS vector.
        sort( Representation.begin(), Representation.end(), REP_TERM_FREQ_LESS_THAN );
        ALL_FREQS.resize( 0 );
        for( unsigned i = 0; i < Representation.size(); i++ )
          ALL_FREQS.push_back( (Representation[i]).frequency );
	Rep_Sorted_By_Coef = false;
      }
    }
  }

  // If the Representation isn't already sorted by frequency coefficient norms, do so now.
  //if( !Rep_Sorted_By_Coef )
  //  sort( Representation.begin(), Representation.end(), REP_TERM_COEF_GREATER_THAN );

  // Clean up the K_Shattering and Freq_Coef_Estimator which are allocated by 'new' through function calls above.
  delete K_Shattering;
  delete Freq_Coef_Estimator;

  // If we had to create an adhoc DFT_engine for this function, delete it now.
  //if( DFT_Library_Useless )  
  //  delete DFT;
}

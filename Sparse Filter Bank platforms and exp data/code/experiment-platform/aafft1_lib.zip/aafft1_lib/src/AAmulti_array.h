/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef MULTI_ARRAY_H
#define MULTI_ARRAY_H

#include "AAarith_prog.h"

const int MARKIWEN = 1;

// Class for a Multi-Dimensional array.  The number of dimensions and the size of each dimension may be declared by the user.  Access
// to any row/column of the multi-dimensional array is allowed and several operations can be performed on any row/column.  Those
// operations include: average of a row/column, median of a row/column, and DFT of a row/column.  
template<class MULTI_ARRAY_DATA_TYPE>
class Multi_Array
{
  public:
    // Empty Constructor for the Multi_Array class.  This will initialize the data elements to default values.
    Multi_Array( void );
    // Constructor that creates a Multi_Array with the dimensions specified by a passed unsigned vector.
    Multi_Array( const vector<unsigned>&, const vector<unsigned>&, DFT_engine* = NULL, unsigned (*)(unsigned) = NULL );
    // Destructor for the Multi_Array class.  It deletes the allocated DFT_engines in the Dimensional_DFT vector.
    inline ~Multi_Array( void ) { if( !Save_Dimensional_DFT_On_Exit && Dimensional_DFT != NULL ) delete Dimensional_DFT; }
    // Adds a new dimension of the passed variable's size to the multi-dimensional array.  The dimension is added as the last dimension.
    bool Add_Dimension( unsigned, unsigned, unsigned (*)(unsigned) = NULL ); 
    // Resizes the passed input dimension to the passed input size.  Uses the passed function to update the DFT_Dim_Map vector.
    bool Resize( unsigned, unsigned, unsigned (*)(unsigned) = NULL );    
    // Returns the number of dimensions in the multi_dim array.  We want to make sure this function doesn't change any array values.
    inline unsigned Dimensions( void ) const { return Dimension_Space.size(); } 
    // Returns the allocated memory taken up by the sub-dimensional array (first dim + 1 dimensions) of this multi-dim. array. 
    inline unsigned Sub_Array_Reserved( const unsigned dim ) const { return Dimension_Space[dim]; }
    // Returns the allocated memory size of the passed dimension.  The size of the 0th dimension is Dimension_Space[0]. The size of other 
    // dimensions i > 0 will be Dimension_Space[i] / Dimension_Space[i - 1].  We don't want the passed dimension to change.
    inline unsigned Dim_Reserved( const unsigned dim ) const 
           { if( dim == 0 ) return Dimension_Space[0]; return ( Dimension_Space[dim] / Dimension_Space[dim - 1] ); }
    // Returns current working space of the passed input dimension.
    inline unsigned Dim_Size( const unsigned dim ) const { return Working_Space[dim]; }
    // Returns a pointer to the cell specified by the passed vector.  See function declaration below for more details.
    MULTI_ARRAY_DATA_TYPE& El_Ref( const vector<unsigned>& ); 
    // Accessor for the working column.  Allows access to the working column like a regular array.
    inline MULTI_ARRAY_DATA_TYPE& Working_Col( const unsigned );
    // This function sets up the working_column structure to represent the same column as that indicated by the passed reference vector.  
    // See the function declaration below for more details.
    bool Column_Access( const vector<int>& );
    // Copies the passed vector's data into the column currently represented by working_column.  Returns TRUE if the copy was successful.
    bool Copy_to_Column( const vector<MULTI_ARRAY_DATA_TYPE>&, const double = 1.0 );
    // Copies the passed vector's data into the working_column column using the passed arithmatic progression and offset. 
    bool Copy_to_Column( const vector<MULTI_ARRAY_DATA_TYPE>&, Arith_Prog&, const unsigned, const double = 1.0 );
    // Copies the passed vector's data into the working_column column using the passed arithmatic progression and offset. 
    bool Copy_to_Column( MULTI_ARRAY_DATA_TYPE (*Signal)(unsigned, int), Arith_Prog&, const unsigned, const double = 1.0 );
    // Returns the mean of the working column. MULTI_ARRAY_DATA_TYPE must support addition and division by integers.
    void Column_Mean( MULTI_ARRAY_DATA_TYPE& ) const;
    // Returns the median of the working column.  MULTI_ARRAY_DATA_TYPE must have a comparison function which is passed in.
    void Column_Median( MULTI_ARRAY_DATA_TYPE&, bool (*)(const MULTI_ARRAY_DATA_TYPE&, const MULTI_ARRAY_DATA_TYPE&) ) const;
    // Returns the Discrete Fourier Transform of the working column.  The DFT is returned in the passed vector.
    void Column_DFT( vector<MULTI_ARRAY_DATA_TYPE>&, bool ) const;
    // Calculates the Discrete Fourier Transform of the working column.  The DFT is then stored back in the working column.
    void Column_DFT( bool );

  protected:
    // This function swaps the values of the two MULTI_ARRAY_DATA_TYPE variables A & B.  Used for by Column_Median function above.
    inline void Swap( MULTI_ARRAY_DATA_TYPE& A, MULTI_ARRAY_DATA_TYPE& B ) const { MULTI_ARRAY_DATA_TYPE temp = A; A = B; B = temp; }

  private:
    // Sizes of Sub-dimensions.  Entry dimension_space[i] = (Size of dimension i)(Size of dimension i-1)...(Size of dimension 0).
    // Hence, the size of dimension i > 0 is dimension_space[i]/dimension_space[i-1].  This array gives offsets for column/row access. 
    vector<unsigned> Dimension_Space;  
    // Gives the current maximum number of cells that the user will be storing data in for each dimension i.  The user may change them.
    vector<unsigned> Working_Space;
    // Actual data in our multi-dimensional array.  We store it in a 1-D vector and used offsets from Dimension_Space to 
    // simulate a multi-dimensional array.  Note that this means changing set dimension sizes will be Big_Oh(Data.size()).
    vector<MULTI_ARRAY_DATA_TYPE> Data;
    // This structure holds information for one column of the multi-dimensional array.  The Mean, Median, and FFT functions all
    // operate on this working column.  Therefore, you must set it correctly before using any of these functions.
    struct Column
    {
      unsigned start;      // Starting Data array index of column array.
      unsigned size;       // Data array index of the last column cell + 1.
      unsigned offset;     // Offset for Data array which moves the down the column one cell.   
      unsigned dimension;  // The dimension in which the column extends (numbering starts at 0). 
    } working_column;
    // Pointer to DFT and inverse DFT computers for each dimension.  Any row/column which extends in dimension 'i' can have it's DFT 
    // computed with the DFT_engine's ith plan.  NOTE:  The present implementional of the DFT_engine class only functions properly if
    // the signal data you want the DFT (or inverse DFT) of is of the type complex<double>.
    DFT_engine* Dimensional_DFT;
    bool Save_Dimensional_DFT_On_Exit;  // Should we destroy the DFT_engine pointed to by Dimensional_DFT?  
                                        // Set to true if using a DFT_engine that was passed into the constructor!
    // Vector that maps every dimensional index i to the index of the Dimensional_DFT Plan_Pair that should be used in order to calculate 
    // DFTs for columns extending in dimension i.
    vector<unsigned> DFT_Dim_Map;
};

#include "AAmulti_array.cc"

#endif



/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef PARAMETERS_H
#define PARAMETERS_H

// Class for holding parameters used by the Sparse Fourier Transform Algorithm.  Contains a variaty of functions for setting parameters.
class Parameters
{
  public:
  // Default class constructor that initializes almost all the parameter values to 1.
  Parameters( void );
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  // In the following block, each function returns the value of its associated 1D DFT parameter value. //
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  inline const unsigned get_Signal_Size( void ) const { return Signal_Size;}
  inline const unsigned get_Num_FreqID_CoefEst_Iterations( void ) const { return Num_FreqID_CoefEst_Iterations; }
  inline const unsigned get_Num_Rep_Terms( void ) const { return Num_Rep_Terms; }
  inline const unsigned get_Working_Rep_Terms( void ) const { return Working_Rep_Terms; }
  inline const unsigned get_Max_KShattering_Sample_Points( void ) const { return Max_KShattering_Sample_Points; }
  inline const unsigned get_Num_KShattering_Sample_Points( void ) const { return Num_KShattering_Sample_Points; }
  inline const unsigned get_Exhaustive_Most_Sig_Bits( void ) const { return Exhaustive_Most_Sig_Bits; }
  inline const unsigned get_Max_FCE_Sample_Points( void ) const { return Max_FCE_Sample_Points; }
  inline const unsigned get_Num_FCE_Sample_Points( void ) const { return Num_FCE_Sample_Points; }
  inline const unsigned get_Norm_Estimation_Max( void ) const { return Norm_Estimation_Max; }
  inline const unsigned get_Norm_Estimation_Num( void ) const { return Norm_Estimation_Num; }
  inline const unsigned get_Max_FCE_Medians( void ) const { return Max_FCE_Medians; }
  inline const unsigned get_Num_FCE_Medians( void ) const { return Num_FCE_Medians; }
  inline const unsigned get_Roots_Coef( void ) const { return Roots_Coef; }
  inline const unsigned get_Naive_Bulk_Cutoff( void ) const { return Naive_Bulk_Cutoff; }
  inline const unsigned get_Naive_Coef_Est_Cutoff( void ) const { return Naive_Coef_Est_Cutoff; }
  inline const unsigned get_Num_Fast_Bulk_Samp_Taylor_Terms( void ) const { return Num_Fast_Bulk_Samp_Taylor_Terms; }
  inline const unsigned get_FFCE_Roots_Coef( void ) const { return FFCE_Roots_Coef; }
  inline const unsigned get_Num_Fast_Freq_Coefnt_Est_Taylor_Terms( void ) const { return Num_Fast_Freq_Coefnt_Est_Taylor_Terms; }
  inline const unsigned get_FFCE_Iterations( void ) const { return FFCE_Iterations; }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // In the following block, each function assigns the passed value to its associated 1D DFT parameter value. //
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////
  inline void set_Signal_Size( const unsigned value ) { Signal_Size = value; }
  inline void set_Num_FreqID_CoefEst_Iterations( const unsigned value ) { Num_FreqID_CoefEst_Iterations = value; }
  inline void set_Num_Rep_Terms( const unsigned value ) { Num_Rep_Terms = value; }
  inline void set_Working_Rep_Terms( const unsigned value ) 
    { /*if( value < Num_Rep_Terms ) Working_Rep_Terms = Num_Rep_Terms; else*/ Working_Rep_Terms = value; }
  inline void set_Exhaustive_Most_Sig_Bits( const unsigned value ) { Exhaustive_Most_Sig_Bits = value; } // Some checks should be included.
  // We'll force Max_KShattering_Sample_Points to remain >= Num_KShattering_Sample_Points.
  inline void set_Max_KShattering_Sample_Points( const unsigned value ) 
    { /*if( value < Num_KShattering_Sample_Points ) return; else*/ Max_KShattering_Sample_Points = value; }
  inline void set_Num_KShattering_Sample_Points( const unsigned value )             
    { /*if( value > Max_KShattering_Sample_Points ) Max_KShattering_Sample_Points = value;*/ Num_KShattering_Sample_Points = value; }
  // We'll force Max_FCE_Sample_Points to remain >= Num_FCE_Sample_Points.
  inline void set_Max_FCE_Sample_Points( const unsigned value ) 
    { /*if( value < Num_FCE_Sample_Points ) return; else*/ Max_FCE_Sample_Points = value; }
  inline void set_Num_FCE_Sample_Points( const unsigned value ) 
    { /*if( value > Max_FCE_Sample_Points ) Max_FCE_Sample_Points = value;*/ Num_FCE_Sample_Points = value; }
  // We'll force Norm_Estimation_Max to remain >= Norm_Estimation_Num.
  inline void set_Norm_Estimation_Max( const unsigned value ) 
    { /*if( value < Norm_Estimation_Num ) return; else*/ Norm_Estimation_Max = value; }
  inline void set_Norm_Estimation_Num( const unsigned value ) 
    { /*if( value > Norm_Estimation_Max ) Norm_Estimation_Max = value;*/ Norm_Estimation_Num = value; }
  // Num_FCE_Medians MUST REMAIN <= Max_FCE_Medians DURING PROGRAM EXECUTION OR ERRORS WILL RESULT!
  inline void set_Max_FCE_Medians( const unsigned value ) { Max_FCE_Medians= value; }  // Should remain fixed during any 1D DFT code run.
  inline void set_Num_FCE_Medians( const unsigned value ) { /*if( value <= Max_FCE_Medians )*/ Num_FCE_Medians = value; }
  // Roots_Coef must remain >= 2*Pi in order for the Taylor series approximations in the Fast Bulk Sample function to converge.
  inline void set_Roots_Coef( const unsigned value ) { if( value < 8 ) Roots_Coef = 8; else Roots_Coef = value; }
  inline void set_Naive_Bulk_Cutoff( const unsigned value ) { Naive_Bulk_Cutoff = value; }
  inline void set_Naive_Coef_Est_Cutoff( const unsigned value ) { Naive_Coef_Est_Cutoff = value; }
  inline void set_Num_Fast_Bulk_Samp_Taylor_Terms( const unsigned value ) { Num_Fast_Bulk_Samp_Taylor_Terms = value; }
  // FFCE_Roots_Coef must remain >= 2*Pi so that the Taylor series approximations in the Fast Coefficient Estimation function converge.
  inline void set_FFCE_Roots_Coef( const unsigned value ) { if( value < 8 ) FFCE_Roots_Coef = 8; else FFCE_Roots_Coef = value; }
  inline void set_Num_Fast_Freq_Coefnt_Est_Taylor_Terms( const unsigned value ) { Num_Fast_Freq_Coefnt_Est_Taylor_Terms = value; }
  inline void set_FFCE_Iterations( const unsigned value ) { FFCE_Iterations = value; }

  private:
  ///////////////////////////////////////////////////////////////////////
  // PARAMETERS FOR 1 DIMENSIONAL DISCRETE FOURIER TRANSFORM ALGORITHM //
  ///////////////////////////////////////////////////////////////////////
  unsigned Signal_Size;        // Size of the original signal we want the Num_Terms representation of.
  unsigned Num_FreqID_CoefEst_Iterations;  // Number of times we identify large frequencies and estimate their coefficients.
  unsigned Num_Rep_Terms;      // Number of frequencies/coefficients we want in our end result output DFT representation.
  unsigned Working_Rep_Terms;  // Number of frequencies/coefficients we'll keep track of during freq. discovery (largest coef freq.s kept)
  unsigned Exhaustive_Most_Sig_Bits; // How many of the most significant bits of our signal size should we exhaustively search 
           // during significant frequency identification of K-Shattering elements?  Should only be > 0 if Signal_Size isn't a power of 2.
  unsigned Max_KShattering_Sample_Points;  // Number of sample points for arithmatic progressions we initially 
                                           // allocat memory for in K-shatterings.
  unsigned Num_KShattering_Sample_Points;  // Current number of sample points for the arithmatic progressions we're using in K-shatterings.
  unsigned Max_FCE_Sample_Points; // Number of sample points for frequency coefficient estimation we initially 
                                  // allocat memory for in related DFT_engines.
  unsigned Num_FCE_Sample_Points; // Current number of sample points for arithmatic progressions we're using in the frequency coefficient 
                                  // estimation functions (Fast and Niave) in 'fourier1D.h'.
  unsigned Norm_Estimation_Max;// Maximum number of random samples we'll be taking the median of in order to estimate the norm of a signal.
  unsigned Norm_Estimation_Num;// Number of random samples we'll take the median of in order to estimate the norm of a signal (lemma 15).
  unsigned Max_FCE_Medians;    // Maximum # medians of weighted sample means we'll EVER want to take during frequency coef. estimation. 
  unsigned Num_FCE_Medians;    // Current # of medians of sample means taken during frequency coefficient estimation.
                               // NOTE:  Num_FCE_Medians MUST REMAIN <= Max_FCE_Medians DURING PROGRAM EXECUTION OR ERRORS WILL RESULT!
  unsigned Roots_Coef;         // The Fast_Bulk_Sample function uses Roots_Coef*Num_Sample_Points roots of unity for it's Taylor expansion.
  unsigned Naive_Bulk_Cutoff;  // If the number of terms in our representation is < Naive_Bulk_Cutoff, we use the Naive Bulk Sample method.
  unsigned Naive_Coef_Est_Cutoff; // If the number of terms in our representation is < Naive_Coef_Est_Cutoff, use Naive Coef. Estimation.
  unsigned Num_Fast_Bulk_Samp_Taylor_Terms;  // Number of Taylor series terms used to approximate frequency coefficients in the Fast Bulk
                                             // Sample function.
  unsigned FFCE_Roots_Coef;    // The Fast_Frequency_Coefficient_Estimation function uses FFCE_Roots_Coef*Num_FCE_Sample_Points roots of 
                               // unity for it's Taylor expansion.
  unsigned Num_Fast_Freq_Coefnt_Est_Taylor_Terms;  // Number of Taylor series terms used to approximate frequency coefficients in the
                                                   // Fast_Frequency_Coefficient_Estimation function.
  unsigned FFCE_Iterations;    // Number of iterations of coefficient estimation done during Iterative Bulk Coefficient Estimation.
                               // Used in the Iterative_Fast_Freq_Coef_Estimation function below.
};

#include "AAparameters.cc"

#endif



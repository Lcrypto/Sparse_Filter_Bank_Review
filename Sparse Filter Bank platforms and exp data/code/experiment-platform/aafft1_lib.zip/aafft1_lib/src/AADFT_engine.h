/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef FFTW_WRAP_H
#define FFTW_WRAP_H

///////////////////////////////////////////////////////////////////////////
// ********************  1-D FFTW 3.0.1 DFT BASICS  ******************** //
///////////////////////////////////////////////////////////////////////////
// The basic usage of FFTW to compute a one-dimensional DFT of size `N'
// is simple, and it typically looks something like this code:
//
//     #include <fftw3.h>
//     ...
//     {
//         fftw_complex *in, *out;
//         fftw_plan p;
//         ...
//         in = fftw_malloc(sizeof(fftw_complex) * N);
//         out = fftw_malloc(sizeof(fftw_complex) * N);
//         p = fftw_plan_dft_1d(N, in, out, FFTW_FORWARD, FFTW_ESTIMATE);
//         ...
//         fftw_execute(p); // repeat as needed 
//         ...
//         fftw_destroy_plan(p);
//         fftw_free(in); fftw_free(out);
//     }
//
//   (When you compile, you must also link with the `fftw3' library, e.g.
// `-lfftw3 -lm' on Unix systems.)
//
//   First you allocate the input and output arrays.  You can allocate
// them in any way that you like, but we recommend using `fftw_malloc',
// which behaves like `malloc' except that it properly aligns the array
// when SIMD instructions (such as SSE and Altivec) are available (*note
// SIMD alignment and fftw_malloc::).
//
//   The data is an array of type `fftw_complex', which is by default a
// `double[2]' composed of the real (`in[i][0]') and imaginary
// (`in[i][1]') parts of a complex number.
//
//   The next step is to create a "plan", which is an object that
// contains all the data that FFTW needs to compute the FFT.  This
// function creates the plan:
//
//     fftw_plan fftw_plan_dft_1d(int n, fftw_complex *in, fftw_complex *out,
//                                int sign, unsigned flags);
//
//   The first argument, `n', is the size of the transform you are trying
// to compute.  The size `n' can be any positive integer, but sizes that
// are products of small factors are transformed most efficiently
// (although prime sizes still use an O(n log n)  algorithm).
//
//   The next two arguments are pointers to the input and output arrays of
// the transform.  These pointers can be equal, indicating an "in-place"
// transform.
//
//   The fourth argument, `sign', can be either `FFTW_FORWARD' (`-1') or
// `FFTW_BACKWARD' (`+1'), and indicates the direction of the transform
// you are interested in; technically, it is the sign of the exponent in
// the transform.
//
//   The `flags' argument is usually either `FFTW_MEASURE' or
// `FFTW_ESTIMATE'.  `FFTW_MEASURE' instructs FFTW to run and measure the
// execution time of several FFTs in order to find the best way to compute
// the transform of size `n'.  This process takes some time (usually a few
// seconds), depending on your machine and on the size of the transform.
// `FFTW_ESTIMATE', on the contrary, does not run any computation and just
// builds a reasonable plan that is probably sub-optimal.  In short, if
// your program performs many transforms of the same size and
// initialization time is not important, use `FFTW_MEASURE'; otherwise use
// the estimate.  The data in the `in'/`out' arrays is _overwritten_
// during `FFTW_MEASURE' planning, so such planning should be done
// _before_ the input is initialized by the user.
//
//   Once the plan has been created, you can use it as many times as you
// like for transforms on the specified `in'/`out' arrays, computing the
// actual transforms via `fftw_execute(plan)':
//     void fftw_execute(const fftw_plan plan);
//
//   If you want to transform a _different_ array of the same size, you
// can create a new plan with `fftw_plan_dft_1d' and FFTW automatically
// reuses the information from the previous plan, if possible.
// (Alternatively, with the "guru" interface you can apply a given plan to
// a different array, if you are careful.  *Note FFTW Reference::.)
//
//   When you are done with the plan, you deallocate it by calling
// `fftw_destroy_plan(plan)':
//     void fftw_destroy_plan(fftw_plan plan);
// Arrays allocated with `fftw_malloc' should be deallocated by
// `fftw_free' rather than the ordinary `free' (or, heaven forbid,
// `delete').
//
//   The DFT results are stored in-order in the array `out', with the
// zero-frequency (DC) component in `out[0]'.  If `in != out', the
// transform is "out-of-place" and the input array `in' is not modified.
// Otherwise, the input array is overwritten with the transform.
//
//   Users should note that FFTW computes an _unnormalized_ DFT.  Thus,
// computing a forward followed by a backward transform (or vice versa)
// results in the original array scaled by `n'.  For the definition of the
// DFT, see *Note What FFTW Really Computes::.
//
//   If you have a C compiler, such as `gcc', that supports the recent
// C99 standard, and you `#include <complex.h>' _before_ `<fftw3.h>', then
// `fftw_complex' is the native double-precision complex type and you can
// manipulate it with ordinary arithmetic.  Otherwise, FFTW defines its
// own complex type, which is bit-compatible with the C99 complex type.
// You can pass `complex<double>*x' directly to FFTW via 
// `reinterpret_cast<fftw_complex*>(x)'.  *Note Complex numbers::.  
// (The C++ `<complex>' template class may also be usable via a typecast.)
//
//   Single and long-double precision versions of FFTW may be installed;
// to use them, replace the `fftw_' prefix by `fftwf_' or `fftwl_' and
// link with `-lfftw3f' or `-lfftw3l', but use the _same_ `<fftw3.h>'
// header file.
//
//   Many more flags exist besides `FFTW_MEASURE' and `FFTW_ESTIMATE'.
// For example, use `FFTW_PATIENT' if you're willing to wait even longer
// for a possibly even faster plan (*note FFTW Reference::).  You can also
// save plans for future use, as described by *Note Words of Wisdom-Saving
// Plans::.

typedef fftw_complex my_complex;  // CHANGE FFTW COMPLEX TYPE HERE
typedef fftw_plan DFT_plan;       // CHANGE FFTW PLAN TYPE HERE
typedef unsigned Plan_Type;       // CHANGE PLANNING SYLE HERE

// Structure to hold plans for taking both the DFT and the inverse DFT of Working_Size number of data elements.
struct Plan_Pair
{
  unsigned working_size; // Number of array cells that are used in the forward and backward plans.
  Plan_Type plan_type;    // Type of plans the forward and backward DFT/inverse DFT plans are (FFTW_ESTIMATE, etc.).
  DFT_plan forward;      // Plan to take the DFT of an array.
  DFT_plan backward;     // Plan to take the inverse DFT of an array.
};

// This class wraps fftw version 3.0.1 code for computing the DFT of several 1-D arrays.  It allows the user to copy data into it,
// compute the DFT (or inverse DFT) of the the copied data, and then copy the DFT of the data back out.  NOTE:  The code is
// a bit restrictive here.  It assumes that the only signal type we want a DFT of is a complex valued signal. 
class DFT_engine 
{ 
  public:
    // Constructor that creates the transform data array & fftw plans.  See below for details.
    DFT_engine( unsigned, unsigned, Plan_Type = FFTW_PATIENT ); //EDIT - Changed default from FFTW_ESTIMATE to FFTW_PATIENT
    // Destructor for class.  Deallocates all the memory that the class allocated.
    inline ~DFT_engine() 
    { 

      // Free the array used to compute all of our DFT's and inverse DFT's
      fftw_free(In_Place_Transform_Data); 

      // Free all of the plans we have saved.
      for( unsigned i = 0; i < DFT_Plans.size(); i++ )
      {
        // Deallocate memory for both the forward and backward plans
        fftw_destroy_plan(DFT_Plans[i].forward); 
        fftw_destroy_plan(DFT_Plans[i].backward); 
      }
    }
    // Function for adding a new Plan_Pair to the DFT_Plans vector.  Takes two passed input integers.  The first input is the working_size 
    // for the new DFT and inverse DFT plans.  The second input is the type of plans we want (FFTW_ESTIMATE, FFTW_MEASURE, etc.).
    bool Add_Plan( unsigned, Plan_Type = FFTW_PATIENT ); //EDIT - Changed default from FFTW_ESTIMATE to FFTW_PATIENT
    // Function for resizing the In_Place_Transform_Data array.  We destroy the smaller old one and declare a new one with the passed size.
    bool reallocate( unsigned );
    // Replan the Plan_Pair referenced by the first passed input DFT_Plans index.  In doing so, increase the working size of the plans to 
    // the second passed input integer. Return TRUE if the replanning goes as expected, FALSE otherwise.
    bool Replan( unsigned, unsigned );
    // Return the capacity of the In_Place_Transform_Data array. Tells how many elements it can possibly hold.
    inline unsigned get_capacity( void ) const { return In_Place_Transform_Data_Size; }
    // Return the current number of DFT/inverse DFT plans we have.  Tells how many signal size values we have plans for.
    inline unsigned get_num_plans( void ) const { return DFT_Plans.size(); }
    // Return the working_size of the DFT and inverse DFT plans referenced by the passed integer.
    inline unsigned get_working_size( unsigned i ) const { if( i < DFT_Plans.size() ) return DFT_Plans[i].working_size; else return 0; }
    // Copies a vector of complex<double> values into the In_Place_Transform_Data array.  The input variable is a pointer to a vector
    // containing data we want the DFT or inverse DFT of.  WE ASSUME THAT THE DATA CONSISTS OF COMPLEX VALUES IN A VECTOR!  The function
    // returns FALSE if no data was copied, TRUE if it was.
    inline bool put_data( const vector< complex<double> >& Input_Data )
    {
      // Make sure that the passed vector has the correct size.  If not, return FALSE.  
      if( Input_Data.size() > In_Place_Transform_Data_Size )
        return false;

      // Copy the Input_Data array into the In_Place_Transform_Data array.
      for( unsigned i = 0; i < Input_Data.size(); i++ )
      {
        // We have to copy the real and imaginary components of each element seperately.
        (In_Place_Transform_Data[i])[0] = (Input_Data[i]).real();
        (In_Place_Transform_Data[i])[1] = (Input_Data[i]).imag();
      }

      // Return TRUE if the data has been copied. 
      return true;
    }
    // Copies the passed complex number (first arguement to the function) to the In_Place_Transform_Data cell indicated by the second 
    // integer arguement.  The function returns TRUE if successful, else FALSE.  We are again ASSUMING COMPLEX VALUES!
    inline bool put_element( const complex<double>& datum , unsigned index )
    {
      // Make sure that the index is valid.  If not, return FALSE.
      if( index >= In_Place_Transform_Data_Size )
        return false;
      // If the index is valid, copy the complex value 'datum' into the DFT_engine's 'index' array cell.
      else
      {
        // We have to copy the real and imaginary components of the complex number seperately.
        (In_Place_Transform_Data[index])[0] = datum.real();
        (In_Place_Transform_Data[index])[1] = datum.imag(); 
      }

      // If we've copied the element, return TRUE.
      return true;
    }
    // Copies the In_Place_Transform_Data array into a vector of complex<double>.  The input variable is a pointer to a vector
    // we want to copy the In_Place_Transform_Data array to.  WE ASSUME THAT THE DATA CONSISTS OF COMPLEX VALUES IN A VECTOR!  
    // The function returns FALSE if no data was copied, TRUE if it was.  
    inline bool get_data( vector< complex<double> >& Output_Data ) const
    {
      // Make sure that the passed vector has the correct size.  If not, return FALSE.  
      if( Output_Data.size() > In_Place_Transform_Data_Size )
        return false;

      // Copy the Input_Data array into the In_Place_Transform_Data array.
      for( unsigned i = 0; i < Output_Data.size(); i++ )
        Output_Data[i] = complex<double>( (In_Place_Transform_Data[i])[0], (In_Place_Transform_Data[i])[1] );

      // Return TRUE if the data has been copied. 
      return true;
    }
    // Copies the In_Place_Transform_Data cell indicated by the second integer arguement to the passed complex number (first arguement to 
    // the function).  The function returns TRUE if successful, else FALSE.  We are again ASSUMING COMPLEX VALUES!
    inline bool get_element( complex<double>& datum , unsigned index ) const
    {
      // Make sure that the index is valid.  If not, return FALSE.
      if( index >= In_Place_Transform_Data_Size )
        return false;
      // If the index is valid, copy the DFT_engine's 'index' array cell to the passed complex 'datum' variable.
      else
        datum = complex<double>( (In_Place_Transform_Data[index])[0], (In_Place_Transform_Data[index])[1] );

      // If we've copied the element, return TRUE.
      return true;
    }
    // Compute the DFT (or the inverse DFT) of the In_Place_Transform_Data array.  If passed bool variable is TRUE the DFT is computed.  
    // Otherwise the inverse DFT of the In_Place_Transform_Data array is computed.  The Plan_Pair indexed by second passed integer is used.
    inline void DFT( bool Forward, unsigned index )
    { 
      // Make sure that the passed index is valid for use.
      if( index >= DFT_Plans.size() )
        return;

      // If the passed Forward variable is true compute the DFT with the ith Plan_Pair's DFT plan, else use the ith inverse DFT plan
      if(Forward) 
        fftw_execute( DFT_Plans[index].forward ); 
      else 
        fftw_execute( DFT_Plans[index].backward );
    }

  private:
    unsigned In_Place_Transform_Data_Size;// Number of data elements that the In_Place_Transform_Data array can hold
    my_complex* In_Place_Transform_Data;  // Pointer to the array where the DFT is calculated
    vector<Plan_Pair> DFT_Plans;          // Plan_Pairs for various working sizes of elements in the In_Place_Transform_Data array
}; 

#include "AADFT_engine.cc"

#endif



/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using namespace std;

#include <vector>
#include <complex>
#include <fftw3.h>   // We're using fftw version 3.0.1

//////////////////////////////////////////////////////////////////////////////////////////
// ******************** FUNCTION DECLARATIONS FOR DFT_engine CLASS ******************** //
//////////////////////////////////////////////////////////////////////////////////////////

// Constructor that creates the transform data array & fftw plans for the transform data's DFT and inverse DFT.  The function takes three 
// positive integer inputs.  The first input is the largest possible size of any 1-D transform data array we may want the DFT/inverse 
// DFT of.  The second input is a size of some signal we're currently interested in computing the DFT/inverse DFT of.  Finially, the last 
// input is the type of plan we want to create for doing both the DFT and inverse DFT calculations (FFTW_ESTIMATE, FFTW_MEASURE, etc.).
DFT_engine::DFT_engine( unsigned memory_size, unsigned working_size, Plan_Type plan_type )
{
  
  // Make sure that the memory_size (array size) is >= the working_size (amount of data we want to manipulate)
  if( memory_size < working_size )
  {
    // Swap the memory_size and working_size values
    unsigned tmp = memory_size;
    memory_size = working_size;
    working_size = tmp;
  }

  // Use fftw's malloc function to allocate space for the transform data array.
  In_Place_Transform_Data = (my_complex*)fftw_malloc(sizeof(my_complex) * memory_size);

  // Set In_Place_Transform_Data array size to size of the largest possible signal.
  In_Place_Transform_Data_Size = memory_size;
  
  // Create the plans for taking the working size DFT and inverse DFT of the In_Place_Transform_Data array.
  Add_Plan( working_size, plan_type );
}

// Function for adding a new Plan_Pair to the DFT_Plans vector.  Takes two passed input integers.  The first input is the working_size 
// for the new DFT and inverse DFT plans.  The second input is the type of plans we want (FFTW_ESTIMATE, FFTW_MEASURE, etc.).
// We return TRUE if the new Plan_Pair is added with new problems, FALSE if an error has happened along the way.
bool DFT_engine::Add_Plan( unsigned working_size, unsigned plan_type )
{
  // Make sure that the passed working_size is smaller than the capacity of the In_Place_Transform_Data array that we'll be using.
  if( working_size <= In_Place_Transform_Data_Size )
  {
    // Create new Plan_Pair to add to the DFT_Plans vector.
    Plan_Pair temp;
    temp.working_size = working_size;
    temp.plan_type = plan_type;
    temp.forward = fftw_plan_dft_1d( (int)working_size, In_Place_Transform_Data, In_Place_Transform_Data, FFTW_FORWARD, plan_type );
    temp.backward = fftw_plan_dft_1d( (int)working_size, In_Place_Transform_Data, In_Place_Transform_Data, FFTW_BACKWARD, plan_type );
    DFT_Plans.push_back(temp);

    // If the two new plans have been created, return TRUE.
    if( temp.forward != NULL && temp.backward != NULL )
      return true;
  }

  // If we get here then an error has occurred.
  return false;
}

// Function for reallocating the In_Place_Transform_Data array.  We destroy the smaller old one and declare a new one with the passed size.
// We also have to re-plan all of the saved Plan_Pairs using the new In_Place_Transform_Data pointer. The function returns TRUE if the 
// reallocation was successful, FALSE otherwise.
bool DFT_engine::reallocate( unsigned new_size ) 
{ 
  // If the new size we want for the In_Place_Transform_Data array is smaller than it currently is, do nothing.
  if( new_size > In_Place_Transform_Data_Size ) 
  {
    // Otherwise, destroy the old In_Place_Transform_Data array and declare a new larger one.  Save the new capacity for the new array.
    fftw_free(In_Place_Transform_Data); 
    In_Place_Transform_Data = (my_complex*)fftw_malloc(sizeof(my_complex) * new_size);

    // If the In_Place_Transform_Data array couldn't be allocated, return false
    if( In_Place_Transform_Data == NULL )
      return false;

    // Save the new capacity for the new array.
    In_Place_Transform_Data_Size = new_size;

    // Free all of the plans we previously saved.
    for( unsigned i = 0; i < DFT_Plans.size(); i++ )
    {
      // Deallocate memory for both the forward and backward plans
      fftw_destroy_plan(DFT_Plans[i].forward); 
      fftw_destroy_plan(DFT_Plans[i].backward); 
    }

    // Re-plan all of the Plan_Pairs with the new In_Place_Transform_Data pointer value.
    for( unsigned i = 0; i < DFT_Plans.size(); i++ )
    {
      // Compute the new plans.
      DFT_Plans[i].forward = fftw_plan_dft_1d( DFT_Plans[i].working_size, In_Place_Transform_Data, 
                                               In_Place_Transform_Data, FFTW_FORWARD, DFT_Plans[i].plan_type );
      DFT_Plans[i].backward = fftw_plan_dft_1d( DFT_Plans[i].working_size, In_Place_Transform_Data, 
                                               In_Place_Transform_Data, FFTW_BACKWARD, DFT_Plans[i].plan_type );

      // Make sure that the plans were actually created.  If not, warn the user.
      if( DFT_Plans[i].forward == NULL || DFT_Plans[i].backward == NULL )
        return false;
    }
  }
  // The new size was unreasonable.
  else
    return false;
  
  // If we get here then everything has gone well.
  return true;
}

// Replan the Plan_Pair referenced by the first passed input DFT_Plans index.  In doing so, increase the working size of the plans to 
// the second passed input integer. Return TRUE if the replanning goes as expected, FALSE otherwise.
bool DFT_engine::Replan( unsigned index, unsigned new_size )
{
  // Make sure that the passed index and size variables are OK
  if( index >= DFT_Plans.size() || new_size >= In_Place_Transform_Data_Size )
    return false;

  // Do the required replanning and save the new working size for the plans
  fftw_destroy_plan( DFT_Plans[index].forward ); 
  fftw_destroy_plan( DFT_Plans[index].backward ); 
  DFT_Plans[index].forward = fftw_plan_dft_1d( new_size, In_Place_Transform_Data, In_Place_Transform_Data, FFTW_FORWARD, 
                                               DFT_Plans[index].plan_type );
  DFT_Plans[index].backward = fftw_plan_dft_1d( new_size, In_Place_Transform_Data, In_Place_Transform_Data, FFTW_BACKWARD, 
                                                DFT_Plans[index].plan_type );
  DFT_Plans[index].working_size = new_size;

  // If either of the plans weren't constructed properly, return FALSE
  if( DFT_Plans[index].forward == NULL || DFT_Plans[index].backward == NULL )
    return false;
  // Otherwise, everything has gone as expected.
  else
    return true;
}
 

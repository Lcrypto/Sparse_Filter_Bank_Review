/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using namespace std;

#include <vector>
#include <complex>
#include <fftw3.h>   // We're using fftw version 3.0.1
#include "AADFT_engine.h"
#include "AAarith_prog.h"

///////////////////////////////////////////////////////////////////////////////////////////
// ******************** FUNCTION DECLARATIONS FOR MULTI_ARRAY CLASS ******************** //
///////////////////////////////////////////////////////////////////////////////////////////

// Empty Constructor for the Multi_Array class.  This will initialize the data elements to default values.
template<class MULTI_ARRAY_DATA_TYPE>
Multi_Array<MULTI_ARRAY_DATA_TYPE>::Multi_Array( void )
{
  // Initialize the multi-dimensional array to one dimension one element array
  Dimension_Space.push_back(1);
  Working_Space.push_back(0);   // The user has no data elements that he/she may use.
  Data.resize(1);               // Data array will hold junk data.
  
  // Set up the working column to be the one column in this default array
  working_column.start = 0;
  working_column.size = 1;
  working_column.offset = 1;
  working_column.dimension = 0;

  // Set the Dimensional_DFT pointer to be null.
  Dimensional_DFT = NULL;

  // Destroy any DFT_engine that we end up creating for this multi_array.
  Save_Dimensional_DFT_On_Exit = false;
}

// Constructor that creates a Multi_Array with the dimensions specified by the first passed unsigned vector Dimension_Sizes.  The ith 
// element of the Dimension_Sizes array will be taken as the size of the ith dimension of the Multi-dimensional array.  Hence, we require 
// that all elements of the passed vector be > 1.  Dimensions of size 1 are ignored.  The working column is initialized as the first 
// column in the first dimension.  The Data Array is allocated the desired amount of space, but not initialized.  It'll contain garbage!!!
// The second input Working_Sizes vector contains the current number of cells in each dimensional column that the user is allowing 
// themselves access to.  It's used to create the DFT_engine plans if none are passed in.  If the third input arguement is not null, we use
// them to compute dimensional column DFT's and keep track of which Plan_Pair to use with the passed function (fourth arguement).  The 
// fourth arguement is a function pointer to a function that takes a dimension's working size and returns the index for a proper Plan_Pair 
// to use in the passed DFT_engine.  NOTE:  BE CAREFUL THAT EVERY DIMENSION WILL END UP GETTING A GOOD PLAN PAIR FROM THE PASSED FUNCTION.
// ALSO, BE AWARE THAT ANY PASSED DFT_ENGINE WON'T BE DEALLOCATED BY THE MULTI-ARRAY'S DESTRUCTOR.  SAVED_PLANS WILL BE SAVED!!!
template<class MULTI_ARRAY_DATA_TYPE>
Multi_Array<MULTI_ARRAY_DATA_TYPE>::Multi_Array( const vector<unsigned>& Dimension_Sizes, const vector<unsigned>& Working_Sizes, 
                                                 DFT_engine* Saved_Plans, unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  unsigned Maximum_Dim_Size = 0;  // Hold the largest dimension's size.  Used later for declaring the DFT engine class.  

  // Make sure that the Working_Sizes vector is the same size as the Dimension_Sizes vector.  Also make sure that the last two 
  // input arguements are either both null or both non-null -- we want to make sure that we're given a DFT_engine to use iff we're
  // given a rule that tells us which Plan_Pair in the DFT_engine we have to use for each dimensional column DFT/inverse DFT. 
  if( Dimension_Sizes.size() != Working_Sizes.size() || (Saved_Plans != NULL && WHICH_PLAN_PAIR  == NULL ) )
  { 
    // Initialize the multi_array ignoring the bogus input vectors.
    Multi_Array();
    return;
  }

  // Make sure that each dimensional column's working size is less than or equal to the memory allocated for each dimensional column.
  for( unsigned i = 0; i < Dimension_Sizes.size(); i++ )
  {
    // Find the maximum integer in the Dimension_Sizes array (maximum entry).  This will be used to create the DFT engine later.
    if( Dimension_Sizes[i] > Maximum_Dim_Size )
      Maximum_Dim_Size = Dimension_Sizes[i];

    // The working size can't exceed the allocated size
    if( Working_Sizes[i] > Dimension_Sizes[i] )
    {
      // Initialize the multi_array ignoring the bogus input vectors.
      Multi_Array();
      return;
    }
  }

  // Calculate all of the space requirements for the first k-dimensional sub-space arrays of the multi-dimensional array to be built. 
  for( unsigned i = 0; i < Dimension_Sizes.size(); i++ )
    // If the dimension size is > 1, use it in the Dimension_Space vector.
    if( Dimension_Sizes[i] > 1 )
      // If the this is the first dimension we're adding, just push the desired size onto the space requirement vector
      if( Dimension_Space.empty() )
        Dimension_Space.push_back( Dimension_Sizes[i] );
      // Otherwise, push the current size of the total multi-dimensional array onto the space requirement vector 
      else
        Dimension_Space.push_back( Dimension_Sizes[i]*Dimension_Space[Dimension_Space.size() - 1] );

  // Copy the Working_Sizes vector to the Working_Space vector.
  Working_Space.resize( Working_Sizes.size() );
  for( unsigned i = 0; i < Working_Sizes.size(); i++ )
    Working_Space[i] = Working_Sizes[i];

  // Make sure that at least one dimension is added (in case the entire passed vector was full of elements <= 1) 
  if( Dimension_Space.empty() )
    Dimension_Space.push_back(1);

  // Declare the required space for the Data array.  We don't initialize the Data vector so we must remember it contains garbage.
  Data.resize( Dimension_Space[Dimension_Space.size() - 1] );

  // Initialize the working column.
  working_column.start = 0;
  working_column.size = Working_Space[0];
  working_column.offset = 1;
  working_column.dimension = 0;

  // Size the DFT_Dim_Map vector properly.  Make it the same size as the number of dimensions in the multi_dim array.
  DFT_Dim_Map.resize( Working_Space.size() );

  // If no DFT_engine was passed in, create a new one for use by the multi_array columns.
  if( Saved_Plans == NULL )
  {
    // Remember to destroy whatever plans we create here.
    Save_Dimensional_DFT_On_Exit = false;

    // Declare an empty DFT engine with the ability to calculate DFTs and inverse DFTs for all the dimensions.
    Dimensional_DFT = new DFT_engine( Maximum_Dim_Size, Working_Space[0] );

    // Add a new Plan_Pair for each dimension >= 1 (we got the 0th dimension in the initial declaration of the Dimensional_DFT above).
    for( unsigned i = 1; i < Working_Space.size(); i++ )
      Dimensional_DFT->Add_Plan(Working_Space[i]);

    // Create the DFT dimension index -> Plan_Pair index map.  Note that the Dimensional_DFT DFT_engine here was created s.t. the DFT_Dim
    // map will be the identity map. 
    for( unsigned i = 0; i < Working_Space.size(); i++ )
      DFT_Dim_Map[i] = i;
  }
  // If a DFT_engine was passed in, save a reference to it here and initialize the DFT_Dim_Map using the passed WHICH_PLAN_PAIR function.
  else
  {
    // Save the DFT_engine we passed in a pointer to from destruction.  We'll assume we might want to use it again.
    Save_Dimensional_DFT_On_Exit = true;

    // Initialize the Dimensional_DFT pointer.
    Dimensional_DFT = Saved_Plans;
    
    // Initialize the DFT_Dim_Map vector.
    for( unsigned i = 0; i < Working_Space.size(); i++ )
      DFT_Dim_Map[i] = WHICH_PLAN_PAIR( Working_Space[i] );
  }
}

// Adds a new dimension of the passed variable size to the multi-dimensional array.  The dimension is added as the last dimension.
// The working column is re-initialized at the end.  The newly added array Data elements aren't initialized so they'll contain garbage.
// The third arguement is a pointer to a function that takes a dimension's working size and returns the index for a proper Plan_Pair to 
// use in the Dimensional_DFT.  NOTE:  BE CAREFUL THAT EVERY DIMENSION WILL END UP GETTING A GOOD PLAN PAIR FROM THE PASSED FUNCTION.
// The function returns true is the dimension is added and false if some problems is encountered along the way.
template<class MULTI_ARRAY_DATA_TYPE>
bool Multi_Array<MULTI_ARRAY_DATA_TYPE>::Add_Dimension( unsigned mem_size, unsigned working_size, 
                                                        unsigned (*WHICH_PLAN_PAIR)(unsigned) )
{
  // Make sure that the memory size (number of cells we'll allocate) is greater than or equal to the working size.
  if( working_size > mem_size )
  {
    // Swap the two variable's values
    unsigned tmp = mem_size;
    mem_size = working_size;
    working_size = tmp;
  }

  // Make sure that the new dimensions memory size is reasonable (not 0 or 1).  If the size is 0 or 1, quit.  
  if( mem_size <= 1 )
    return false;

  // Add the new dimension to the Dimension_Space array and calculate the size of the new Multi-Array.
  Dimension_Space.push_back( mem_size*Dimension_Space[Dimension_Space.size() - 1] );  

  // Remember the working size of the new dimension.
  Working_Space.push_back( working_size );

  // Resize the Data array to hold the new dimension and the extension all previous dimensions into the new dimension.
  Data.resize(Dimension_Space[Dimension_Space.size() - 1]);

  // Re-initialize the working column.
  working_column.start = 0;
  working_column.size = Dimension_Space[0];
  working_column.offset = 1;
  working_column.dimension = 0;

  // If working size of the new dimension is larger than the capacity of the Dimensional_DFT DFT_engine, allocate more DFT_engine space.
  if( working_size > Dimensional_DFT->get_capacity() )
    if( !Dimensional_DFT->reallocate( mem_size ) )
      return false; // The DFT_engine resize function failed.

  // Add a plan for computing the DFT/inverse DFT of the new dimension.  Use the passed function if one was given.
  if( WHICH_PLAN_PAIR == NULL )
  {
    // If no function was passed we assume the Dimensional_DFT has no Plan_Pair that will work.  So, we create a new one.
    Dimensional_DFT->Add_Plan( working_size );  
    DFT_Dim_Map.push_back( Dimensional_DFT->get_num_plans() - 1 );
  }
  // If a function was passed we assume that the Dimensional_DFT is already extensive enough to have a useful Plan_Pair.
  else
    DFT_Dim_Map.push_back( WHICH_PLAN_PAIR(working_size) );

  // Everything worked OK.
  return true;
}

// This function takes three passed inputs.  The first input is the index of the dimension we want to resize.  The second input is the new
// size we want our dimension to be.  And, the third is a function mapping the new size of the dimension to the DFT_engine Plan_Pair that 
// should be used to compute its column's DFTs and inverse DFTs.  If no function is passed in, then we will simply re-plan the Plan_Pair 
// currently used for the dimension's columns.  NOTE:  IN THAT CASE WE HAVE TO MAKE SURE THAT THE RESIZED PLAN_PAIR ISN'T USED BY MORE THAN
// ONE DIMENSION.  The function returns TRUE if the resizing goes as expected, FALSE is returned otherwise. 
template<class MULTI_ARRAY_DATA_TYPE>
bool Multi_Array<MULTI_ARRAY_DATA_TYPE>::Resize( const unsigned Dimension, const unsigned New_Size, 
                                                 unsigned (*WHICH_PLAN_PAIR)(unsigned) )   
{
  // Make sure that the passed dimension index and new size are valid
  if( Dimension >= Working_Space.size() || New_Size >= Dim_Reserved(Dimension) )
    return false;
  else
    Working_Space[Dimension] = New_Size;

  // If no WHICH_PLAN_PAIR function was passed, resize the Plan_Pair currently used for the dimension and quit.
  if( WHICH_PLAN_PAIR == NULL )
  {
    if( Dimensional_DFT->Replan(DFT_Dim_Map[Dimension], New_Size) )
    {
      // If the replanning went well, save the new size of the dimension and report success.
      Working_Space[Dimension] = New_Size; 
      return true;
    }
    // Replanning failed if we get here 
    else
      return false;
  }
  // A function pointer was passed so we assume we have a robust DFT_engine.  Hence, we just find a new Plan_Pair to use from it.
  else
    DFT_Dim_Map[Dimension] = WHICH_PLAN_PAIR( New_Size );

  // If we get this far everything has worked well.
  return true;
}

// Takes an a pointer to an unsigned vector as input.  This input vector (Ref) specifies the multi-dimensional array cell in the 
// usual fashion.  For example, Ref = {0, 1, 7} will return a pointer to cell Data[0][1][7].  We make sure no data is changed in
// returning the pointer to the desired array cell.  We also perform some checks to make sure Ref makes sence w.r.t. the array.
// If the Ref input vector is illegal (too small, whatever) we'll return the NULL pointer.
template<class MULTI_ARRAY_DATA_TYPE>
MULTI_ARRAY_DATA_TYPE& Multi_Array<MULTI_ARRAY_DATA_TYPE>::El_Ref( const vector<unsigned>& Ref )
{
  unsigned Data_Index = Ref[0];  // This variable will hold the Data vector index corresponding to the Ref vector

  // Make sure that the input reference vector has the correct number of dimensions.
  if( Ref.size() != Working_Space.size() )
  {
    // Print an error message and exit the program.
    cout << "Illegal reference call from Mulit_Array class member function El_Ref." << endl;
    exit(1);
  }

  // Locate Data vector cell associated with the Ref input vector.  Along the way we'll make sure that the elements of the Ref
  // input vector are all < the working sizes their respective dimensions.  This will slow down the access time a little, but not much.
  for( unsigned i = 1; i < Working_Space.size(); i++ )
  {
    // Make sure that the ith dimensional coordinate is < the size of the ith dimension. 
    if( Ref[i] >= Working_Space[i] )
    {
      // Print an error message and exit the program.
      cout << "Illegal reference call from Mulit_Array class member function El_Ref." << endl;
      exit(1);
    }

    // Calculate the index of our Data array which corresponds to the Ref coordinates for our mult-dimensional array.
    Data_Index += Ref[i]*Dimension_Space[i - 1];
  }

  // Return the address of the desired data cell
  return Data[Data_Index];
} 

// Accessor for the working column.  Allows access to the working column like a regular array.  The one passed integer is the index 
// of the desired element.  NOTE:  There's no error checking done here -- we have to be as careful as we would be with a regular array.
template<class MULTI_ARRAY_DATA_TYPE>
inline MULTI_ARRAY_DATA_TYPE& Multi_Array<MULTI_ARRAY_DATA_TYPE>::Working_Col( const unsigned index )
{
  return Data[working_column.start + index*working_column.offset];
}

// This function takes a pointer to a vector of integers.  It's assumed that ONLY ONE value in the input Ref vector will be negative.
// The negative value should mark the dimension to be traversed (the dimension along which the desired column extends).  The other
// Ref.size() - 1 values should be unsigned and represent the starting cell of the column.  Checks will be run to make sure the Ref
// array makes sence (dimension not too small, ...).  The working_column start will be set the starting cell index of the desired column
// in the Data array.  The working_column size will be set to the size of the column sub-array in the Data array.  The working_column
// offset variable will be set to the offset in the Data array which corresponds to moving one element in the column.  And, the  
// working_column dimension variable will be assigned the dimension that the column extends in.  The function returns TRUE if it operated 
// as expected (the Ref array was good) and FALSE if it encountered an error.
template<class MULTI_ARRAY_DATA_TYPE>
bool Multi_Array<MULTI_ARRAY_DATA_TYPE>::Column_Access( const vector<int>& Ref )
{
  bool Found_Negative = false;  // Have we found the the single negative value in the Ref vector yet?

  // Make sure that the input reference vector has the correct number of dimensions.
  if( Ref.size() != Working_Space.size() )
    return false;  // Ref array is not the correct size.

  // Initialize the working_column structure.  Set working_column.start to Ref[0] if it's >=0 or to 0 if Ref[0] < 0.
  if( Ref[0] < 0 )
  {
    // If we're moving in the 0th dimension, do the setup here.
    working_column.start = 0;
    working_column.offset = 1;
    working_column.size = Working_Space[0];
    working_column.dimension = 0;
    Found_Negative = true;
  }
  // We're going to be traversing a different dimension > 0.  Initialize the working_column starting value and continue.
  else
    working_column.start = Ref[0];

  // Locate Data vector index associated with the Ref input vector column's beginning cell.  Along the way we'll make sure that the 
  // elements of the Ref input vector are all < the working sizes their respective dimensions and make sure that only one entry in the 
  // Ref vector is negative.
  for( unsigned i = 1; i < Working_Space.size(); i++ )
  {
    // Make sure that the ith dimensional coordinate is < the size of the ith dimension. 
    if( Ref[i] >= (int)Working_Space[i] )
      return false;  // Ref array has one coordinate which is too large.

    // When we find the negative entry in the Ref vector remember to stop calculating the offset.  Also check to make sure we haven't 
    // already seen a negative entry (there should only be one).  Plus, make sure the working_column start index and the working_column
    // size skip the negative value when being calculated.  All of this is kept track of with the boolean Found_Negative variable.
    if( Ref[i] < 0 )
    {
      // If this is the second negative value we've seen, quit.
      if( Found_Negative )
        return false;  // Ref array has too many negative values.

      // Remember what the offset is for moving one cell in the desired column.
      working_column.offset = Dimension_Space[i - 1];

      // Set the dimension in which the column extends.
      working_column.dimension = i;

      // Save the total number of column offsets that are possible in this dimension + 1.  Later we'll need to add the starting index.
      working_column.size = working_column.offset*( Working_Space[i] - 1 ) + 1;

      // Remember we've seen a negative value.
      Found_Negative = true;
    }
    else
    {
      // Calculate the index of our Data array which corresponds to the Ref column's beginning cell.
      working_column.start += Ref[i]*Dimension_Space[i - 1];
    }
  }

  // Add the column starting possition to the column size.

  working_column.size += working_column.start;

  // The function ran as expected (Ref input was OK).
  return true;
}

// Copies the passed vector's data into the column currently represented by working_column.  Scales the passed vector by the scale_value as
// the copy progresses.  If the copy takes place successfully TRUE is returned by the function.  Otherwise, if an error was encountered 
// the function will return FALSE.
template<class MULTI_ARRAY_DATA_TYPE>
bool Multi_Array<MULTI_ARRAY_DATA_TYPE>::Copy_to_Column( const vector<MULTI_ARRAY_DATA_TYPE>& Source, const double scale_value )
{
  // Make sure that the Source vector (source of data) is the same size as the column we want to copy to.  If not, return FALSE.
  if( Source.size() != Working_Space[working_column.dimension] )
    return false;

  // Copy the Source vector to the working_column.
  for( unsigned i = working_column.start; i < working_column.size; i += working_column.offset )
    Data[i] = scale_value*Source[(i - working_column.start)/working_column.offset];

  // Everything was copied OK, so return TRUE.
  return true;
}

// Copies the passed vector's data into the column currently represented by working_column using the passed arithmatic progression and 
// offset.  The working column's ith entry will be scale_value*Signal[(a+b*i+offset) % signal_size] where a+b*i is the arithmatic 
// progression.  If the copy takes place successfully TRUE is returned by the function.  Otherwise, if an error was encountered the 
// function will return FALSE.
template<class MULTI_ARRAY_DATA_TYPE>
bool Multi_Array<MULTI_ARRAY_DATA_TYPE>::Copy_to_Column( const vector<MULTI_ARRAY_DATA_TYPE>& signal, Arith_Prog& samples, 
                                                         const unsigned offset = 0, const double scale_value )
{
  // Make sure that the 'samples' arithmatic progression is doing arithmatic modulo the signal size.  If not, return false.
  if( signal.size() != samples.get_modulus() )
    return false;

  // Copy the Signal vector data to the working_column.
  samples.reset();
  for( unsigned i = working_column.start; i < working_column.size; i += working_column.offset )
  {
    Data[i] = scale_value*signal[ (samples.get_last_value() + offset) % signal.size() ];
    samples.next();
  }

  // Everything was copied OK, so return TRUE.
  return true;  
}

// Copies the passed function's returned data into the column currently represented by working_column using the passed arithmatic progression 
// and offset.  The working column's ith entry will be scale_value*Signal[(a+b*i+offset) % signal_size] where a+b*i is the arithmatic 
// progression.  If the copy takes place successfully TRUE is returned by the function.  Otherwise, if an error was encountered the 
// function will return FALSE.
template<class MULTI_ARRAY_DATA_TYPE>
bool Multi_Array<MULTI_ARRAY_DATA_TYPE>::Copy_to_Column( MULTI_ARRAY_DATA_TYPE (*Signal)(unsigned, int), Arith_Prog& samples, 
                                                         const unsigned offset = 0, const double scale_value )
{
  // Copy the Signal vector data to the working_column.
  samples.reset();
  for( unsigned i = working_column.start; i < working_column.size; i += working_column.offset )
  {
    Data[i] = scale_value*Signal( (samples.get_last_value() + offset) % samples.get_modulus(), -1 );
    samples.next();
  }

  // Everything was copied OK, so return TRUE.
  return true;  
}

// Calculates the mean of the working column.  Note that MULTI_ARRAY_DATA_TYPE must support addition, division by doubles, and 
// initialization to 0 in order for this function to be used.  The passed Average variable will get the average stored in it by reference.
template<class MULTI_ARRAY_DATA_TYPE>
void Multi_Array<MULTI_ARRAY_DATA_TYPE>::Column_Mean( MULTI_ARRAY_DATA_TYPE& Average ) const
{
  // Initialize the Average variable to 'zero'
  Average = 0.0;

  // Find the sum of the indicated column.
  for( unsigned i = working_column.start; i < working_column.size; i += working_column.offset )
    Average += Data[i];

  // Compute the average by dividing by the the number of Data cells summed.
  Average /= (double)Working_Space[working_column.dimension];
}

// This function finds the median of the working column.  Note that MULTI_ARRAY_DATA_TYPE must must have a comparison function COMPARE.  
// The passed Median variable will get the median stored in it by reference.  Here COMPARE(A,B) = TRUE means that A > B.  This algorithm 
// is a variant of quicksort.
template<class MULTI_ARRAY_DATA_TYPE>
void Multi_Array<MULTI_ARRAY_DATA_TYPE>::Column_Median( MULTI_ARRAY_DATA_TYPE& Median, 
                                                        bool (*COMPARE)(const MULTI_ARRAY_DATA_TYPE&, const MULTI_ARRAY_DATA_TYPE&) ) const
{
  unsigned median_index;                            // Index that the median column value will have after sorting.
  unsigned column_start = 0;                        // First cell of the column copy vector which we still have to search for the median.
  unsigned column_size;                             // Last cell of the column copy vector which we still have to search for the median + 1
  static vector<MULTI_ARRAY_DATA_TYPE> column_copy; // Copy of the column we want the median of.

  // If the column_copy vector is smaller then the current working column's size, allocate more memory for the column_copy vector.
  if( column_copy.capacity() < Working_Space[working_column.dimension] )
    column_copy.reserve( Working_Space[working_column.dimension] );

  // Remove all values from the column_copy vector.  Leaves memory allocated for the vector alone.
  column_copy.resize(0);

  // Copy the column under consideration.
  for( unsigned i = working_column.start; i < working_column.size; i += working_column.offset )
    column_copy.push_back( Data[i] );

  // Calculate where the median would be if the vector were sorted.  Set the column_size variable to the size of the column_copy vector.
  median_index = column_copy.size() / 2;
  column_size = column_copy.size();

  // Use a variant of quicksort to find the median.  Average case run time is Big_Oh(column_copy.size()).
  do {
    unsigned column_end = column_size - 1;  // Last cell in the column copy which might be smaller than the pivot element
    unsigned pivot_location = column_start; // Location of the pivot element in our copy of the column.

    // We'll always use column_copy[column_start] as our initial pivot element.  Here we put the pivot element in the proper vector cell.
    while( pivot_location < column_end )
      // If the pivot element > the next element, swap them.
      if( COMPARE(column_copy[pivot_location],column_copy[pivot_location + 1]) )  
      {
        // Swap the pivot element with the next column copy element and remember where the pivot element went.
        Swap( column_copy[pivot_location], column_copy[pivot_location + 1] );          
        ++pivot_location;
      }
      // Since the pivot element is <= the next element, the next element can be moved to the other end of the array
      else
      {
        // Swap the pivot element's neighbor which is >= the pivot to the other end of the array and remember its there.
        if( pivot_location + 1 < column_end )
	  Swap( column_copy[pivot_location + 1], column_copy[column_end] );
        --column_end;
      }

    // Recalculate the part of the array that it still makes sence to search for the median element in.
    if( pivot_location == median_index )  // In this case we're done!
      break;
    // If the median is smaller then the pivot element, set the column_size to the current pivot element location.
    if( pivot_location > median_index )
      column_size = pivot_location;     
    // If the median is bigger then the pivot element, set the column_start to be the pivot's larger neighbor. 
    else
      column_start = pivot_location + 1;

  } while( true );

  // Set the Median variable.
  Median = column_copy[median_index];
}

// Returns the Discrete Fourier Transform of the working column.  The DFT (or inverse DFT) of the working column is returned by reference 
// in the passed vector.  The passed bool variable is TRUE if the user wants to compute the DFT of the column, and FALSE if the user wants
// to compute the inverse DFT of the column.  Note that the MULTI_ARRAY_DATA_TYPE must support multiplication and addition so that the 
// DFT can actually be computed.  The DFT is calculated by the DFT_engine class which can be found in the 'DFT_engine.h' file. 
template<class MULTI_ARRAY_DATA_TYPE>
void Multi_Array<MULTI_ARRAY_DATA_TYPE>::Column_DFT( vector<MULTI_ARRAY_DATA_TYPE>& DFT, bool Forward ) const
{
  // Only compute the DFT (or inverse DFT) if a DFT_engine has been created.
  if( Dimensional_DFT != NULL )
  {
    // Copy the working column into the DFT_engine for the dimension in which the working column extends.
    unsigned i = 0;
    while( Dimensional_DFT->put_element(Data[working_column.start + i*working_column.offset], i) )
      ++i;

    // Compute the DFT (or inverse DFT) of the working column
    Dimensional_DFT->DFT(Forward, DFT_Dim_Map[working_column.dimension] );

    // Make sure that the passed DFT array is the correct size to receive the working column DFT data
    if( DFT.size() != Working_Space[working_column.dimension] )
      // If the passed DFT array isn't the right size, resize it.
      DFT.resize( Working_Space[working_column.dimension] );      

    // Copy the result of the DFT (or inverse DFT) into the passed array.
    Dimensional_DFT->get_data( DFT );
  }
}

// The DFT (or inverse DFT) of the working column is calculated and stored back in the working column.  The passed bool variable is TRUE 
// if the user wants to compute the DFT of the column, and FALSE if the user wants to compute the inverse DFT of the column.  Note that 
// the MULTI_ARRAY_DATA_TYPE must support multiplication and addition so that the DFT can actually be computed.  The DFT is calculated by 
// the DFT_engine class which can be found in the 'DFT_engine.h' file. 
template<class MULTI_ARRAY_DATA_TYPE>
void Multi_Array<MULTI_ARRAY_DATA_TYPE>::Column_DFT( bool Forward )
{
  // Only compute the DFT (or inverse DFT) if a DFT_engine has been created.
  if( Dimensional_DFT != NULL )
  {
    // Copy the working column into the DFT_engine for the dimension in which the working column extends.
    unsigned i = 0;
    while( Dimensional_DFT->put_element(Data[working_column.start + i*working_column.offset], i) )
      ++i;

    // Compute the DFT (or inverse DFT) of the working column
    Dimensional_DFT->DFT(Forward, DFT_Dim_Map[working_column.dimension] );

    // Copy the result of the DFT (or inverse DFT) back into the working column.
    i = 0;
    while( Dimensional_DFT->get_element(Data[working_column.start + i*working_column.offset], i) )
      ++i;

  }
}

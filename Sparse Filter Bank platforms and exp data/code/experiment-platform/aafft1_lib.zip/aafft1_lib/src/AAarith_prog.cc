/*
Copyright (c) <2011> <Mark Iwen>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, 
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software 
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/


#include <stdlib.h>
#include <time.h>
#include <math.h>

//////////////////////////////////////////////////////////////////////////////////////////
// ******************** SUPPORTING FUNCTIONS FOR Arith_Prog CLASS ********************* //
//////////////////////////////////////////////////////////////////////////////////////////

// This function takes two positive integers and returns their greatest common divisor.  It works based on the following Theorem 
// (An Introduction To The Theory of Numbers, by Ivan Niven, Herbert S. Zuckerman, and Hugh L. Montgomery, page 11):
// Given integers b and c > 0, we make use repeated application of the division algorithm to obtain a series of equations
// b = c*q_1 + r_1,         0 < r_1 < c,
// c = r_1*q_2 + r_2,       0 < r_2 < r_1,
// r_1 = r_2*q_3 + r_3,     0 < r_3 < r_2,
//     ...                       ...
// r_j-2 = r_j-1*q_j + r_j, 0 < r_j < r_j-1,
// r_j-1 = r_j*q_j+1.
// 
// The greatest common divisor of of b and c is r_j, the last non-zero remainder in the division process.
unsigned GCD( unsigned bigger, unsigned smaller )
{
  unsigned remainder;  // A temperary variable used to hold bigger modulo smaller (remainder of bigger/smaller).

  // If the 'smaller' variable is larger than the 'bigger' variable, swap their values. 
  if( bigger < smaller )
  {
    // Swap the 'bigger' variable with the 'smaller' variable
    remainder = bigger;
    bigger = smaller;
    smaller = remainder;
  }

  // If the smaller number is 0, return 0.
  if( smaller == 0 )
    return 0;

  // While the remainder of bigger/smaller isn't 0, continue to look for the GCD.
  while( (remainder = bigger % smaller) != 0 )
  {
    // If the remainder isn't zero, continue with the division algorithm.
    bigger = smaller;
    smaller = remainder;
  } 
 
  // The smaller variable will hold the GCD after the while loop.
  return smaller;    
}


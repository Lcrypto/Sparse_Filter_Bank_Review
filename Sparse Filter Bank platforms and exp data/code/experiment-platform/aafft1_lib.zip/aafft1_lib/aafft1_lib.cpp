#include "aafft1_lib.h"


Aafft1_lib::Aafft1_lib()
{
}

#ifndef AAFFT1_LIB_H
#define AAFFT1_LIB_H

#include "aafft1_lib_global.h"

class AAFFT1_LIBSHARED_EXPORT Aafft1_lib
{

public:
    Aafft1_lib();
};

#endif // AAFFT1_LIB_H

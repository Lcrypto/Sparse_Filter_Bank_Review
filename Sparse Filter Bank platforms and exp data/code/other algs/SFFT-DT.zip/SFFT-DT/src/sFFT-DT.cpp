// FFTw and Sparse FFT.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "fftw3.h"
//#include <Windows.h>
#include <iostream>
#include <cmath>
#include <complex>
#include <ctime>
#include <iomanip>
#include <omp.h>
#include <armadillo>

using namespace arma;


#define PI 3.14159265358979323846 
#define SHIFT_RANGE 401
#define MAXALIASING 3

using namespace std;

long timerFreq;
long counterAtStart,counterAtNow,counterTotalStart,counterTotalNow;


double randn (double mu, double sigma)
{
  double U1, U2, W, mult;
  static double X1, X2;
  static int call = 0;
 
  if (call == 1)
    {
      call = !call;
      return (mu + sigma * (double) X2);
    }
 
  do
    {
      U1 = -1 + ((double) rand () / RAND_MAX) * 2;
      U2 = -1 + ((double) rand () / RAND_MAX) * 2;
      W = pow (U1, 2) + pow (U2, 2);
    }
  while (W >= 1 || W == 0);
 
  mult = sqrt ((-2 * log (W)) / W);
  X1 = U1 * mult;
  X2 = U2 * mult;
 
  call = !call;
 
  return (mu + sigma * (double) X1);
}

void SVD_for_sig (int i, int real_i,int aliasing,fftw_complex **dw_f_Signal, vec &eig_val_collector)
{		

	vec S;
	cx_mat SyndromeMatrix = zeros<cx_mat>(aliasing, aliasing);

	for (int j=0;j<aliasing;j++){
		for(int k=0;k<aliasing;k++){
			SyndromeMatrix(j,k)=complex<double>(dw_f_Signal[j+k+2*MAXALIASING][real_i][0],dw_f_Signal[j+k+2*MAXALIASING][real_i][1]);				
		}
				
	}

	S=eig_sym(SyndromeMatrix.t()*SyndromeMatrix);	

	for(int k=0;k<aliasing;k++){
		eig_val_collector[i*MAXALIASING+k]=abs(S[k]);
	}

}
void Fro_for_sig (int i,int aliasing,fftw_complex **dw_f_Signal, vec &max_eig_val_collector)
{		

	vec S;
	cx_mat SyndromeMatrix = zeros<cx_mat>(aliasing, aliasing);

	for (int j=0;j<aliasing;j++){
		for(int k=0;k<aliasing;k++){
			SyndromeMatrix(j,k)=complex<double>(dw_f_Signal[j+k+2*MAXALIASING][i][0],dw_f_Signal[j+k+2*MAXALIASING][i][1]);				
		}				
	}


	max_eig_val_collector[i]=norm(SyndromeMatrix,"fro");


		
}

void CS_Recovery(int i,int N, int numOfcoli,int DownRatio, int DwNumber,cx_mat &AforRoots,fftw_complex *rec_Signal, fftw_complex **dw_f_Signal)
{		
		int j,k,iter,numOfcandA,flag,pos,suppOfCS,suppOfSP;
		complex<double> sum;

		cx_mat measurements = zeros<cx_mat>(numOfcoli, 1),candA,pcandA,rec_x,residue,corr,A_Supp_1,A_Supp_2,corr_Supp_1,corr_Supp_2;
		cx_mat tmcoef = zeros<cx_mat>(numOfcoli, 1);
		cx_mat ErrMatrix = zeros<cx_mat>(numOfcoli, numOfcoli);
		cx_mat candidate_roots = zeros<cx_mat>(numOfcoli, 1);
		uvec pos_collector = zeros<uvec>(numOfcoli, 1);
		vec val_collector = zeros<vec>(DownRatio,1);
		uvec indices,Supp,tempSupp,indices_Supp_2;
		uvec setOfCSCol = zeros<uvec>(numOfcoli*6,1);
		cx_mat residul_norm = zeros<cx_mat>(1, 1);




        if(numOfcoli == 1)
        {
              cx_mat A1 = zeros<cx_mat>(2, 2);
              cx_mat A2 = zeros<cx_mat>(2, 2);
              cx_mat V1 = zeros<cx_mat>(1, 1);
              cx_mat V2 = zeros<cx_mat>(1, 1);
              cx_mat V3 = zeros<cx_mat>(1, 1);
              A1[0] = complex<double>(dw_f_Signal[0][i][0],dw_f_Signal[0][i][1]);
              A1[1] = complex<double>(dw_f_Signal[1][i][0],dw_f_Signal[1][i][1]);
              A1[2] = complex<double>(dw_f_Signal[16][i][0],dw_f_Signal[16][i][1]);
              A1[3] = complex<double>(dw_f_Signal[15][i][0],dw_f_Signal[15][i][1]);

              cx_mat U,V;
              colvec S;
              double cj,nj;
              svd(U,S,V,A1);
              A2 = V.t();
              V1 = A2(0,0);
              V2 = A2(0,1);
              V3 = (pinv(V1))*V2;
              cj = atan2(-V3.mem[0].imag(), V3.mem[0].real());
              if(cj < 0)
              {
                  cj = cj +2*PI;
              }

              nj = round(cj/(2*PI/DownRatio));

              A1[0] = complex<double>(dw_f_Signal[0][i][0],dw_f_Signal[0][i][1]);
              A1[0] = complex<double>(dw_f_Signal[0][i][0],dw_f_Signal[0][i][1]);
              A1[0] = complex<double>(dw_f_Signal[0][i][0],dw_f_Signal[0][i][1]);
        }

        if(numOfcoli == 2)
         {
            cx_mat A1 = zeros<cx_mat>(3, 3);
            cx_mat A2 = zeros<cx_mat>(3, 3);
            cx_mat V1 = zeros<cx_mat>(2, 2);
            cx_mat V2 = zeros<cx_mat>(2, 2);
            cx_mat V3 = zeros<cx_mat>(2, 2);

              A1[0] = complex<double>(dw_f_Signal[0][1][0],dw_f_Signal[0][1][1]);
              A1[1] = complex<double>(dw_f_Signal[1][1][0],dw_f_Signal[1][1][1]);
              A1[2] = complex<double>(dw_f_Signal[2][1][0],dw_f_Signal[2][1][1]);
              A1[3] = complex<double>(dw_f_Signal[16][1][0],dw_f_Signal[16][1][1]);
              A1[4] = complex<double>(dw_f_Signal[0][1][0],dw_f_Signal[0][1][1]);
              A1[5] = complex<double>(dw_f_Signal[1][1][0],dw_f_Signal[1][1][1]);
              A1[6] = complex<double>(dw_f_Signal[17][1][0],dw_f_Signal[17][1][1]);
              A1[7] = complex<double>(dw_f_Signal[16][1][0],dw_f_Signal[16][1][1]);
              A1[8] = complex<double>(dw_f_Signal[0][1][0],dw_f_Signal[0][1][1]);

              cx_mat U,V;
              colvec S;
              svd(U,S,V,A1);
              A2 = V.t();

              V1 = A2.rows(0,1);
              V1 = V1.cols(0,1);
              V2 = A2.rows(1,2);
              V2 = V2.cols(0,1);
              V3 = (pinv(V1))*V2;


              A1[0] = complex<double>(dw_f_Signal[0][1][0],dw_f_Signal[0][1][1]);
              A1[1] = complex<double>(dw_f_Signal[1][1][0],dw_f_Signal[1][1][1]);
              A1[2] = complex<double>(dw_f_Signal[2][1][0],dw_f_Signal[2][1][1]);

        }




		for (j=0;j<numOfcoli;j++){
			measurements[j]=complex<double>(-dw_f_Signal[j+numOfcoli][i][0],-dw_f_Signal[j+numOfcoli][i][1]);
				
			for(k=0;k<numOfcoli;k++){
				ErrMatrix(j,k)=complex<double>(dw_f_Signal[j+k][i][0],dw_f_Signal[j+k][i][1]);		
					
			}
				
		}

		tmcoef=pinv(ErrMatrix)*measurements;

		for(j=0;j<DownRatio;j++){
			sum=complex<double>(0,0);
			complex<double> cand_roots(cos(2.0*PI*(DwNumber*j+i)/(double)N),sin(2.0*PI*(DwNumber*j+i)/(double)N));
			sum=pow((complex<double>)cand_roots,numOfcoli);
			for(k=0;k<numOfcoli;k++){
				sum=sum+pow((complex<double>)cand_roots,k)*tmcoef[k];
			}
			val_collector[j]=std::norm(sum);
		}
		indices = sort_index(val_collector);
	

		for (j=0;j<numOfcoli;j++){
			pos_collector[j]=indices[j];
		}
		

			//---------------------------------------Normalized Measurement due to Shift------------------------------------------ 
			

		measurements.resize(MAXALIASING*3,1);
			
			
		for (j=0;j<MAXALIASING*3;j++){
			measurements[j]=complex<double>(dw_f_Signal[j+2*MAXALIASING][i][0],dw_f_Signal[j+2*MAXALIASING][i][1]);
			measurements[j]=measurements[j]/(complex<double>( cos(2*PI*i*SHIFT_RANGE*j/N)  , sin(2*PI*i*SHIFT_RANGE*j/N) )  );
		}
		//cout<<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
		numOfcandA=0;
			
		


			
		for (j=0;j<numOfcoli;j++){
			for (k=-1;k<=1;k++){
				flag=0;
				for (pos=0;pos<numOfcandA;pos++){
					if(setOfCSCol[pos]== ((pos_collector[j]+k)%DownRatio) ){
						flag=1;
					}
				}

				if(flag==0){
					setOfCSCol[numOfcandA]=(pos_collector[j]+k)%DownRatio;
					++numOfcandA;
				}

			}
		} 
			
		candA.resize(MAXALIASING*3,numOfcandA);

		for (j=0;j<numOfcandA;j++){
			for(k=0;k<MAXALIASING*3;k++){
				candA(k,j)=AforRoots(k,setOfCSCol[j]);
					
			}
				
		}
		//cout<<"---------------------"<<endl;


		//---------------------------------------Sparse Signal Recovery Algorithm---------------------------------------------
		suppOfCS=(int)min((double)numOfcandA,(double)2*numOfcoli);
		rec_x.resize(numOfcandA,1);
		residue.resize(MAXALIASING*3,1);
		corr.resize(numOfcandA,1);
		Supp.resize(suppOfCS,1);
		tempSupp.resize(suppOfCS,1);
		indices.resize(numOfcandA,1);
			
		A_Supp_1.resize(MAXALIASING*3,numOfcoli);
			
		corr_Supp_1.resize(numOfcoli,1);
			
		residue=measurements;
		pcandA=pinv(candA);
		corr=pcandA*residue;
			

		indices = sort_index(abs(corr),1);
		//indices.print();
		for (j=0;j<numOfcoli;j++){
			Supp[j]=indices[j];
		}
				
		for (j=0;j<numOfcoli;j++){
			A_Supp_1.col(j)=candA.col(Supp[j]);
		}

		corr_Supp_1=pinv(A_Supp_1)*residue;
			
		residue=measurements-A_Supp_1*corr_Supp_1;
			
			
		for (iter=0;iter<numOfcoli;iter++){
			
			residul_norm=residue.t()*residue;
			if( norm(residul_norm.mem[0])<0.01){
				break;
			}
			suppOfSP=numOfcoli;
			corr=pcandA*residue;
			indices = sort_index(abs(corr),1);
				
				
			for (j=numOfcoli;j<suppOfCS;j++){
				flag=0;
				for (k=0;k<suppOfSP;k++ ){
					if(Supp[k]==indices[j-numOfcoli]){
						flag=1;
						break;
					}
				}
				if(flag==0){
					Supp[j]=indices[j-numOfcoli];
					++j;
				}
			}
				
			A_Supp_2.resize(MAXALIASING*3,suppOfSP);
			corr_Supp_2.resize(suppOfSP,1);
			indices_Supp_2.resize(suppOfSP,1);
			

			for (j=0;j<suppOfSP;j++){
				A_Supp_2.col(j)=candA.col(Supp[j]);
			}
			
			corr_Supp_2=pinv(A_Supp_2)*measurements;
				
				
			indices_Supp_2= sort_index(abs(corr_Supp_2),1);

				
			for (j=0;j<numOfcoli;j++){
				tempSupp[j]=Supp[indices_Supp_2[j]];
			}
					
			for (j=0;j<numOfcoli;j++){
				Supp[j]=tempSupp[j];
			}
				
			for (j=0;j<numOfcoli;j++){
				A_Supp_1.col(j)=candA.col(Supp[j]);
			}

			corr_Supp_1=pinv(A_Supp_1)*measurements;
			residue=measurements-A_Supp_1*corr_Supp_1;
				
		}
			
			
		for (j=0;j<numOfcoli;j++){
			rec_Signal[i+DwNumber*setOfCSCol[Supp[j]]][0]=corr_Supp_1[j].real()*DownRatio;
			rec_Signal[i+DwNumber*setOfCSCol[Supp[j]]][1]=corr_Supp_1[j].imag()*DownRatio;
		}	
		
}


int _tmain(int argc, _TCHAR* argv[])
{
//	if(argc!=2){
//		cout<<"Wrong parameters. Please follow the format: sFFT-DT.exe [Outputfile(Store Time Domain Signal)]"<<endl;
//		exit(0);
//	}
	//------------------parameter setting------------------------------
	int N_index,K_index;
	char fileName[300];
    int i,q;
	long decodeDulation;

//	wcstombs(fileName,argv[1],wcslen(argv[1]));
//	fileName[wcslen(argv[1])]='\0';

	FILE *fp=NULL;

//	fp=fopen(fileName,"r");

    fp=fopen("/root/SFFT-DT/src/3.txt","r+");

	if(fp!=NULL){
		if(fp!=NULL){
			fscanf(fp,"%d",&N_index);
			fscanf(fp,"%d",&K_index);
		}
	}else{
		cout<<"File does not exist!"<<endl;
		exit(0);
	}
	
	int N=(int)pow((double)2,(double)N_index);
	int K=(int)pow((double)2,(double)K_index);

	
	 
	if(N_index-K_index-5<0){
		cout<<"N/K should be larger than 2^5!"<<endl;
		exit(0);
	}

	int DownRatio=(int)pow((double)2,(double)N_index-K_index-5);

	fftw_complex *t_Signal, *f_Signal, **dw_t_Signal,**dw_f_Signal;
	fftw_complex *rec_Signal;
    fftw_plan p_dw_forward[MAXALIASING*7];

//	QueryPerformanceFrequency(&timerFreq);
	
//	QueryPerformanceCounter(&counterAtStart);



	t_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);
	f_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);

	memset(t_Signal,0,sizeof(fftw_complex) * N);
	memset(f_Signal,0,sizeof(fftw_complex) * N);


	for (i=0;i<N;i++){
		fscanf(fp,"%lf",&t_Signal[i][0]);
		fscanf(fp,"%lf",&t_Signal[i][1]);
	}
	
	fclose(fp);
	
//	QueryPerformanceCounter(&counterAtNow);

//	decodeDulation=( ((counterAtNow.QuadPart - counterAtStart.QuadPart) * 1000)/timerFreq.QuadPart);
	cout<<"Cost Time (Reading signals from File):"<<(double)decodeDulation/1000<<endl;

	int DwNumber=N/DownRatio;

	int j,tempInt;
	int isPruningflag=1;
	
    int *dPostoPos=NULL,*numOfsig=NULL;
	double **dw_mag=NULL,error,total_energy,*root_err=NULL,optVar,noiseVar;
	int *totalSupp1=NULL,*totalSupp2=NULL,*no_aliasing_Supp1=NULL,*aliasing_Supp1=NULL,*GroundTruth=NULL;
	int *posOfsupp1=NULL,*posOfsupp2=NULL,sumOfsupp1=0,sumOfsupp2=0,*posSequence=NULL;
	



	cx_mat residul_norm = zeros<cx_mat>(1, 1);
	cx_mat measurements = zeros<cx_mat>(MAXALIASING, 1),candidate_roots,corr,A_Supp_1,A_Supp_2,corr_Supp_1,corr_Supp_2;
	cx_mat tmcoef = zeros<cx_mat>(MAXALIASING, 1);
	cx_mat ErrMatrix = zeros<cx_mat>(MAXALIASING, MAXALIASING),rec_x,residue;
	cx_cube rootMatrix = zeros<cx_cube>(MAXALIASING, MAXALIASING,DwNumber);
	complex<double> coef[4],sum,initialized_m(0,0),cx_mean,cx_sum;
	cx_mat eig_vec;
	mat tempround=zeros<mat>(1, 1);
	vec eig_val;
	vec eig_val_collector = zeros<vec>(MAXALIASING*K,1),val_collector = zeros<vec>(DownRatio,1);
	vec max_eig_val_collector = zeros<vec>(DwNumber,1);
	uvec pos_collector,setOfCSCol,Supp,indices_Supp_2,tempSupp;
	cx_mat AforRoots = zeros<cx_mat>(3*MAXALIASING, DownRatio),candA;
	


	

	int aliasing=MAXALIASING;


	//------------------parameter setting------------------------------


  


	cout<<"Dimension:"<<N<<endl<<"Sparisty:"<<K<<endl;


	dw_mag=new double *[MAXALIASING*5];
	for (i=0;i<MAXALIASING*5;i++){
		dw_mag[i]=new double[DwNumber];
	}



	dPostoPos=new int[DwNumber];

	totalSupp1=new int[DwNumber];

	no_aliasing_Supp1=new int[DwNumber];
	aliasing_Supp1=new int[DwNumber];
	posOfsupp1=new int[DwNumber];

	posSequence=new int[DwNumber];

	root_err=new double[DownRatio];

	numOfsig=new int [DwNumber];

	GroundTruth=new int [K]; 


//-------------------------------Initialization---------------------------------------

	

	for(i=0;i<DwNumber;i++)
		totalSupp1[i]=0;

	for(i=0;i<DwNumber;i++){
		no_aliasing_Supp1[i]=0;
        aliasing_Supp1[i]=0;
		dPostoPos[i]=0;
	}

	for(i=0;i<DwNumber;i++)
		posOfsupp1[i]=-1;



	


	rec_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);


    dw_t_Signal = (fftw_complex**) fftw_malloc(sizeof(fftw_complex*)*7*MAXALIASING);
    for (i=0;i<7*MAXALIASING;i++){
		dw_t_Signal[i] = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * DwNumber);
	}
	
    dw_f_Signal = (fftw_complex**) fftw_malloc(sizeof(fftw_complex*)*7*MAXALIASING);
    for (i=0;i<7*MAXALIASING;i++){
		dw_f_Signal[i] = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * DwNumber);
	}

	for (i=0;i<DwNumber;i++){
		numOfsig[i]=0;
	}

	for (i=0;i<3*MAXALIASING;i++){
		for(j=0;j<DownRatio;j++){
			complex<double> exp_term(cos(2.0*PI*(double)(j*DwNumber)*(i*SHIFT_RANGE)/(double)N),sin(2.0*PI*(double)(j*DwNumber)*(i*SHIFT_RANGE)/(double)N));
			AforRoots(i,j)=exp_term;
		}
	}


	memset(rec_Signal,0,sizeof(fftw_complex) * N);




    for (i=0;i<7*MAXALIASING;i++){
		p_dw_forward[i] = fftw_plan_dft_1d(N/DownRatio, dw_t_Signal[i], dw_f_Signal[i], FFTW_FORWARD, FFTW_ESTIMATE);	
	}



	
	//--------------------------------Initialization------------------------------------------
	
//	QueryPerformanceCounter(&counterTotalStart);
	
	
	for (j=0;j<2*MAXALIASING;j++){
		#pragma omp parallel for private( i)
		for (i=0;i<DwNumber;i++){		
			dw_t_Signal[j][i][0]=t_Signal[j+i*DownRatio][0];
			dw_t_Signal[j][i][1]=t_Signal[j+i*DownRatio][1];		
		}
	}
	
	
	for (j=2*MAXALIASING;j<5*MAXALIASING;j++){
		tempInt=(SHIFT_RANGE*(j-2*MAXALIASING));
		#pragma omp parallel for private( i )
		for (i=0;i<DwNumber;i++){
			dw_t_Signal[j][i][0]=t_Signal[(tempInt+i*DownRatio)%N][0];
			dw_t_Signal[j][i][1]=t_Signal[(tempInt+i*DownRatio)%N][1];
		}
	}

    for (j=5*MAXALIASING;j<7*MAXALIASING;j++){
        #pragma omp parallel for private( i)
        for (i=0;i<DwNumber;i++){
            q=i*DownRatio - (j-5*MAXALIASING);
            if(q<0)
            {
                q = 8192 + q;
            }
            dw_t_Signal[j][i][0]=t_Signal[q][0];
            dw_t_Signal[j][i][1]=t_Signal[q][1];
        }
    }



	#pragma omp parallel for private( i ) 
    for (i=0;i<7*MAXALIASING;i++){
		fftw_execute(p_dw_forward[i]); 		
	}



	
	#pragma omp parallel for private( i ) schedule(static) 
	for(int i=0;i<DwNumber;i++){
		Fro_for_sig (i,aliasing,dw_f_Signal,max_eig_val_collector);
	}

	uvec max_indices = sort_index(max_eig_val_collector,1);



	#pragma omp parallel for private( i ) schedule(static) 
	for(int i=0;i<K;i++){
		SVD_for_sig (i,max_indices[i],aliasing,dw_f_Signal,eig_val_collector);
	}


	uvec indices = sort_index(eig_val_collector,1);
	for (i=0;i<K;i++){
		++numOfsig[max_indices[(int)indices[i]/MAXALIASING]];
	}
	


	
	for(i=0;i<DwNumber;i++){
		if(numOfsig[i]>0){
			CS_Recovery(i,N, numOfsig[i],DownRatio,DwNumber,AforRoots,rec_Signal,dw_f_Signal);		
		}
	}
		

	
//	QueryPerformanceCounter(&counterTotalNow);

	//--------------------------------------------------------------------------
	


//	decodeDulation=( ((counterTotalNow.QuadPart - counterTotalStart.QuadPart) * 1000)/timerFreq.QuadPart);

	
	cout<<"Cost Time (sFFT-DT):"<<setprecision (5)<<(double)decodeDulation/1000<<endl;
		
	
	fftw_plan p_forward;
	p_forward = fftw_plan_dft_1d(N, t_Signal,f_Signal, FFTW_FORWARD, FFTW_ESTIMATE);	
//	QueryPerformanceCounter(&counterAtStart);
	fftw_execute(p_forward); 
//	QueryPerformanceCounter(&counterAtNow);

//	decodeDulation=( ((counterAtNow.QuadPart - counterAtStart.QuadPart) * 1000)/timerFreq.QuadPart);
	
	cout<<"Cost Time (FFTw):"<<(double)decodeDulation/1000<<endl;
	//------------------------------------------Error Calculation---------------------------------------



	 

	
	 error=0;
	 total_energy=0;


	 cx_mean=complex<double>(0,0);
	
	 for (i=0;i<N;i++){
		cx_mean=cx_mean+complex<double>(f_Signal[i][0],f_Signal[i][1]);
	 }
	 cx_mean=cx_mean/complex<double>(N,0);

	 cx_sum=complex<double>(0,0);

	 optVar=0;
	
	 for (i=0;i<N;i++){
		 cx_sum=complex<double>(f_Signal[i][0]-cx_mean.real(),f_Signal[i][1]-cx_mean.imag()  );
		 optVar=optVar+abs(cx_sum*cx_sum);
	 }



	
	 cx_mean=complex<double>(0,0);
	
	 for (i=0;i<N;i++){
		cx_mean=cx_mean+complex<double>(rec_Signal[i][0]-f_Signal[i][0],rec_Signal[i][1]-f_Signal[i][1]);
	 }
	 cx_mean=cx_mean/complex<double>(N,0);

	 cx_sum=complex<double>(0,0);

	 noiseVar=0.0000000001;

	 for (i=0;i<N;i++){
		 cx_sum=complex<double>(rec_Signal[i][0]-f_Signal[i][0]-cx_mean.real(),   rec_Signal[i][1]- f_Signal[i][1]-cx_mean.imag());
		 noiseVar=noiseVar+abs(cx_sum*cx_sum);
	 }



	cout<<"Total SNR: "<<(double)10*log10(optVar/noiseVar)<<endl;





	cout<<"The Ratio of K to N:  "<<(double)K*100/N<<"%"<<endl;

	//---------------------------------------------------------------------------------------------------









    for (i=0;i<7*MAXALIASING;i++){
		fftw_destroy_plan(p_dw_forward[i]);
	}

	
	if(dw_t_Signal!=NULL){
        for (i=0;i<7*MAXALIASING;i++){
			fftw_free(dw_t_Signal[i]);
		}
		fftw_free(dw_t_Signal);
		dw_t_Signal=NULL;
	}
	if(dw_f_Signal!=NULL){
        for (i=0;i<7*MAXALIASING;i++){
			fftw_free(dw_f_Signal[i]);
		}
		fftw_free(dw_f_Signal);
		dw_f_Signal=NULL;
	}



	if(dw_mag!=NULL){
        for (i=0;i<7*MAXALIASING;i++){
			delete [] dw_mag[i];
		}
		delete [] dw_mag;
		dw_mag=NULL;
	}



	if(totalSupp1!=NULL)
		delete [] totalSupp1;
	totalSupp1=NULL;


	if(posSequence!=NULL)
		delete [] posSequence;
	posSequence=NULL;

	if(no_aliasing_Supp1!=NULL)
		delete [] no_aliasing_Supp1;
	no_aliasing_Supp1=NULL;


	if(posOfsupp1!=NULL)
		delete [] posOfsupp1;
	posOfsupp1=NULL;


	if(aliasing_Supp1!=NULL)
		delete [] aliasing_Supp1;
	aliasing_Supp1=NULL;


	if(dPostoPos!=NULL)
		delete [] dPostoPos;
	dPostoPos=NULL;

	if(root_err!=NULL)
		delete [] root_err;
	root_err=NULL;

	if(numOfsig!=NULL)
		delete [] numOfsig;
	numOfsig=NULL;
	
	if(GroundTruth!=NULL)
		delete [] GroundTruth;
	GroundTruth=NULL;



	fftw_free(t_Signal); 
	fftw_free(f_Signal);
	fftw_free(rec_Signal);
	fftw_free(dw_t_Signal);


	
	system("pause");

	return 0;
}



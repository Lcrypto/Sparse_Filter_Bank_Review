// Benchmark.cpp : �w�q�D���x���ε{�����i�J�I�C
//

#include "stdafx.h"
#include <iostream>
#include <cmath>
#include <ctime>
#include "fftw3.h"

using namespace std;
/*
double randn (double mu, double sigma)
{
  double U1, U2, W, mult;
  static double X1, X2;
  static int call = 0;

  if (call == 1)
    {
      call = !call;
      return (mu + sigma * (double) X2);
    }

  do
    {
      U1 = -1 + ((double) rand () / RAND_MAX) * 2;
      U2 = -1 + ((double) rand () / RAND_MAX) * 2;
      W = pow (U1, 2) + pow (U2, 2);
    }
  while (W >= 1 || W == 0);

  mult = sqrt ((-2 * log (W)) / W);
  X1 = U1 * mult;
  X2 = U2 * mult;

  call = !call;

  return (mu + sigma * (double) X1);
}

int _tmain(int argc, _TCHAR* argv[])
{
    int i,pos;

    //if(argc<6){
    //    cout<<"Too few parameters. Please follow the format: Benchmark.exe [N] [K] [dB] [Outputfile(Store Time Domain Signal)] [Outputfile(Store Frequency Domain Signal)]"<<endl;
    //    exit(0);
    //}

    //int N_index=_wtoi(argv[1]);
    int N_index = 12;
    int N=(int)pow((double)2,(double)N_index);


    if(N<=0){
        cout<<"Wrong parameter: N is negetive or zero."<<endl;
    }

    //int K_index=_wtoi(argv[2]);
    int K_index = 4;
    int K=(int)pow((double)2,(double)K_index);
    if(K<=0){
        cout<<"Wrong parameter: K is negetive or zero."<<endl;
    }

    if(K>N){
        cout<<"Wrong parameter: K>N."<<endl;
        exit(0);
    }

    //double signaldb=_wtof(argv[3]),signal_var;
    double signaldb= 30,signal_var;

    char fileName[300],filename_freq[300];
    //wcstombs(fileName,argv[4],wcslen(argv[4]));
    //fileName[wcslen(argv[4])]='\0';
    //wcstombs(filename_freq,argv[5],wcslen(argv[5]));
    //filename_freq[wcslen(argv[5])]='\0';



    fftw_complex *f_Signal=NULL;
    f_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);

    srand((unsigned int)time(NULL) );
    signal_var=sqrt((double)pow((double)10,((double)signaldb/10.0))*(N-K)/K);

    for (i=0;i<N;i++){
        f_Signal[i][0]=0;
        f_Signal[i][1]=0;
    }

    i=0;
    f_Signal[1][0]=signal_var*randn(0,1.0);
    f_Signal[1][1]=signal_var*randn(0,1.0);
    i++;
    f_Signal[1537][0]=signal_var*randn(0,1.0);
    f_Signal[1537][1]=signal_var*randn(0,1.0);
    i++;

    while(i<K){
        pos = ((rand() << 15) +rand()) % N;
        if (f_Signal[pos][0]==0){
            f_Signal[pos][0]=signal_var*randn(0,1.0);
            f_Signal[pos][1]=signal_var*randn(0,1.0);
            i++;

        }

    }

    for (i=0;i<N;i++){
        if (f_Signal[i][0]==0){
            f_Signal[i][0]=randn(0,1.0);
            f_Signal[i][1]=randn(0,1.0);
        }
    }

    fftw_complex *t_Signal=NULL;
    fftw_plan p_backward;

    t_Signal = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);
    p_backward = fftw_plan_dft_1d(N, f_Signal, t_Signal, FFTW_BACKWARD, FFTW_ESTIMATE);

    fftw_execute(p_backward);


    for(i=0;i<N;i++){
        t_Signal[i][0]=t_Signal[i][0]/N;
        t_Signal[i][1]=t_Signal[i][1]/N;
    }

    FILE *fp;
    //fp=fopen(fileName,"w");
    fp=fopen("3.txt","w");
    if (fp!=NULL){
        fprintf(fp,"%d \n",N_index);
        fprintf(fp,"%d \n",K_index);
        for (i=0;i<N;i++){
            fprintf(fp,"%f %f \n",t_Signal[i][0],t_Signal[i][1]);
        }
    }

    fclose(fp);

    fp=NULL;
    //fp=fopen(filename_freq,"w");
    fp=fopen("4.txt","w");
    if (fp!=NULL){
        fprintf(fp,"%d \n",N_index);
        fprintf(fp,"%d \n",K_index);
        for (i=0;i<N;i++){
            fprintf(fp,"%f %f \n",f_Signal[i][0],f_Signal[i][1]);
        }
    }

    fclose(fp);

    fftw_free(f_Signal);
    fftw_free(t_Signal);

    return 0;
}

*/

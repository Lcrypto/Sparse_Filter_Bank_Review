/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <complex.h>
#include <fftw3.h>
#include <stdint.h>
#include <omp.h>

/*N point 1-d FFT based on FFTW3.3*/
void fft(double complex * fft_in, double complex * fft_out, uint32_t B)
{

     /*fftw_plan variable */
     fftw_plan p;
     /*Builds the plan with mutual exclusion cause the plan functions are not reentrant */




    #ifdef WITH_OPENMP
     #pragma omp critical(fftw_plan)
     #endif     
{
          p = fftw_plan_dft_1d(B, (fftw_complex *) fft_in,
                               (fftw_complex *) fft_out, FFTW_FORWARD,
                               FFTW_ESTIMATE);
     }
     /*Performs FFT */
     fftw_execute(p);
     /*Destroys plan */
     #ifdef WITH_OPENMP
     #pragma omp critical(fftw_plan)
     #endif
     {
          fftw_destroy_plan(p);
     }

}


/*N point 1-d IFFT based on FFTW3.3*/
void ifft(double complex * fft_in, double complex * fft_out, uint32_t B)
{

     /*fftw_plan variable */
     fftw_plan p;
     /*Builds the plan */
     p = fftw_plan_dft_1d(B, (fftw_complex *) fft_in,
                          (fftw_complex *) fft_out, FFTW_BACKWARD,
                          FFTW_ESTIMATE);
     /*Performs FFT */
     fftw_execute(p);
     /*Destroys plan */
     fftw_destroy_plan(p);

}

/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <complex.h>


#ifdef IS_IPP

#include <ippvm.h>

#endif

/*Modular inverse x*x1=(1 mod 2^p) for p>=1
through Little's Fermat theorem and binary exponentiation
*/
uint32_t two_pow_mod_inverse(uint32_t x, uint8_t p)
{

     uint32_t m;


     uint8_t iterations;
     uint8_t k;
     uint32_t x1;

     /*If x is not odd */
     if (!(x & 1))
          return -1;

     /*Trivial conditions */
     if (p == 0)
          return 0;

     if ((p == 1))
          return x;



     /*Modulus */
     m = 1 << p;

     /*Number of iterations a^(-1)=a^(2^(p-1)-1)(1 mod m) */
     iterations = p - 2;

     /*Initial value */
     x1 = x;
     /*Iterations of the binary exponentiation algorithm */
     for (k = 0; k < iterations; k++) {
          /*C computes the products as mod-32 */
          x1 = (x1 * x1) & (m - 1);
          x1 = (x1 * x) & (m - 1);
     }
     /*Modular inverse */
     return x1;

}




//double min(double* array, uint32_t size){
//    // returns the minimum value of array
//     double minimum;
//
//
//     minimum = array[0];
//     uint32_t jj;
//
//    for (jj = 1; jj < size; jj++){
//      if (minimum > array[jj]) {
//            minimum = array[jj];
//        }
//    }
//    return minimum;
//}


////Computes exp(-j*2*pi*n/2N)
//double complex cexpm( uint32_t n, uint32_t N,int8_t s){
//
//    double x;
//    double complex y ;
//
//
//    x=(double)s*I*2*M_PI*(double)(n)/(double)(N);
//
//    #ifdef IS_ISPP
//    ippsSinCos_64f_A26 (&x, (double *)(&y)+1, (double *)(&y), 1);
//
//    #else
//
//    y=cos(x)+I*sin(x);
//
//    #endif
//
//    return y;
//
//
//}



int32_t compare_descending(const void *a, const void *b){

    double x = *(double *) a;
double y = *(double *) b;

if (x < y) return 1;
else if (x > y) return -1; return 0;


}

/*compare function for the linear search of indexes*/
int32_t compare_index(const void *a, const void *b)
{

     uint32_t x = *(uint32_t *) a;
     uint32_t y = *(uint32_t *) b;


     return x - y;

}

/*compare function for the linear search of indexes*/
int32_t compare_index2(const void *a, const void *b)
{

     uint32_t x = *(uint32_t *) a;
     uint32_t y = *(uint32_t *) b;


     return y - x;

}



/*Sinc function*/
 double sinc(double x)
{



     if (x == 0)
          return 1.0;

     return sin(M_PI * x) / (M_PI * x);

}

 double normcdf(double x)
{

     double p;

     p = 0.5 * erfc(-x / sqrt(2.0));


     return p;

}


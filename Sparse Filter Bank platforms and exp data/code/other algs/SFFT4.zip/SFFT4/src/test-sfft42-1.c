/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <termios.h>
#include <search.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "sfft4.h"
#include "fft.h"
#include "estimate-values.h"
#include "timer.h"
#include "gnuplot_i.h"


#include <math.h>

#include <pthread.h>



 //#define FULL_OUTPUT

/* sleep until a key is pressed and return value. echo = 0 disables key echo. */
int keypress(unsigned char echo)
{
    struct termios savedState, newState;
    int c;

    if (-1 == tcgetattr(STDIN_FILENO, &savedState))
    {
        return EOF;     /* error on tcgetattr */
    }

    newState = savedState;

    if ((echo = !echo)) /* yes i'm doing an assignment in an if clause */
    {
        echo = ECHO;    /* echo bit to disable echo */
    }

    /* disable canonical input and disable echo.  set minimal input to 1. */
    newState.c_lflag &= ~(echo | ICANON);
    newState.c_cc[VMIN] = 1;

    if (-1 == tcsetattr(STDIN_FILENO, TCSANOW, &newState))
    {
        return EOF;     /* error on tcsetattr */
    }

    c = getchar();      /* block (withot spinning) until we get a keypress */

    /* restore the saved state */
    if (-1 == tcsetattr(STDIN_FILENO, TCSANOW, &savedState))
    {
        return EOF;     /* error on tcsetattr */
    }

    return c;
}



int main()
{

     double          alpha, supp_reduction,
                     delta;

     double          elapsed_time_fftw,
                     elapsed_time_sfft;

     uint32_t        ii,
                     jj,
                     N,
                     nk,
                     suppz_hat,
                     *wz_hat,
                     *ws;

     uint32_t       *aux_index_p,
                    found_indexes;
     size_t          aux_nelp;
     double complex  aux_value;

     uint32_t        aux_index;


     uint8_t         retcond;

     uint8_t         p;
     double complex *x,
            *z_hat;
     double         *amps;
     double         *plot_points_y;
     double         *plot_points_x;

     double          rmse,
                     rmsei,
                     maxrmse;

     double complex  worst_amp,
            real_worst_amp;;
     uint32_t        worst_index;


     double          s;

     uint32_t        Rloc,
                     Rest,
                     Rsfft;
     uint8_t         mlog2_epsilon_l,mlog2_epsilon_e;

     uint32_t        reps;

     gnuplot_ctrl   *h1;





     reps = 10;



     nk = 50;		// Number of sparse components
     p =13 ;
     N = 1 << p;			// Number of points


     alpha = 1.0;		// Parameter of flat window
     delta = 1e-8;		// Error parameter
     supp_reduction=1.0;//log(((double)N)/delta); //Factor for support reduction
     Rloc = (uint32_t)floor(log2(log2((double)N)));			// Number of location loops
     s = 0.1;			// Threshold for location is s*M_PI
     Rest = 12;			// Number of estimation loops Higher
     // values improves the precision of
     // estimation
     //Rsfft = (uint32_t)ceil(log2((double)nk)/(log2(log2((double)nk))));
     Rsfft = (uint32_t)floor(log2((double)nk));
     //Rsfft=1;


     mlog2_epsilon_l = 1;		// Factor for computing
     mlog2_epsilon_e = 1;
     // B=2^(floor(log2(nk)))*2^(mlog2_epsilon)



     /*
      * Room for the test signal
      */
     x = (double complex *)malloc(sizeof(double complex) * N);
     /*
      * Frequency bins and their amplitudes for the test signal
      */
     ws = (uint32_t *) malloc(sizeof(uint32_t) * nk);
     amps = (double *) malloc(sizeof(double) * nk);
     plot_points_x = (double *) malloc(sizeof(double) * N);
     plot_points_y = (double *) malloc(sizeof(double) * N);


     /*
      * Room for the algorithm output
      */
     z_hat = (double complex *) malloc(sizeof(double complex) * N);
     wz_hat = (uint32_t *) malloc(sizeof(uint32_t) * N);




     /*
      * Initialize the pseudorandom number generators
      */
     srand(time(NULL) ^ (getpid() * 171717));
     srand48(time(NULL) ^ (getpid() * 171717));




     /*
      * Create test signal
      */
     memset(x, 0, N * sizeof(double complex));

     for (ii = 0; ii < nk; ii++) {
          ws[ii] = rand_all(N);
          amps[ii] = 1.0  + 0.4 * (drand48() - 0.5);
          x[ws[ii]] = amps[ii];
     }


     ifft(x, x, N);











     reset_timer();

     for (jj = 0; jj < reps; jj++) {
          /*
           * Sets accumulators to zero
           */
          memset(z_hat, 0, N * sizeof(double complex));
          suppz_hat = 0;

          /*
           * Calls SFFT
           */
          retcond = sfft42(x,	/* Input signal */
                           nk,	/* Sparsity order */
                           z_hat,	/* Value of the estimated sparse
				 * components */
                           wz_hat,	/* Frequency bins of the estimated
					 * sparse components */
                           &suppz_hat,	/* Size of wz_hat */
                           p,	/* log2(N) where N is the signal length */

                           alpha, delta, supp_reduction,	/* Flat windows parameters */
                           mlog2_epsilon_l,mlog2_epsilon_e,	/* Error parameter */
                           s,	/* Values location parameter */
                           Rloc,	/* Values location parameter */
                           Rest,	/* Values estimation parameter */
                           Rsfft	/* SFFT iterations parameter */
                          );

     }

     elapsed_time_sfft = get_time() / (double) reps;

     reset_timer();
     fft(x, x, N);
     elapsed_time_fftw = get_time();



     /*
      * Accuracy metrics with found indexes
      */
     aux_nelp = nk;
     found_indexes = 0;
     rmse = 0.0;
     maxrmse = 0.0;
     for (jj = 0; jj < nk; jj++) {
          aux_index_p =
               lfind(&ws[jj], wz_hat, &aux_nelp, sizeof(uint32_t),
                     compare_index);
          if (aux_index_p) {
           aux_index =
                    wz_hat[(uint32_t) ((uint32_t *) aux_index_p - wz_hat)];
               aux_value =
                    z_hat[(uint32_t) ((uint32_t *) aux_index_p - wz_hat)];
               rmsei = cabs(aux_value - x[aux_index]/(double)(N));// / fabs(amps[jj]) * 100.0;
#ifdef FULL_OUTPUT
               aux_index =
                    wz_hat[(uint32_t) ((uint32_t *) aux_index_p - wz_hat)];
               printf
               ("%d:\nX[%d]=%f+%f*1i\nX_hat[%d]=%f+%f*1i\n Error: %f \n\n",
                found_indexes, ws[jj], creal(x[aux_index]/(double)(N)),cimag(x[aux_index]/(double)(N)), aux_index,
                creal(aux_value), cimag(aux_value), rmsei);
#endif
               found_indexes++;
               rmse += rmsei;
               if (rmsei > maxrmse) {
                    maxrmse = rmsei;
                    real_worst_amp = amps[jj];
                    worst_amp = aux_value;
                    worst_index = ws[jj];
               }
          }


     }



     printf
     ("\nFor N=%d points I found out %d and %d indexes of %d -> retcond=%d L1 ERROR=%e, MEAN ERROR=%e and MAX ERROR=%e .\n\n",
      N, suppz_hat, found_indexes, nk, retcond, rmse, rmse/(double)found_indexes,maxrmse);
     printf("The worst value was X[%d]=%f+1i*%f -> x_hat[%d]=%f+1i*%f\n\n",
            worst_index, creal(real_worst_amp), cimag(real_worst_amp),
            worst_index, creal(worst_amp), cimag(worst_amp));





     printf("SFFT time: %f seconds\n", elapsed_time_sfft);
     printf("FFTW time: %f seconds\n", elapsed_time_fftw);


     /*
      * Plot results
      */
     h1 = gnuplot_init("sfftresults.svg");
     gnuplot_resetplot(h1);

     gnuplot_cmd(h1, "set title \"sFFT v4.0 for N=%d and k=%d\"", N, nk);

     gnuplot_cmd(h1, "set xrange [0:%d]", N - 1);
     gnuplot_cmd(h1, "set yrange [0:1.5]");

     gnuplot_cmd(h1, "set grid");
     gnuplot_set_xlabel(h1, "k");
     gnuplot_set_ylabel(h1, "Magnitude");





     for (jj = 0; jj < suppz_hat; jj++) {
          plot_points_x[jj] = (double) wz_hat[jj];
          plot_points_y[jj] = cabs(z_hat[jj]);
     }



     gnuplot_setstyle(h1, "impulses");
     gnuplot_setcolour(h1, "red");
     gnuplot_plot_xy(h1, plot_points_x, plot_points_y, suppz_hat, NULL);
     gnuplot_setstyle(h1, "points");
     gnuplot_plot_xy(h1, plot_points_x, plot_points_y, suppz_hat,
                     "Recovered sparse components");



     for (jj = 0; jj < nk; jj++) {

          plot_points_x[jj] = cabs(ws[jj]);
     }

     gnuplot_setcolour(h1, "blue");
     gnuplot_setstyle(h1, "impulses");
     gnuplot_plot_xy(h1, plot_points_x, amps, nk, NULL);
     gnuplot_setstyle(h1, "points");
     gnuplot_plot_xy(h1, plot_points_x, amps, nk,
                     "Original sparse components");






    //keypress(0);

     gnuplot_close(h1);


     free(plot_points_x);
     free(plot_points_y);


     free(ws);
     free(wz_hat);
     free(x);
     free(z_hat);
     free(amps);


     return 0;
}



/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifndef FLAT_WINDOWS_H_INCLUDED
#define FLAT_WINDOWS_H_INCLUDED

#include <stdint.h>
void window_parameters(uint32_t N, uint32_t B, double alpha, double delta,
			double *sigma, double *C, uint32_t * supp,
			uint32_t * one_index, uint32_t * zero_index);
void get_windows(uint32_t N, uint32_t B, double alpha, double delta, double supp_reduction,
		  double **G, double **G_hat, uint32_t * suppw,
		  uint32_t * one_index, uint32_t * zero_index);
double time_domain_fw(uint32_t N, double sigmaw, double C, uint32_t n);
double frequency_domain_fw(uint32_t N, double sigmaw, double C,
			    uint32_t one_index, uint32_t zero_index,
			    uint32_t n);


#endif				// FLAT_WINDOWS_H_INCLUDED

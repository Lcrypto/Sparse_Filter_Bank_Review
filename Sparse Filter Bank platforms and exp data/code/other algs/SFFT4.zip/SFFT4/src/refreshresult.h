#ifndef REFRESHRESULT_H
#define REFRESHRESULT_H
#include <stdint.h>
#include <complex.h>

//extern "C" void RefreshResult(double complex *z_hat, uint32_t *wz_hat, uint32_t *suppz_hat, double complex *z_hat_final, uint32_t *wz_hat_final, uint32_t *suppz_hat_final);
//extern "C"
//{
    //void RefreshResult(double complex *z_hat, uint32_t *wz_hat, uint32_t *suppz_hat, double complex *z_hat_final, uint32_t *wz_hat_final, uint32_t *suppz_hat_final);
//}


#endif // REFRESHRESULT_H

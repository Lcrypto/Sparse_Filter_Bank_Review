
/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */
#ifndef SFFT4_H_INCLUDED
#define SFFT4_H_INCLUDED
#include <stdint.h>

/*sFFT with constant flat window*/
    uint8_t sfft41(const double _Complex * x, /*Input signal */
		   const uint32_t k, /*Sparsity order */
           double _Complex * z_hat, /*Value of the estimated sparse components */
		   uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
		   uint32_t * suppz_hat, /*Size of wz_hat and z_hat */
		   uint8_t p, /*log2(N) where N is the signal length */
		   double alpha, double delta, double supp_reduction,/*Flat windows parameters */
		   uint8_t mlog2_epsilon, /*Error parameter */
		   double s, /*Values location parameter */
		   uint32_t Rloc, /*Values location parameter */
		   uint32_t Rest, /*Values estimation parameter */
		   uint32_t Rsfft /*SFFT iterations parameter */
    );

/*sFFT with time variant flat window (faster sFFT)*/
/*sFFT with time variant flat window (faster)*/
uint8_t sfft42(const double _Complex * x,	/*Input signal */
               const uint32_t k,	/*Sparsity order */
               double _Complex * z_hat,	/*Value of the estimated sparse components */
               uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
               uint32_t * suppz_hat,	/*Size of wz_hat */
               uint8_t p,	/*log2(N) where N is the signal length */
               double alpha, double delta, double supp_reduction,	/*Flat windows parameters */
               uint8_t mlog2_epsilon_l,uint8_t mlog2_epsilon_e,	/*Error parameter */
               double s,	/*Values location parameter */
               uint32_t Rloc,	/*Values location parameter */
               uint32_t Rest,	/*Values estimation parameter */
               uint32_t Rsfft	/*SFFT iterations parameter */
              );


              uint8_t sfft42_gaussian(const double _Complex * x,	/*Input signal */
               const uint32_t k,	/*Sparsity order */
               double _Complex * z_hat,	/*Value of the estimated sparse components */
               uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
               uint32_t * suppz_hat,	/*Size of wz_hat */
               uint8_t p,	/*log2(N) where N is the signal length */
               uint8_t mlog2_epsilon_l,uint8_t mlog2_epsilon_e,	/*Error parameter */
               double s,	/*Values location parameter */
               uint32_t Rloc,	/*Values location parameter */
               uint32_t Rest,	/*Values estimation parameter */
               uint32_t Rsfft	/*SFFT iterations parameter */
              );


#endif				// SFFT4_H_INCLUDED

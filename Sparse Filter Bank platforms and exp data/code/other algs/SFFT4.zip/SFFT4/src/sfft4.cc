/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <stdio.h>

#include <stdlib.h>
#include <math.h>

#include "locate-signal.h"
#include "estimate-values.h"
#include "flat-windows.h"
#include "utils.h"

//#include<map>
//using namespace std;



/*sFFT with constant window*/
uint8_t sfft41(const double _Complex * x,	/*Input signal */
               const uint32_t k,	/*Sparsity order */
               double _Complex * z_hat,	/*Value of the estimated sparse components */
               uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
               uint32_t * suppz_hat,	/*Size of wz_hat and z_hat */
               uint8_t p,	/*log2(N) where N is the signal length */
               double alpha, double delta, double supp_reduction,	/*Flat windows parameters */
               uint8_t mlog2_epsilon,	/*Error parameter */
               double s,	/*Values location parameter */
               uint32_t Rloc,	/*Values location parameter */
               uint32_t Rest,	/*Values estimation parameter */
               uint32_t Rsfft	/*SFFT iterations parameter */
              )
{

     double *G, *G_hat;
     uint32_t ii, N, B, *L, suppw_hat, suppw, one_index, zero_index;
     uint32_t Nl;
     uint8_t *w_hat;
     uint8_t retcond;
     //std::map<int, const double _Complex> ans;

     retcond = 0x0;

     /*Size of the signal */
     N = 1 << p;
     /*Number of bins to locate */
     B = 1<<((uint8_t)floor(log2(k))) << mlog2_epsilon;

     /*Windows calculation */
     get_windows(N, B, alpha, delta, supp_reduction,&G, &G_hat, &suppw, &one_index,
                 &zero_index);

     /*Vector with located bins */
     L = (uint32_t *) malloc(sizeof(uint32_t) * B);

     /*Vector to store the ĺocated bins and their values */
     w_hat =
          (uint8_t *) malloc((B) *                                  (sizeof(double complex) + sizeof(uint32_t)));




     /*Main loop */
     for (ii = 0; ii < Rsfft; ii++)
     {
          /*Located bins counter */
          Nl = 0;
          locate_signal2(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         *suppz_hat,	/*Size of wz_hat */
                         p,	/*log2(N) where N is the signal length */
                         G, G_hat, B, suppw, one_index, zero_index,	/*Flat window parameters *//*Flat window parameters */
                         s, Rloc, L,	/*Frequency bins to estimate */
                         &Nl);
          /*If no bin was located */
          if (Nl == 0) {
               retcond = ii + 1;
               break;
          } else {
               /*Perform values estimation */
               suppw_hat = estimate_values2(x,	/*Input signal */
                                            z_hat,	/*Value of the estimated sparse components */
                                            wz_hat,	/*Frequency bins of the estimated sparse components */
                                            *suppz_hat,	/*Size of wz_hat */
                                            L,	/*Frequency bins to estmate */
                                            Nl,	/*Size of L */
                                            N,	/* N is the signal length */
                                            G, G_hat, B, suppw, one_index, zero_index, 3*k, Rest, w_hat	/*Return vector: {real(X_wk), imag(X_wx), wk ...} */
                                           );

               /*Refines current estimation */
               add_values(z_hat, wz_hat, suppz_hat, w_hat, suppw_hat);




          }



     }




     free(L);
     free(w_hat);
     free(G);
     free(G_hat);
     return retcond;

}





/*sFFT with time variant flat window (faster)*/
uint8_t sfft42(const double _Complex * x,	/*Input signal */
               const uint32_t k,	/*Sparsity order */
               double _Complex * z_hat,	/*Value of the estimated sparse components */
               uint32_t * wz_hat,	/*Frequency bins of the estimated sparse components */
               uint32_t * suppz_hat,	/*Size of wz_hat */
               uint8_t p,	/*log2(N) where N is the signal length */
               double alpha, double delta, double supp_reduction,	/*Flat windows parameters */
               uint8_t mlog2_epsilon_l,uint8_t mlog2_epsilon_e,	/*Error parameter */
               double s,	/*Values location parameter */
               uint32_t Rloc,	/*Values location parameter */
               uint32_t Rest,	/*Values estimation parameter */
               uint32_t Rsfft	/*SFFT iterations parameter */
              )
{

     double *G_l, *G_hat_l;
     double *G_e, *G_hat_e;
     uint32_t ii, N,nk, B_l,B_e, *L, suppw_hat, suppw_l,suppw_e, one_index_l, zero_index_l,one_index_e, zero_index_e;
     uint32_t Nl;
     uint8_t *w_hat;
     uint8_t retcond;


     retcond = 0x0;


    nk=k;

     /*Size of the signal */
     N = 1 << p;
     /*Number of bins to locate */
     B_l = 1L<<((uint8_t)ceil(log2(k))) << mlog2_epsilon_l;
     B_e = 1L<<((uint8_t)ceil(log2(k))) << mlog2_epsilon_e;


     /*Vector with located bins */
     L = (uint32_t *) malloc(sizeof(uint32_t) * B_l);

     /*Vector to store the ĺocated bins and their values */
     w_hat =
          (uint8_t *) malloc((B_l) *   (sizeof(double complex) + sizeof(uint32_t)));


     /*First iteration Windows*/
     if(mlog2_epsilon_e==mlog2_epsilon_l){
     get_windows(N, B_l, alpha, delta,supp_reduction, &G_l, &G_hat_l, &suppw_l, &one_index_l,
                 &zero_index_l);

                 suppw_e=suppw_l;
                 one_index_e=one_index_l;
                 zero_index_e=zero_index_l;
                 G_e=G_l;
                 G_hat_e=G_hat_l;


     }
                 else{
                     get_windows(N, B_l, alpha, delta,supp_reduction, &G_l, &G_hat_l, &suppw_l, &one_index_l,
                 &zero_index_l);
get_windows(N, B_e, alpha, delta,supp_reduction, &G_e, &G_hat_e, &suppw_e, &one_index_e,
                 &zero_index_e);
                 }


     /*Main loop */
     for (ii = 0; ii < Rsfft; ii++) {



          /*Located bins counter */
          Nl = 0;
          locate_signal2(x,	/*Input signal */
                         z_hat,	/*Value of the estimated sparse components */
                         wz_hat,	/*Frequency bins of the estimated sparse components */
                         *suppz_hat,	/*Size of wz_hat */
                         p,	/*log2(N) where N is the signal length */
                         G_l, G_hat_l, B_l, suppw_l, one_index_l, zero_index_l,	/*Flat window parameters *//*Flat window parameters */
                         s, Rloc, L,	/*Frequency bins to estimate */
                         &Nl);
          /*If no bin was located */
          if (Nl == 0) {

               retcond = ii + 1;
               //break;

          } else {
               /*Perform values estimation */
               suppw_hat = estimate_values2(x,	/*Input signal */
                                            z_hat,	/*Value of the estimated sparse components */
                                            wz_hat,	/*Frequency bins of the estimated sparse components */
                                            *suppz_hat,	/*Size of wz_hat */
                                            L,	/*Frequency bins to estmate */
                                            Nl,	/*Size of L */
                                            N,	/* N is the signal length */
                                            G_e, G_hat_e, B_e, suppw_e, one_index_e, zero_index_e, 3*nk, Rest, w_hat	/*Return vector: {real(X_wk), imag(X_wx), wk ...} */
                                           );

               /*Refines current estimation */
               add_values(z_hat, wz_hat, suppz_hat, w_hat, suppw_hat);


               /*I divide B by two, at odd iterations */
               if ((B_e > 2) && (B_l > 2) && (ii & (0x01))) {
                    B_e = B_e >> 1;
                    B_l = B_l >> 1;
                    //alpha=alpha/2.0;
                    nk=nk>>1;

                    //Rest=Rest*0.9;

                    /*Windows calculation */
             /*First iteration Windows*/
     if(mlog2_epsilon_e==mlog2_epsilon_l){
     get_windows(N, B_l, alpha, delta,supp_reduction, &G_l, &G_hat_l, &suppw_l, &one_index_l,
                 &zero_index_l);

                 suppw_e=suppw_l;
                 one_index_e=one_index_l;
                 zero_index_e=zero_index_l;
                 G_e=G_l;
                 G_hat_e=G_hat_l;


     }
                 else{
                     get_windows(N, B_l, alpha, delta,supp_reduction, &G_l, &G_hat_l, &suppw_l, &one_index_l,
                 &zero_index_l);
get_windows(N, B_e, alpha, delta,supp_reduction, &G_e, &G_hat_e, &suppw_e, &one_index_e,
                 &zero_index_e);
                 }

               }




          }



     }




     free(L);
     free(w_hat);

     return retcond;





}



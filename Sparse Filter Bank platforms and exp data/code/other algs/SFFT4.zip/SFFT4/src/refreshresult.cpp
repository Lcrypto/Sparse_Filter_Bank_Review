#include <termios.h>
#include <search.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <float.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "sfft4.h"
#include "fft.h"
#include "estimate-values.h"
#include "timer.h"
#include "gnuplot_i.h"

#include <mm_malloc.h>
#include <math.h>

#include <pthread.h>
#include "refreshresult.h"
#include "refreshresult.h"
#include<map>
using namespace std;
map<uint32_t, double complex> complexMap;

extern "C"
void RefreshResult(double complex *z_hat, uint32_t *wz_hat, uint32_t *suppz_hat, double complex *z_hat_final, uint32_t *wz_hat_final, uint32_t *suppz_hat_final,
                   uint32_t ii, uint32_t N, uint32_t reps)
{

    uint32_t num = 0;
    int jj = 0;
    map<uint32_t, double complex>::iterator map_iter2 = complexMap.begin();
    map<uint32_t, double complex>::iterator map_iter1;
    //num = *suppz_hat_final;
    //num++;
    //*suppz_hat_final = num;
    num = *suppz_hat;
    if (ii == 0)
    {
        for (jj = 0; jj < num; jj ++)
        {
            complexMap[wz_hat[jj]] = z_hat[jj];
        }
    }
    else if (ii == (reps - 1))
    {
        for(jj = 0; map_iter2 != complexMap.end(); map_iter2 ++)
        {
            wz_hat_final[jj] =  map_iter2->first;
            z_hat_final[jj] = map_iter2->second;
            jj++;
        }
        *suppz_hat_final = jj;
    }
    else
    {
        for (jj = 0; jj < num; jj ++ )
        {
            map_iter1 = complexMap.find(wz_hat[jj]);
            if (map_iter1 == complexMap.end())
            {
                pair<uint32_t, double complex> value(wz_hat[jj], z_hat[jj]);
                complexMap.insert(value);
            }
        }
    }
}



/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifndef ESTIMATE_VALUES_H_INCLUDED
#define ESTIMATE_VALUES_H_INCLUDED

#include <stdint.h>
#include <complex.h>

//uint32_t estimate_values(const double complex *x, /*Input signal*/
//                  const double complex *z_hat, /*Value of the estimated sparse components*/
//                const uint32_t *wz_hat, /*Frequency bins of the estimated sparse components*/
//                 const uint32_t suppz_hat, /*Size of wz_hat*/
//                 const uint32_t *L, /*Frequency bins to estmate*/
//                 uint32_t NL, /*Size of L*/
//                  uint32_t N, /*log2(N) where N is the signal length*/
//                  uint32_t B,double alpha,double delta, /*Flat window parameters*/
//                  uint32_t k_prime, uint32_t Rest,
//                 void * w_hat  /*Return vector: {real(X_wk), imag(X_wx), wk ...}*/
//                  );
uint32_t estimate_values2(const double complex * x, /*Input signal */
			       const double complex * z_hat, /*Value of the estimated sparse components */
			       const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
			       const uint32_t suppz_hat, /*Size of wz_hat */
			       const uint32_t * L, /*Frequency bins to estmate */
			       uint32_t NL, /*Size of L */
			       uint32_t N, /*log2(N) where N is the signal length */
			       const double *G, const double *G_hat,
			       uint32_t B, uint32_t suppw,
			       uint32_t one_index, uint32_t zero_index,
			       /*Flat windows parameters */
			       uint32_t k_prime, uint32_t Rest,
void *w_hat
			       /*Return vector: {real(X_wk), imag(X_wx), wk ...} */

    );

    uint32_t estimate_values_gaussian(const double complex * x, /*Input signal */
			       const double complex * z_hat, /*Value of the estimated sparse components */
			       const uint32_t * wz_hat, /*Frequency bins of the estimated sparse components */
			       const uint32_t suppz_hat, /*Size of wz_hat */
			       const uint32_t * L, /*Frequency bins to estmate */
			       uint32_t NL, /*Size of L */
			       uint32_t N, /*log2(N) where N is the signal length */
			       const double *G, const double *G_hat,
			       uint32_t B, uint32_t suppw,
			        uint32_t zero_index,
			       /*Flat windows parameters */
			       uint32_t k_prime, uint32_t Rest,
void *w_hat
			       /*Return vector: {real(X_wk), imag(X_wx), wk ...} */

    );
int32_t compare_ascending(const void *a, const void *b);
int32_t compare_complex(const void *a, const void *b);
int32_t compare_index(const void *a, const void *b);
void add_values(double complex * z_hat,uint32_t * wz_hat,
uint32_t * suppz_hat,const void *w_hat,
uint32_t supp_w_hat);
double median(double *x, uint32_t N);

#endif				// ESTIMATE-VALUES_H_INCLUDED

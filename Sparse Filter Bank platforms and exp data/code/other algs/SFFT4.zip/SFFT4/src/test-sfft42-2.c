/*
 * Copyright (c) 2013 Alexander López-Parrado Universidad del
 * Valle/Universidad del Quindío.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <termios.h>
#include <search.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <float.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "sfft4.h"
#include "fft.h"
#include "estimate-values.h"
#include "timer.h"
#include "gnuplot_i.h"

#include <mm_malloc.h>
#include <math.h>

#include <pthread.h>
#include "refreshresult.h"

#define SFFT42

#define REPS 10
#define NNS 12
#define NKS 8

#define INDEX_K_VS_SIGNAL_SIZE 0
#define INDEX_N_VS_SPARSITY 9

//#define WITH_GNUPLOT


/*log2 of the signal sizes for tests*/
uint32_t log2Ns[NNS]={13,14,15,16,17,18,19,20,21,22,23,24};
/*log2 of the sparsity orders sizes for tests*/
uint32_t ks[NKS]={10,100,200,500,1000,2000,2500,4000};

void get_parameters(uint32_t N, uint32_t k, double *alpha, double *delta,double *s,uint32_t *Rloc, uint32_t *Rest, uint32_t *Rsfft, uint8_t * mlog2_epsilon_l, uint8_t * mlog2_epsilon_e){

     *alpha = 1.0;
     *delta = 1e-8;
     *Rloc = (uint32_t)floor(log2(log2((double)N)));
     *s = 0.001;
     *Rest = 12;
     *Rsfft = (uint32_t)floor(log2((double)k));
     //   *Rsfft = (uint32_t)ceil(log2((double)k)/(log2(log2((double)k))));
     *mlog2_epsilon_l = 1;
     *mlog2_epsilon_e = 1;

}


void print_times(double *indep_var,double *fftw_times,double *sfft_times, uint32_t n, char *xlabel,char *ylabel,char *title, char ptype){


    FILE   *h1;

     uint32_t jj;


     char file_name[100];


     sprintf(file_name,"sffttest%d.csv",ptype);

     h1 = fopen(file_name,"w+");

     	
     fprintf(h1,"# ");
     fprintf(h1,title);
     fprintf(h1,"\n");
     fprintf(h1,"#%s, FFTW3-3 time, sFFT-4.0 time\n",xlabel);


	for(jj=0;jj<n;jj++){
	     fprintf(h1,"%f, %f, %f\n",indep_var[jj],fftw_times[jj],sfft_times[jj]);

	}













	fclose(h1);







}



void plot_times(double *indep_var,double *fftw_times,double *sfft_times, uint32_t n, char *xlabel,char *ylabel,char *title, char ptype){


     gnuplot_ctrl   *h1;

     uint32_t jj;

     double max_time;

     double min_time;

     char file_name[100];


     sprintf(file_name,"sffttest%d.svg",ptype);

     h1 = gnuplot_init(file_name);
     gnuplot_resetplot(h1);


    max_time=0;
    min_time=FLT_MAX;
    for(jj=0;jj<n;jj++){
        if(sfft_times[jj]>max_time)
            max_time=sfft_times[jj];

           if(fftw_times[jj]>max_time)
            max_time=fftw_times[jj];

             if(sfft_times[jj]<min_time)
            min_time=sfft_times[jj];

           if(fftw_times[jj]<min_time)
            min_time=fftw_times[jj];

    }

    gnuplot_cmd(h1,"set logscale y 10");



    if(ptype)
    gnuplot_cmd(h1,"set logscale x 10");
    else
    gnuplot_cmd(h1,"set logscale x 2");


     gnuplot_cmd(h1, "set grid");


     gnuplot_cmd(h1, "set xrange [%d:%d]",(int32_t)indep_var[0],(int32_t)indep_var[n-1] );
    // gnuplot_cmd(h1, "set yrange [0.01:1]");

     gnuplot_cmd(h1, "set title \"%s\"", title);


     gnuplot_setcolour(h1, "blue");
     gnuplot_setstyle(h1, "linespoints");
     gnuplot_set_xlabel(h1, xlabel);
     gnuplot_set_ylabel(h1, ylabel);
     gnuplot_plot_xy(h1, indep_var, sfft_times, n,
                     "sFFT v4.0");


     gnuplot_setcolour(h1, "red");
     gnuplot_setstyle(h1, "linespoints");
     gnuplot_set_xlabel(h1, xlabel);
     gnuplot_set_ylabel(h1, ylabel);
     gnuplot_plot_xy(h1, indep_var, fftw_times, n,
                    "FFTW 3.3");


     gnuplot_close(h1);

}





void experiment_runtime_vs_signal_size(uint32_t *log2ns,uint32_t nns, uint32_t nk,uint32_t reps ,double *sfft_times,double *fftw_times)
{



     uint32_t        ii,
                     jj,
                     N,
                     suppz_hat,
                     suppz_hat_final,
                     *wz_hat,
                     *ws,
                     *wz_hat_final;


double complex *x,*z_hat;
double complex *z_hat_final;
double         *amps;

     double          s;
     double          alpha,
                     delta;

     uint32_t        Rloc,
                     Rest,
                     Rsfft;
     uint8_t         mlog2_epsilon_l,mlog2_epsilon_e;

     uint8_t p;

     printf("\n\n************* Running experiment: Runtime vs. Signal Size *************\n\n");

         srand(time(NULL) ^ (getpid() * 171717));
     srand48(time(NULL) ^ (getpid() * 171717));




   ws = (uint32_t *) _mm_malloc(sizeof(uint32_t) * nk, 16);
     amps = (double *) _mm_malloc(sizeof(double) * nk, 16);

/*Main loop of experiment*/
for(jj=0;jj<nns;jj++){
p=log2ns[jj];
    N=1<<p;



     x = (double complex *) _mm_malloc(sizeof(double complex) * N, 16);
     z_hat = (double complex *) _mm_malloc(sizeof(double complex) * N, 16);
     wz_hat = (uint32_t *) _mm_malloc(sizeof(uint32_t) * N, 16);
     z_hat_final = (double complex *) _mm_malloc(sizeof(double complex) * N, 16);
     wz_hat_final = (uint32_t *) _mm_malloc(sizeof(uint32_t) * N, 16);

    memset(x, 0, N * sizeof(double complex));

     for (ii = 0; ii < nk; ii++) {
          ws[ii] = rand_all(N);
          amps[ii] = 1.0 + 0.4 * (drand48() - 0.5);
          //x[ws[ii]] = 1.0 + I * 0.4 * (drand48() - 0.5);
          x[ws[ii]] = 1.0;
     }


     ifft(x, x, N);

    get_parameters(N, nk, &alpha, &delta,&s,&Rloc, &Rest, &Rsfft, &mlog2_epsilon_l,&mlog2_epsilon_e);

    printf("Running %d times sFFT v4.0 and FFTW for N=%d and k=%d\n",reps,N,nk);




  reset_timer();

   for(ii=0;ii<reps;ii++){


          memset(z_hat, 0, N * sizeof(double complex));
          suppz_hat = 0;

          #ifdef SFFT42

         sfft42(x,	/* Input signal */
                           nk,	/* Sparsity order */
                           z_hat,	/* Value of the estimated sparse
                 * components */
                           wz_hat,	/* Frequency bins of the estimated
                     * sparse components */
                           &suppz_hat,	/* Size of wz_hat */
                           p,	/* log2(N) where N is the signal length */
                           alpha, delta, 1.0,	/* Flat windows parameters */
                           mlog2_epsilon_l,mlog2_epsilon_e,	/* Error parameter */
                           s,	/* Values location parameter */
                           Rloc,	/* Values location parameter */
                           Rest,	/* Values estimation parameter */
                           Rsfft	/* SFFT iterations parameter */
                          );


           #else

                    sfft41(x,	/* Input signal */
                           nk,	/* Sparsity order */
                           z_hat,	/* Value of the estimated sparse
                 * components */
                           wz_hat,	/* Frequency bins of the estimated
                     * sparse components */
                           &suppz_hat,	/* Size of wz_hat */
                           p,	/* log2(N) where N is the signal length */
                           alpha, delta,1.0,	/* Flat windows parameters */
                           //mlog2_epsilon,	/* Error parameter */
                           mlog2_epsilon_l,
                           s,	/* Values location parameter */
                           Rloc,	/* Values location parameter */
                           Rest,	/* Values estimation parameter */
                           Rsfft	/* SFFT iterations parameter */
                          );

                          #endif


        RefreshResult(z_hat, wz_hat, &suppz_hat, z_hat_final, wz_hat_final, &suppz_hat_final, ii, N, reps);



   }
   sfft_times[jj]=get_time()/(double)reps;

   reset_timer();
   for(ii=0;ii<reps;ii++)
   fft(x,x,N);
   fftw_times[jj]=get_time()/(double)reps;



_mm_free(wz_hat);
_mm_free(x);
_mm_free(z_hat);
_mm_free(wz_hat_final);
_mm_free(z_hat_final);


}

_mm_free(amps);
_mm_free(ws);





}




void experiment_runtime_vs_sparsity_order(uint32_t *ks,uint32_t nks, uint32_t log2n,uint32_t reps ,double *sfft_times,double *fftw_times){



     uint32_t        ii,
                     jj,
                     N,
                     nk,
                     suppz_hat,
                     *wz_hat,
                     *ws;


double complex *x,*z_hat;
double         *amps;

     double          s;
     double          alpha,
                     delta;

     uint32_t        Rloc,
                     Rest,
                     Rsfft;
     uint8_t         mlog2_epsilon_l,mlog2_epsilon_e;

     uint8_t p;

     printf("\n\n************* Running experiment: Runtime vs. Sparsity Order *************\n\n");

         srand(time(NULL) ^ (getpid() * 171717));
     srand48(time(NULL) ^ (getpid() * 171717));



p=log2n;
N=1<<p;

 x = (double complex *) _mm_malloc(sizeof(double complex) * N, 16);
      z_hat = (double complex *) _mm_malloc(sizeof(double complex) * N, 16);
     wz_hat = (uint32_t *) _mm_malloc(sizeof(uint32_t) * N, 16);

/*Main loop of experiment*/
for(jj=0;jj<nks;jj++){
nk=ks[jj];





     ws = (uint32_t *) _mm_malloc(sizeof(uint32_t) * nk, 16);
     amps = (double *) _mm_malloc(sizeof(double) * nk, 16);


    memset(x, 0, N * sizeof(double complex));

     for (ii = 0; ii < nk; ii++) {
          ws[ii] = rand_all(N);
          amps[ii] = 1.0 + 0.4 * (drand48() - 0.5);
          x[ws[ii]] = 1.0 + I * 0.4 * (drand48() - 0.5);
     }


     ifft(x, x, N);

    get_parameters(N, nk, &alpha, &delta,&s,&Rloc, &Rest, &Rsfft, &mlog2_epsilon_l,&mlog2_epsilon_e);

    printf("Running %d times sFFT v4.0 and FFTW for N=%d and k=%d\n",reps,N,nk);




  reset_timer();

   for(ii=0;ii<reps;ii++){


          memset(z_hat, 0, N * sizeof(double complex));
          suppz_hat = 0;

    #ifdef SFFT42

         sfft42(x,	/* Input signal */
                           nk,	/* Sparsity order */
                           z_hat,	/* Value of the estimated sparse
				 * components */
                           wz_hat,	/* Frequency bins of the estimated
					 * sparse components */
                           &suppz_hat,	/* Size of wz_hat */
                           p,	/* log2(N) where N is the signal length */
                           alpha, delta,1.0,	/* Flat windows parameters */
                           mlog2_epsilon_l,mlog2_epsilon_e,	/* Error parameter */
                           s,	/* Values location parameter */
                           Rloc,	/* Values location parameter */
                           Rest,	/* Values estimation parameter */
                           Rsfft	/* SFFT iterations parameter */
                          );


           #else

                    sfft41(x,	/* Input signal */
                           nk,	/* Sparsity order */
                           z_hat,	/* Value of the estimated sparse
				 * components */
                           wz_hat,	/* Frequency bins of the estimated
					 * sparse components */
                           &suppz_hat,	/* Size of wz_hat */
                           p,	/* log2(N) where N is the signal length */
                           alpha, delta,1.0,	/* Flat windows parameters */
                           //mlog2_epsilon,	/* Error parameter */
                           mlog2_epsilon_l,
                           s,	/* Values location parameter */
                           Rloc,	/* Values location parameter */
                           Rest,	/* Values estimation parameter */
                           Rsfft	/* SFFT iterations parameter */
                          );

                          #endif





   }
   sfft_times[jj]=get_time()/(double)reps;

 reset_timer();
   for(ii=0;ii<reps;ii++)
   fft(x,x,N);
   fftw_times[jj]=get_time()/(double)reps;


   _mm_free(ws);
   _mm_free(amps);







}

_mm_free(wz_hat);
_mm_free(x);
_mm_free(z_hat);




}

/* sleep until a key is pressed and return value. echo = 0 disables key echo. */
int keypress(unsigned char echo)
{
    struct termios savedState, newState;
    int c;

    if (-1 == tcgetattr(STDIN_FILENO, &savedState))
    {
        return EOF;     /* error on tcgetattr */
    }

    newState = savedState;

    if ((echo = !echo)) /* yes i'm doing an assignment in an if clause */
    {
        echo = ECHO;    /* echo bit to disable echo */
    }

    /* disable canonical input and disable echo.  set minimal input to 1. */
    newState.c_lflag &= ~(echo | ICANON);
    newState.c_cc[VMIN] = 1;

    if (-1 == tcsetattr(STDIN_FILENO, TCSANOW, &newState))
    {
        return EOF;     /* error on tcsetattr */
    }

    c = getchar();      /* block (withot spinning) until we get a keypress */

    /* restore the saved state */
    if (-1 == tcsetattr(STDIN_FILENO, TCSANOW, &savedState))
    {
        return EOF;     /* error on tcsetattr */
    }

    return c;
}


int main()
{

double fftw_times1[NNS],sfft_times1[NNS];
double fftw_times2[NKS],sfft_times2[NKS];

double signal_sizes[NNS];
double sparsity_orders[NKS];

char aux_str[100];


uint32_t jj;



experiment_runtime_vs_signal_size(log2Ns,NNS, ks[INDEX_K_VS_SIGNAL_SIZE],REPS ,sfft_times1,fftw_times1);

for(jj=0;jj<NNS;jj++)
signal_sizes[jj]=(double)(1<<log2Ns[jj]);
sprintf(aux_str,"sFFT-4.0 runtime against signal size for K=%d",ks[INDEX_K_VS_SIGNAL_SIZE]);

#ifdef WITH_GNUPLOT
plot_times(signal_sizes,fftw_times1,sfft_times1, NNS, "Signal size N","Runtime (seconds)",aux_str,0);

#else

print_times(signal_sizes,fftw_times1,sfft_times1, NNS, "Signal size N","Runtime (seconds)",aux_str,0);

#endif








experiment_runtime_vs_sparsity_order(ks,NKS, log2Ns[INDEX_N_VS_SPARSITY],REPS ,sfft_times2,fftw_times2);
for(jj=0;jj<NKS;jj++)
sparsity_orders[jj]=(double)(ks[jj]);
sprintf(aux_str,"sFFT-4.0 runtime against sparsity order for N=%d",1<<log2Ns[INDEX_N_VS_SPARSITY]);
#ifdef WITH_GNUPLOT
plot_times(sparsity_orders,fftw_times2,sfft_times2, NKS, "Sparsity order K","Runtime (seconds)",aux_str,1);
#else

print_times(sparsity_orders,fftw_times2,sfft_times2, NKS, "Sparsity order K","Runtime (seconds)",aux_str,1);

#endif

    //keypress(0);

     return 0;
}


